<?php

  /**
   * Provide a public-facing view for the plugin
   *
   * This file is used to markup the public-facing aspects of the plugin.
   *
   * @link       http://example.com
   * @since      1.0.0
   *
   * @package    Carehome_Property
   * @subpackage Carehome_Property/public/partials/form
   */
 ?>
<div class="jr-page jrPage jrAdvSearchModule jrRoundedPanel jrForm jrAdvSearchModule2" style="background: #0000005e; ">

<form class="jr-form-adv-search-module" action="<?php echo site_url(); ?>/properties/" method="get" data-live-search="0" data-live-search-hide="1" data-module-id="jreviewsadvsearchwidget-2">
   <div class="jrFieldDiv jrLeft" style="display:none"></div>
   <div class="jrFieldDiv jrLeft"> 
      <input type="text" style="width:100%; font-weight:500;height: 50px;" class="jrKeywords" placeholder="Enter a city, zip code or name of a care home" name="keywords" value="">
   </div>
   <div class="jrFieldDiv jrLeft jr_button"> 
      <button class="jr-search jrButton jrButton2" style="margin:0;padding: 3px 20px !important;height: 53px;border: transparent;"><i class="fa fa-search" aria-hidden="true" style="margin-right: 5px;"></i><span style="font-family: monospace;">Search</span> 
        </button>
    </div>
 <div class="jrClear"></div> 
</form>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo site_url().'/wp-content/plugins/carehome-property/public/css/theme_css/theme.min.css'; ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css" media="screen">
  .jrAdvSearchModule2 .jrFieldDiv .jrButton {
       padding: 12px 20px !important;
       background: #dd3333 !important;
       color: #fff !important;
       display: inline-block;
   }
   [class^="jrIcon"]:before{color:#fff !important}
   .jrKeywords{padding:25px !important; }
    .jrButton, .ui-state-focus.jrButton, #es a.jrButton{border-radius:inherit !important}
    .jrRoundedPanel, .jrRoundedPanelLt{border-bottom:inherit !important}
    .jrForm, .jrForm.jrFormContainer, .jrForm.jrReviewForm, #es form.jrForm {
       padding: 18px 18px 6px !important;}
      .jrForm{width:38% !important}
    .jrLeft{ width:78% !important }
    .jr_button{width:22% !important}

    input::placeholder {
     color: #b1b1b1;
   }
   @media screen and (max-width: 1920px) {
      .jrForm
            {
               width:32% !important
         }
   }
   @media screen and (max-width: 1680px) {
      .jrForm
            {
               width:36% !important
         }
   }
   @media screen and (max-width: 1600px) {
      .jrForm
            {
               width:38% !important
         }
   }
   @media only screen and (max-width: 1440px) {
      .jrForm
            {
               width:42% !important
         }
   }
   @media only screen and (max-width: 1366px) {
      .jrForm
            {
               width:44% !important
         }
   }
   @media only screen and (max-width: 1280px) {
      .jrForm
            {
               width:47% !important
         }
   }
   @media only screen and (max-width: 1140px) {
      .jrForm
            {
               width:54% !important
         }
   }
   @media only screen and (max-width: 1024px) {
      .jrForm
            {
               width:60% !important
         }
           .jrLeft {
       width: 75% !important;
   }
   .jr_button {
       width: 25% !important;
   }
   }
    
    @media only screen and (max-width: 991px) {
      .jrForm
            {
               width:62% !important
         }
   }
   @media only screen and (max-width: 900px) {
      .jrLeft {
       width: 76% !important;
   }
   .jr_button {
       width: 24% !important;
   }
   }
   @media only screen and (max-width: 800px) {
      .jrForm
            {
               width:75% !important
         }
   }
   @media only screen and (max-width: 768px) {
      .jrForm
            {
               width:78% !important
         }
   }
   @media only screen and (max-width: 767px) {
      .jrForm
            {
               width:95% !important
         }
         .jrLeft{ width:100% !important  }
   }
   @media only screen and (max-width: 320px) {
      .jrForm
            {
               width:95% !important
         }
          
   }  
</style>