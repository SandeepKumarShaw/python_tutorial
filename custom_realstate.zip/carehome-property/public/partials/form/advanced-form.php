<?php
  /**
   * Provide a public-facing view for the plugin
   *
   * This file is used to markup the public-facing aspects of the plugin.
   *
   * @link       http://example.com
   * @since      1.0.0
   *
   * @package    Carehome_Property
   * @subpackage Carehome_Property/public/partials/form
   */
 ?>
<div id="tm-main" class="tm-main uk-section uk-section-default" uk-height-viewport="expand: true" style="min-height: 61px;">
  <div class="uk-container">
    <div class="uk-grid uk-grid-divider uk-grid-stack" uk-grid="">
      <div class="uk-width-expand@m uk-first-column">
        <section id="primary">
          <div id="content" role="main">
            <div class="jr-page jrPage jrAdvSearchPage">
              <div class="jrFormContainer jrForm">
                <form id="jr-form-adv-search" name="jr-form-adv-search1" action="<?php echo site_url().'/properties/'; ?>" method="get">
                  <fieldset>
                <!--     <div class="jrFieldDiv">
                      <div class="jrFieldOption"> <input name="contentoptions[]" id="jr-title" type="checkbox" value="title" checked="checked">Listing title</div>
                      <div class="jrFieldOption"> <input name="contentoptions[]" id="fulltext" type="checkbox" value="fulltext" checked="checked">Listing description</div>
                      <div class="jrFieldOption"> <input name="contentoptions[]" id="reviews" type="checkbox" value="reviews">Review comments</div>
                    </div> -->
                    <div class="jrFieldDiv"> <input type="text" id="keywords" name="jrTitle" class="jrTitle" value="" placeholder="Enter name of a care home"></div>
              <!--       <div class="jrFieldDiv">
                      <div class="jrFieldOption"> <input name="search_query_1" id="search_query_1" type="radio" value="any" checked="checked">Any</div>
                      <div class="jrFieldOption"> <input name="search_query_2" id="search_query_2" type="radio" value="all">All</div>
                      <div class="jrFieldOption"> <input name="search_query_3" id="search_query_3" type="radio" value="exact">Exact</div>
                    </div> -->
                    <div class="jrFieldDiv"> <button class="jr-search jrButton">Search</button> <button class="jr-back jrButton" onclick="history.back();">Cancel</button> <span id="spinner" class="jrLoadingSmall jrHidden"></span></div>
                  </fieldset>
                  <div id="jr-search-fields" class="jr-search-fields jrHidden" style="display: block;">
                 <fieldset style="margin: 15px 0;">
                      <div class="jrFieldDiv">
                        <label>Category</label>
                        <select name="jv_category" class="jrSelect" size="5">
                          <option value="assisted-living-communities">- Assisted Living Communities</option>
                          <option value="residential-care-homes">- Residential Care Homes</option>
                        </select>
                      </div>
                    </fieldset>
                    <br>
                    <fieldset id="group_location" class="jrHidden jrFieldsetMargin" style="display: block;">
                      <legend>Location</legend>
                      <div class="jrFieldDiv jrCity">
                        <span class="jrFieldBefore">Search ANY selected option</span><label class="jrLabel">City</label>



                        <select name="jr_city[]" id="jr_city" class="jr_city jrSelectMultiple" multiple="multiple" data-search="1">
                          <option value="adelanto">ADELANTO</option>
                          <option value="agoura-hills">AGOURA HILLS</option>
                          <option value="alameda">ALAMEDA</option>
                          <option value="alamo">ALAMO</option>
                          <option value="albany">ALBANY</option>
                          <option value="albion">ALBION</option>
                          <option value="alhambra">ALHAMBRA</option>
                          <option value="aliso-viejo">Aliso Viejo</option>
                          <option value="alpine">ALPINE</option>
                          <option value="alta-loma">ALTA LOMA</option>
                          <option value="altadena">ALTADENA</option>
                          <option value="american-canyon">AMERICAN CANYON</option>
                          <option value="anaheim">ANAHEIM</option>
                          <option value="anaheim-hill">ANAHEIM HILL</option>
                          <option value="anaheim-hills">ANAHEIM HILLS</option>
                          <option value="anderson">ANDERSON</option>
                          <option value="angels-camp">ANGELS CAMP</option>
                          <option value="angelus-oaks">ANGELUS OAKS</option>
                          <option value="angwin">ANGWIN</option>
                          <option value="antelope">ANTELOPE</option>
                          <option value="antioch">ANTIOCH</option>
                          <option value="apple-valley">APPLE VALLEY</option>
                          <option value="aptos">APTOS</option>
                          <option value="arcadia">ARCADIA</option>
                          <option value="arleta">ARLETA</option>
                          <option value="arroyo-grande">ARROYO GRANDE</option>
                          <option value="artesia">ARTESIA</option>
                          <option value="atascadero">ATASCADERO</option>
                          <option value="atwater">ATWATER</option>
                          <option value="auburn">AUBURN</option>
                          <option value="azusa">AZUSA</option>
                          <option value="bakersfield">BAKERSFIELD</option>
                          <option value="balboa-island">BALBOA ISLAND</option>
                          <option value="baldwin-park">BALDWIN PARK</option>
                          <option value="banning">BANNING</option>
                          <option value="barstow">BARSTOW</option>
                          <option value="bay-point">BAY POINT</option>
                          <option value="bayside">BAYSIDE</option>
                          <option value="beaumont">BEAUMONT</option>
                          <option value="bella-vista">BELLA VISTA</option>
                          <option value="bellflower">BELLFLOWER</option>
                          <option value="belmont">BELMONT</option>
                          <option value="ben-lomond">BEN LOMOND</option>
                          <option value="benicia">BENICIA</option>
                          <option value="berkeley">BERKELEY</option>
                          <option value="bermuda-dunes">BERMUDA DUNES</option>
                          <option value="bermudas-dunes">BERMUDAS DUNES</option>
                          <option value="beverly-hills">BEVERLY HILLS</option>
                          <option value="big-bear-city">BIG BEAR CITY</option>
                          <option value="bishop">BISHOP</option>
                          <option value="bloomington">BLOOMINGTON</option>
                          <option value="bolinas">BOLINAS</option>
                          <option value="bonita">BONITA</option>
                          <option value="bonsall">BONSALL</option>
                          <option value="borrego-springs">BORREGO SPRINGS</option>
                          <option value="brawley">BRAWLEY</option>
                          <option value="brea">BREA</option>
                          <option value="brentwood">BRENTWOOD</option>
                          <option value="browns-valley">BROWNS VALLEY</option>
                          <option value="buena-park">BUENA PARK</option>
                          <option value="burbank">BURBANK</option>
                          <option value="burlingame">BURLINGAME</option>
                          <option value="calabasas">CALABASAS</option>
                          <option value="calimesa">CALIMESA</option>
                          <option value="calistoga">CALISTOGA</option>
                          <option value="camarillo">CAMARILLO</option>
                          <option value="cambria">CAMBRIA</option>
                          <option value="cameron-park">CAMERON PARK</option>
                          <option value="camino">CAMINO</option>
                          <option value="campbell">CAMPBELL</option>
                          <option value="canoga-park">CANOGA PARK</option>
                          <option value="canyon-country">CANYON COUNTRY</option>
                          <option value="canyon-lake">CANYON LAKE</option>
                          <option value="capistrano-beach">CAPISTRANO BEACH</option>
                          <option value="cardiff-by-the-sea">CARDIFF BY THE SEA</option>
                          <option value="carlsbad">CARLSBAD</option>
                          <option value="carmel">CARMEL</option>
                          <option value="carmel-valley">CARMEL VALLEY</option>
                          <option value="carmichael">CARMICHAEL</option>
                          <option value="carpinteria">CARPINTERIA</option>
                          <option value="carson">CARSON</option>
                          <option value="castaic">CASTAIC</option>
                          <option value="castro-valley">CASTRO VALLEY</option>
                          <option value="castroville">CASTROVILLE</option>
                          <option value="cathedral-city">CATHEDRAL CITY</option>
                          <option value="cathedral-way">CATHEDRAL WAY</option>
                          <option value="ceres">CERES</option>
                          <option value="cerritos">CERRITOS</option>
                          <option value="chastworth">CHASTWORTH</option>
                          <option value="chatsworth">CHATSWORTH</option>
                          <option value="cherry-valley">CHERRY VALLEY</option>
                          <option value="chico">CHICO</option>
                          <option value="chino">CHINO</option>
                          <option value="chino-hills">CHINO HILLS</option>
                          <option value="chowchilla">CHOWCHILLA</option>
                          <option value="chula-vista">CHULA VISTA</option>
                          <option value="citrus-heights">CITRUS HEIGHTS</option>
                          <option value="claremont">CLAREMONT</option>
                          <option value="clayton">CLAYTON</option>
                          <option value="clearlake">CLEARLAKE</option>
                          <option value="cloverdale">CLOVERDALE</option>
                          <option value="clovis">CLOVIS</option>
                          <option value="coalinga">COALINGA</option>
                          <option value="coarsegold">COARSEGOLD</option>
                          <option value="colfax">COLFAX</option>
                          <option value="colma">COLMA</option>
                          <option value="colton">COLTON</option>
                          <option value="compton">COMPTON</option>
                          <option value="concord">CONCORD</option>
                          <option value="contra-costa">CONTRA COSTA</option>
                          <option value="corning">CORNING</option>
                          <option value="corona">Corona</option>
                          <option value="corona-del-mar">CORONA DEL MAR</option>
                          <option value="coronado">CORONADO</option>
                          <option value="corralitos">CORRALITOS</option>
                          <option value="corte-madera">CORTE MADERA</option>
                          <option value="costa-mesa">Costa Mesa</option>
                          <option value="cotati">COTATI</option>
                          <option value="coulterville">COULTERVILLE</option>
                          <option value="covina">COVINA</option>
                          <option value="crescent-city">CRESCENT CITY</option>
                          <option value="cudahy">CUDAHY</option>
                          <option value="culver-city">CULVER CITY</option>
                          <option value="cupertino">CUPERTINO</option>
                          <option value="cypress">CYPRESS</option>
                          <option value="daly-city">DALY CITY</option>
                          <option value="dana-point">DANA POINT</option>
                          <option value="danville">DANVILLE</option>
                          <option value="davis">DAVIS</option>
                          <option value="del-mar">DEL MAR</option>
                          <option value="del-rey-oaks">DEL REY OAKS</option>
                          <option value="delano">DELANO</option>
                          <option value="desert-hot-springs">DESERT HOT SPRINGS</option>
                          <option value="diamond">DIAMOND</option>
                          <option value="diamond-bar">DIAMOND BAR</option>
                          <option value="dinuba">DINUBA</option>
                          <option value="dixon">DIXON</option>
                          <option value="downey">DOWNEY</option>
                          <option value="duarte">DUARTE</option>
                          <option value="dublin">DUBLIN</option>
                          <option value="eagle-rock">EAGLE ROCK</option>
                          <option value="east-palo-alto">EAST PALO ALTO</option>
                          <option value="eastvale">EASTVALE</option>
                          <option value="el-cajon">EL CAJON</option>
                          <option value="el-centro">EL CENTRO</option>
                          <option value="el-cerrito">EL CERRITO</option>
                          <option value="el-dorado">EL DORADO</option>
                          <option value="el-dorado-hills">EL DORADO HILLS</option>
                          <option value="el-dorado-hils">EL DORADO HILS</option>
                          <option value="el-monte">EL MONTE</option>
                          <option value="el-sobrante">EL SOBRANTE</option>
                          <option value="elk-grove">ELK GROVE</option>
                          <option value="elverta">ELVERTA</option>
                          <option value="emerald-hills">EMERALD HILLS</option>
                          <option value="emeryville">EMERYVILLE</option>
                          <option value="empire">EMPIRE</option>
                          <option value="encinitas">ENCINITAS</option>
                          <option value="encino">ENCINO</option>
                          <option value="escalon">ESCALON</option>
                          <option value="escondido">ESCONDIDO</option>
                          <option value="esparto">ESPARTO</option>
                          <option value="etna">ETNA</option>
                          <option value="eureka">EUREKA</option>
                          <option value="exeter">EXETER</option>
                          <option value="fair-oaks">FAIR OAKS</option>
                          <option value="fairfield">FAIRFIELD</option>
                          <option value="fallbrook">FALLBROOK</option>
                          <option value="fillmore">FILLMORE</option>
                          <option value="folsom">FOLSOM</option>
                          <option value="fontana">FONTANA</option>
                          <option value="foresthill">FORESTHILL</option>
                          <option value="forestville">FORESTVILLE</option>
                          <option value="fort-bragg">FORT BRAGG</option>
                          <option value="fortuna">FORTUNA</option>
                          <option value="foster-city">FOSTER CITY</option>
                          <option value="fountain-valley">Fountain Valley</option>
                          <option value="fowler">FOWLER</option>
                          <option value="freedom">FREEDOM</option>
                          <option value="fremont">FREMONT</option>
                          <option value="french-camp">FRENCH CAMP</option>
                          <option value="fresno">FRESNO</option>
                          <option value="fullerton">FULLERTON</option>
                          <option value="galt">GALT</option>
                          <option value="garden-grove">GARDEN GROVE</option>
                          <option value="gardena">GARDENA</option>
                          <option value="gilroy">GILROY</option>
                          <option value="glendale">GLENDALE</option>
                          <option value="glendora">GLENDORA</option>
                          <option value="glenn">GLENN</option>
                          <option value="gold-river">GOLD RIVER</option>
                          <option value="goleta">GOLETA</option>
                          <option value="granada-hills">GRANADA HILLS</option>
                          <option value="grand-terrace">GRAND TERRACE</option>
                          <option value="granda-hills">GRANDA HILLS</option>
                          <option value="granite-bay">GRANITE BAY</option>
                          <option value="grass-valley">GRASS VALLEY</option>
                          <option value="greenbrae">GREENBRAE</option>
                          <option value="grenada">GRENADA</option>
                          <option value="gridley">GRIDLEY</option>
                          <option value="grover-beach">GROVER BEACH</option>
                          <option value="gualala">GUALALA</option>
                          <option value="hacienda-heights">HACIENDA HEIGHTS</option>
                          <option value="hanford">HANFORD</option>
                          <option value="harbor-city">HARBOR CITY</option>
                          <option value="hawthorne">HAWTHORNE</option>
                          <option value="hayward">HAYWARD</option>
                          <option value="healdsburg">HEALDSBURG</option>
                          <option value="helendale">HELENDALE</option>
                          <option value="hemet">HEMET</option>
                          <option value="hercules">HERCULES</option>
                          <option value="hermosa-beach">HERMOSA BEACH</option>
                          <option value="hesperia">HESPERIA</option>
                          <option value="highland">HIGHLAND</option>
                          <option value="hilmar">HILMAR</option>
                          <option value="hollister">HOLLISTER</option>
                          <option value="holtville">HOLTVILLE</option>
                          <option value="hughson">HUGHSON</option>
                          <option value="huntington">HUNTINGTON</option>
                          <option value="huntington-beach">HUNTINGTON BEACH</option>
                          <option value="imperial-beach">IMPERIAL BEACH</option>
                          <option value="indio">INDIO</option>
                          <option value="inglewood">INGLEWOOD</option>
                          <option value="ione">IONE</option>
                          <option value="irvine">Irvine</option>
                          <option value="jackson">JACKSON</option>
                          <option value="jaipur">jaipur</option>
                          <option value="jamestown">JAMESTOWN</option>
                          <option value="jamul">JAMUL</option>
                          <option value="joshua-tree">JOSHUA TREE</option>
                          <option value="julian">JULIAN</option>
                          <option value="jurupa-valley">JURUPA VALLEY</option>
                          <option value="kelseyville">KELSEYVILLE</option>
                          <option value="kentfield">KENTFIELD</option>
                          <option value="kenwood">KENWOOD</option>
                          <option value="kerman">KERMAN</option>
                          <option value="kernville">KERNVILLE</option>
                          <option value="la-canada">LA CANADA</option>
                          <option value="la-crescenta">LA CRESCENTA</option>
                          <option value="la-habra">LA HABRA</option>
                          <option value="la-habra-heights">LA HABRA HEIGHTS</option>
                          <option value="la-jolla">LA JOLLA</option>
                          <option value="la-mesa">LA MESA</option>
                          <option value="la-mirada">LA MIRADA</option>
                          <option value="la-palma">LA PALMA</option>
                          <option value="la-puente">LA PUENTE</option>
                          <option value="la-quinta">LA QUINTA</option>
                          <option value="la-selva-beach">LA SELVA BEACH</option>
                          <option value="la-verne">LA VERNE</option>
                          <option value="lafayette">LAFAYETTE</option>
                          <option value="laguna-beach">LAGUNA BEACH</option>
                          <option value="laguna-hills">LAGUNA HILLS</option>
                          <option value="laguna-niguel">LAGUNA NIGUEL</option>
                          <option value="laguna-woods">LAGUNA WOODS</option>
                          <option value="lake-balboa">LAKE BALBOA</option>
                          <option value="lake-elsinore">LAKE ELSINORE</option>
                          <option value="lake-forest">LAKE FOREST</option>
                          <option value="lakeport">LAKEPORT</option>
                          <option value="lakeside">LAKESIDE</option>
                          <option value="lakewood">LAKEWOOD</option>
                          <option value="lancaster">LANCASTER</option>
                          <option value="lathrop">LATHROP</option>
                          <option value="lawndale">LAWNDALE</option>
                          <option value="lemon-grove">LEMON GROVE</option>
                          <option value="lemoore">LEMOORE</option>
                          <option value="lincoln">LINCOLN</option>
                          <option value="little-river">LITTLE RIVER</option>
                          <option value="littlerock">LITTLEROCK</option>
                          <option value="livermore">LIVERMORE</option>
                          <option value="lodi">LODI</option>
                          <option value="loma-linda">LOMA LINDA</option>
                          <option value="lomita">LOMITA</option>
                          <option value="lompoc">LOMPOC</option>
                          <option value="long-beach">LONG BEACH</option>
                          <option value="loomis">LOOMIS</option>
                          <option value="los-alamitos">LOS ALAMITOS</option>
                          <option value="los-altos">LOS ALTOS</option>
                          <option value="los-angeles">LOS ANGELES</option>
                          <option value="los-banos">LOS BANOS</option>
                          <option value="los-gatos">LOS GATOS</option>
                          <option value="los-molinos">LOS MOLINOS</option>
                          <option value="los-osos">LOS OSOS</option>
                          <option value="lower-lake">LOWER LAKE</option>
                          <option value="lynwood">LYNWOOD</option>
                          <option value="mader">MADER</option>
                          <option value="madera">MADERA</option>
                          <option value="malibu">MALIBU</option>
                          <option value="manhattan-beach">MANHATTAN BEACH</option>
                          <option value="manteca">MANTECA</option>
                          <option value="marina">MARINA</option>
                          <option value="mariposa">MARIPOSA</option>
                          <option value="martinez">MARTINEZ</option>
                          <option value="marysville">MARYSVILLE</option>
                          <option value="mccloud">MCCLOUD</option>
                          <option value="mckinleyville">MCKINLEYVILLE</option>
                          <option value="menifee">MENIFEE</option>
                          <option value="menlo-park">MENLO PARK</option>
                          <option value="mentone">MENTONE</option>
                          <option value="merced">MERCED</option>
                          <option value="midway-city">MIDWAY CITY</option>
                          <option value="mill-valley">MILL VALLEY</option>
                          <option value="millbrae">MILLBRAE</option>
                          <option value="milpitas">MILPITAS</option>
                          <option value="mira-loma">MIRA LOMA</option>
                          <option value="mission-hills">MISSION HILLS</option>
                          <option value="mission-viejo">MISSION VIEJO</option>
                          <option value="modesto">MODESTO</option>
                          <option value="modjeska-canyon">MODJESKA CANYON</option>
                          <option value="monarch-beach">MONARCH BEACH</option>
                          <option value="monrovia">MONROVIA</option>
                          <option value="montara">MONTARA</option>
                          <option value="montclair">MONTCLAIR</option>
                          <option value="montebello">MONTEBELLO</option>
                          <option value="monterey">MONTEREY</option>
                          <option value="monterey-park">MONTEREY PARK</option>
                          <option value="montrose">MONTROSE</option>
                          <option value="moorpark">MOORPARK</option>
                          <option value="moraga">MORAGA</option>
                          <option value="moreno-valley">MORENO VALLEY</option>
                          <option value="morgan-hill">MORGAN HILL</option>
                          <option value="morro-bay">MORRO BAY</option>
                          <option value="moss-beach">MOSS BEACH</option>
                          <option value="mountain-view">MOUNTAIN VIEW</option>
                          <option value="mt-view">MT. VIEW</option>
                          <option value="murrieta">MURRIETA</option>
                          <option value="n-hollywood">N HOLLYWOOD</option>
                          <option value="napa">NAPA</option>
                          <option value="national-city">NATIONAL CITY</option>
                          <option value="nevada-city">NEVADA CITY</option>
                          <option value="newark">NEWARK</option>
                          <option value="newbury-park">NEWBURY PARK</option>
                          <option value="newcastle">NEWCASTLE</option>
                          <option value="newhall">NEWHALL</option>
                          <option value="newman">NEWMAN</option>
                          <option value="newport-beach">Newport Beach</option>
                          <option value="nice">NICE</option>
                          <option value="nipomo">NIPOMO</option>
                          <option value="norco">NORCO</option>
                          <option value="north-fork">NORTH FORK</option>
                          <option value="north-highlands">NORTH HIGHLANDS</option>
                          <option value="north-hills">NORTH HILLS</option>
                          <option value="north-hollywood">NORTH HOLLYWOOD</option>
                          <option value="north-tustin">NORTH TUSTIN</option>
                          <option value="northridge">NORTHRIDGE</option>
                          <option value="norwalk">NORWALK</option>
                          <option value="novato">NOVATO</option>
                          <option value="nuevo">NUEVO</option>
                          <option value="oak-park">OAK PARK</option>
                          <option value="oak-view">OAK VIEW</option>
                          <option value="oakdale">OAKDALE</option>
                          <option value="oakhurst">OAKHURST</option>
                          <option value="oakland">OAKLAND</option>
                          <option value="oakley">OAKLEY</option>
                          <option value="oceanside">OCEANSIDE</option>
                          <option value="ojai">OJAI</option>
                          <option value="olivehurst">OLIVEHURST</option>
                          <option value="ontario">ONTARIO</option>
                          <option value="orange">ORANGE</option>
                          <option value="orangevale">ORANGEVALE</option>
                          <option value="orcutt">ORCUTT</option>
                          <option value="orinda">ORINDA</option>
                          <option value="orland">ORLAND</option>
                          <option value="oroville">OROVILLE</option>
                          <option value="oxnard">OXNARD</option>
                          <option value="pacific-grove">PACIFIC GROVE</option>
                          <option value="pacific-palisades">PACIFIC PALISADES</option>
                          <option value="pacifica">PACIFICA</option>
                          <option value="pacoima">PACOIMA</option>
                          <option value="palm-desert">PALM DESERT</option>
                          <option value="palm-spring">PALM SPRING</option>
                          <option value="palm-springs">PALM SPRINGS</option>
                          <option value="palmdale">PALMDALE</option>
                          <option value="palo-alto">PALO ALTO</option>
                          <option value="palos-verdes-estates">PALOS VERDES ESTATES</option>
                          <option value="panorama">PANORAMA</option>
                          <option value="panorama-city">PANORAMA CITY</option>
                          <option value="paradise">PARADISE</option>
                          <option value="pasadena">PASADENA</option>
                          <option value="paso-robles">PASO ROBLES</option>
                          <option value="patterson">PATTERSON</option>
                          <option value="penn-valley">PENN VALLEY</option>
                          <option value="penngrove">PENNGROVE</option>
                          <option value="penryn">PENRYN</option>
                          <option value="perris">PERRIS</option>
                          <option value="petaluma">PETALUMA</option>
                          <option value="phelan">PHELAN</option>
                          <option value="phillips-ranch">PHILLIPS RANCH</option>
                          <option value="pinole">PINOLE</option>
                          <option value="pinon-hills">PINON HILLS</option>
                          <option value="pismo-beach">PISMO BEACH</option>
                          <option value="pittsburg">PITTSBURG</option>
                          <option value="placentia">PLACENTIA</option>
                          <option value="placerville">PLACERVILLE</option>
                          <option value="playa-vista">PLAYA VISTA</option>
                          <option value="pleasant-hill">PLEASANT HILL</option>
                          <option value="pleasanton">PLEASANTON</option>
                          <option value="point-reyes-station">POINT REYES STATION</option>
                          <option value="pomona">POMONA</option>
                          <option value="port-hueneme">PORT HUENEME</option>
                          <option value="porter-ranch">PORTER RANCH</option>
                          <option value="porterville">PORTERVILLE</option>
                          <option value="portola">PORTOLA</option>
                          <option value="portola-valley">PORTOLA VALLEY</option>
                          <option value="poway">POWAY</option>
                          <option value="quail-valley">QUAIL VALLEY</option>
                          <option value="quartz-hill">QUARTZ HILL</option>
                          <option value="ramona">RAMONA</option>
                          <option value="ranch-cucamonga">RANCH CUCAMONGA</option>
                          <option value="rancho-cordova">RANCHO CORDOVA</option>
                          <option value="rancho-cucamonga">RANCHO CUCAMONGA</option>
                          <option value="rancho-mirage">RANCHO MIRAGE</option>
                          <option value="rancho-mission-viejo">RANCHO MISSION VIEJO</option>
                          <option value="rancho-palos-verdes">RANCHO PALOS VERDES</option>
                          <option value="rancho-san-diego">RANCHO SAN DIEGO</option>
                          <option value="rancho-santa-margari">RANCHO SANTA MARGARI</option>
                          <option value="red-bluff">RED BLUFF</option>
                          <option value="redding">REDDING</option>
                          <option value="redlands">REDLANDS</option>
                          <option value="redondo-beach">REDONDO BEACH</option>
                          <option value="redwood-city">REDWOOD CITY</option>
                          <option value="reedley">REEDLEY</option>
                          <option value="reseda">RESEDA</option>
                          <option value="rialto">RIALTO</option>
                          <option value="richmond">RICHMOND</option>
                          <option value="ridgecrest">RIDGECREST</option>
                          <option value="rio-dell">RIO DELL</option>
                          <option value="rio-linda">RIO LINDA</option>
                          <option value="rio-vista">RIO VISTA</option>
                          <option value="ripon">RIPON</option>
                          <option value="riverbank">RIVERBANK</option>
                          <option value="riverside">Riverside</option>
                          <option value="rnacho-mirage">RNACHO MIRAGE</option>
                          <option value="rocklin">ROCKLIN</option>
                          <option value="rodeo">RODEO</option>
                          <option value="rohnert-park">ROHNERT PARK</option>
                          <option value="rolling-hills-estate">ROLLING HILLS ESTATE</option>
                          <option value="rosemead">ROSEMEAD</option>
                          <option value="roseville">ROSEVILLE</option>
                          <option value="rossmoor">ROSSMOOR</option>
                          <option value="rowland-heights">ROWLAND HEIGHTS</option>
                          <option value="s-san-francisco">S SAN FRANCISCO</option>
                          <option value="sacramento">SACRAMENTO</option>
                          <option value="salida">SALIDA</option>
                          <option value="salinas">SALINAS</option>
                          <option value="san-andreas">SAN ANDREAS</option>
                          <option value="san-anselmo">SAN ANSELMO</option>
                          <option value="san-bernardino">SAN BERNARDINO</option>
                          <option value="san-bruno">SAN BRUNO</option>
                          <option value="san-carlos">SAN CARLOS</option>
                          <option value="san-clemente">SAN CLEMENTE</option>
                          <option value="san-diego">SAN DIEGO</option>
                          <option value="san-dimas">SAN DIMAS</option>
                          <option value="san-fernando">SAN FERNANDO</option>
                          <option value="san-francisco">SAN FRANCISCO</option>
                          <option value="san-gabriel">SAN GABRIEL</option>
                          <option value="san-jacinto">SAN JACINTO</option>
                          <option value="san-jose">SAN JOSE</option>
                          <option value="san-juan-capistano">SAN JUAN CAPISTANO</option>
                          <option value="san-juan-capistrano">SAN JUAN CAPISTRANO</option>
                          <option value="san-leandro">SAN LEANDRO</option>
                          <option value="san-lorenzo">SAN LORENZO</option>
                          <option value="san-luis-obispo">SAN LUIS OBISPO</option>
                          <option value="san-marcos">SAN MARCOS</option>
                          <option value="san-martin">SAN MARTIN</option>
                          <option value="san-mateo">SAN MATEO</option>
                          <option value="san-pablo">SAN PABLO</option>
                          <option value="san-pedro">SAN PEDRO</option>
                          <option value="san-rafael">SAN RAFAEL</option>
                          <option value="san-ramon">SAN RAMON</option>
                          <option value="sanger">SANGER</option>
                          <option value="santa-ana">Santa Ana</option>
                          <option value="santa-barbara">SANTA BARBARA</option>
                          <option value="santa-clara">SANTA CLARA</option>
                          <option value="santa-clarita">SANTA CLARITA</option>
                          <option value="santa-cruz">SANTA CRUZ</option>
                          <option value="santa-maria">SANTA MARIA</option>
                          <option value="santa-monica">SANTA MONICA</option>
                          <option value="santa-paula">SANTA PAULA</option>
                          <option value="santa-rosa">SANTA ROSA</option>
                          <option value="santee">SANTEE</option>
                          <option value="saratoga">SARATOGA</option>
                          <option value="saugus">SAUGUS</option>
                          <option value="scotts-valley">SCOTTS VALLEY</option>
                          <option value="seal-beach">SEAL BEACH</option>
                          <option value="seaside">SEASIDE</option>
                          <option value="sebastopol">SEBASTOPOL</option>
                          <option value="selma">SELMA</option>
                          <option value="shafter">SHAFTER</option>
                          <option value="shasta-lake-city">SHASTA LAKE CITY</option>
                          <option value="sherman-oaks">SHERMAN OAKS</option>
                          <option value="sherwood-forest">SHERWOOD FOREST</option>
                          <option value="shingle-springs">SHINGLE SPRINGS</option>
                          <option value="sierra-madre">SIERRA MADRE</option>
                          <option value="simi-valley">SIMI VALLEY</option>
                          <option value="sky-valley">SKY VALLEY</option>
                          <option value="so-san-francisco">SO SAN FRANCISCO</option>
                          <option value="solana-beach">SOLANA BEACH</option>
                          <option value="solvang">SOLVANG</option>
                          <option value="somis">SOMIS</option>
                          <option value="sonoma">SONOMA</option>
                          <option value="sonora">SONORA</option>
                          <option value="soquel">SOQUEL</option>
                          <option value="soulsbyville">SOULSBYVILLE</option>
                          <option value="south-pasadena">SOUTH PASADENA</option>
                          <option value="south-san-francisco">SOUTH SAN FRANCISCO</option>
                          <option value="spring-valley">SPRING VALLEY</option>
                          <option value="st-helena">ST HELENA</option>
                          <option value="stallion-springs">STALLION SPRINGS</option>
                          <option value="stanton">STANTON</option>
                          <option value="stevenson-ranch">STEVENSON RANCH</option>
                          <option value="stockton">STOCKTON</option>
                          <option value="strathmore">STRATHMORE</option>
                          <option value="studio-city">STUDIO CITY</option>
                          <option value="suisun">SUISUN</option>
                          <option value="suisun-city">SUISUN CITY</option>
                          <option value="sun-city">SUN CITY</option>
                          <option value="sun-valley">SUN VALLEY</option>
                          <option value="sunland">SUNLAND</option>
                          <option value="sunnyvale">SUNNYVALE</option>
                          <option value="susanville">SUSANVILLE</option>
                          <option value="sutter-creek">SUTTER CREEK</option>
                          <option value="sylmar">SYLMAR</option>
                          <option value="taft">TAFT</option>
                          <option value="tarzana">TARZANA</option>
                          <option value="tehachapi">TEHACHAPI</option>
                          <option value="temecula">TEMECULA</option>
                          <option value="temple-city">TEMPLE CITY</option>
                          <option value="templeton">TEMPLETON</option>
                          <option value="thermalito">THERMALITO</option>
                          <option value="thousand-oaks">THOUSAND OAKS</option>
                          <option value="toluca-lake">TOLUCA LAKE</option>
                          <option value="tomales">TOMALES</option>
                          <option value="torrance">TORRANCE</option>
                          <option value="tracy">TRACY</option>
                          <option value="tujunga">TUJUNGA</option>
                          <option value="tulare">TULARE</option>
                          <option value="turlock">TURLOCK</option>
                          <option value="tustin">TUSTIN</option>
                          <option value="twentynine-palms">TWENTYNINE PALMS</option>
                          <option value="ukiah">UKIAH</option>
                          <option value="union-city">UNION CITY</option>
                          <option value="upland">UPLAND</option>
                          <option value="upper-lake">UPPER LAKE</option>
                          <option value="vacaville">VACAVILLE</option>
                          <option value="vacville">VACVILLE</option>
                          <option value="val-verde">VAL VERDE</option>
                          <option value="valencia">VALENCIA</option>
                          <option value="valinda">VALINDA</option>
                          <option value="vallejo">VALLEJO</option>
                          <option value="valley-center">VALLEY CENTER</option>
                          <option value="valley-glen">VALLEY GLEN</option>
                          <option value="valley-village">VALLEY VILLAGE</option>
                          <option value="van-nuys">VAN NUYS</option>
                          <option value="venice">VENICE</option>
                          <option value="ventura">VENTURA</option>
                          <option value="victorville">VICTORVILLE</option>
                          <option value="villa-park">VILLA PARK</option>
                          <option value="visala">VISALA</option>
                          <option value="visalia">VISALIA</option>
                          <option value="vista">VISTA</option>
                          <option value="walnut">WALNUT</option>
                          <option value="walnut-creek">WALNUT CREEK</option>
                          <option value="wasco">WASCO</option>
                          <option value="watsonville">WATSONVILLE</option>
                          <option value="weimar">WEIMAR</option>
                          <option value="west-covina">WEST COVINA</option>
                          <option value="west-hills">WEST HILLS</option>
                          <option value="west-hollywood">WEST HOLLYWOOD</option>
                          <option value="west-los-angeles">WEST LOS ANGELES</option>
                          <option value="west-sacramento">WEST SACRAMENTO</option>
                          <option value="westlake-village">WESTLAKE VILLAGE</option>
                          <option value="westminister">WESTMINISTER</option>
                          <option value="westminster">WESTMINSTER</option>
                          <option value="westwood">WESTWOOD</option>
                          <option value="whittier">WHITTIER</option>
                          <option value="wildomar">WILDOMAR</option>
                          <option value="williams">WILLIAMS</option>
                          <option value="willits">WILLITS</option>
                          <option value="wilton">WILTON</option>
                          <option value="winchester">WINCHESTER</option>
                          <option value="windsor">WINDSOR</option>
                          <option value="winnetka">WINNETKA</option>
                          <option value="wofford-heights">WOFFORD HEIGHTS</option>
                          <option value="woodland">WOODLAND</option>
                          <option value="woodland-hills">WOODLAND HILLS</option>
                          <option value="woodside">WOODSIDE</option>
                          <option value="yorba-linda">YORBA LINDA</option>
                          <option value="yountville">YOUNTVILLE</option>
                          <option value="yreka">YREKA</option>
                          <option value="yuba-city">YUBA CITY</option>
                          <option value="yucaipa">YUCAIPA</option>
                          <option value="yucca-valley">YUCCA VALLEY</option>
                        </select>
                     
                      </div>
                      <div class="jrFieldDiv jrPostalcode">
                        <label class="jrLabel">Zip Code</label>
                        <input type="text" name="jr_postalcode" class="jr_postalcode jrText" data-search="1">
                      </div>
                    </fieldset>
                    

                    <?php        
                    $Amenities = "field_5dadac5d891b6";
                    $Amenitiy = get_field_object($Amenities);
                    if( $Amenitiy )
                    {
                            echo '<fieldset id="group_amenities" class="jrHidden jrFieldsetMargin" style="display: block;">';
                            echo '<legend>Amenities</legend>';
                            echo '<div class="jrFieldDiv jrAmenities">';
                            echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Amenities</label>';

                            foreach( $Amenitiy['choices'] as $k => $v )
                            {
                              echo '<div class="jr-option jrFieldOption" style="min-width: 324px;">';
                               echo '<input type="checkbox" name="jr_amenities[]" id="jr_amenities_activity-center-search" class="jr_amenities" data-search="1" value="' . $k . '">';
                               echo '<label for="jr_amenities_activity-center-search">' . $v . '</label>';    
                                echo '</div>';       
                            }

                            echo '</div>';
                            echo '</fieldset>';
                       
                    }            
                            
                    $services = "field_5dadae53141ef";
                    $service = get_field_object($services);
                    if( $service )
                    {
                            echo '<fieldset id="group_services" class="jrHidden jrFieldsetMargin" style="display: block;">';
                            echo '<legend>Services</legend>';
                            echo '<div class="jrFieldDiv jrServices">';
                            echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Services</label>';

                            foreach( $service['choices'] as $k => $v )
                            {
                              echo '<div class="jr-option jrFieldOption" style="min-width: 324px;">';
                               echo '<input type="checkbox" name="jr_services[]" id="jr_services_bathing-dressing-assistance-search" class="jr_services" data-search="1" value="' . $k . '">';
                               echo '<label for="jr_services_bathing-dressing-assistance-search">' . $v . '</label>';    
                                echo '</div>';       
                            }

                            echo '</div>';
                            echo '</fieldset>';
                       
                    }            
                          
                    $languages = "field_5dadae98b8c24";
                    $language = get_field_object($languages);
                    if( $language )
                    {
                            echo '<fieldset id="group_languages" class="jrHidden jrFieldsetMargin" style="display: block;">';
                            echo '<legend>Languages</legend>';
                            echo '<div class="jrFieldDiv jrLanguagesspoken">';
                            echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Languages Spoken</label>';

                            foreach( $language['choices'] as $k => $v )
                            {
                              echo '<div class="jr-option jrFieldOption" style="min-width: 157px;">';
                               echo '<input type="checkbox" name="jr_languagesspoken[]" id="jr_languagesspoken_cantonese-search" class="jr_languagesspoken" data-search="1" value="' . $k . '">';
                               echo '<label for="jr_services_bathing-dressing-assistance-search">' . $v . '</label>';    
                                echo '</div>';       
                            }

                            echo '</div>';
                            echo '</fieldset>';
                       
                    }            
                    ?>

                    <fieldset id="group_availability" class="jrHidden jrFieldsetMargin" style="display: block;">
                      <legend>Availability</legend>
                      <div class="jrFieldDiv jrAvailablebedsinprivaterooms">
                        <label class="jrLabel">Private Rooms</label>
                        <select name="jr_availbedprooms_c" class="jr-search-range jrSearchOptions">
                         <option value="=">=</option>
                          <option value=">=">&gt;=</option>
                          <option value="<=">&lt;=</option>
                        </select>
                        <input type="number" name="jr_availbedprooms" class="jr_availbedprooms jrInteger">
                      </div>

                      <div class="jrFieldDiv jrAvailablebedsinsharedrooms">
                        <label class="jrLabel">Shared Rooms</label>
                        <select name="jr_availbedsrooms_c" class="jr-search-range jrSearchOptions">
                          <option value="=">=</option>
                          <option value=">=">&gt;=</option>
                          <option value="<=">&lt;=</option>
                        </select>
                        <input type="number" name="jr_availbedsrooms" class="jr_availablebedsinsharedrooms jrInteger">
                      </div>
                    </fieldset>


                    <fieldset id="group_pricing" class="jrHidden jrFieldsetMargin" style="display: block;">
                      <legend>Pricing</legend>
                      <div class="jrFieldDiv jrPrivateroomcostmonth">
                        <label class="jrLabel">Private Room Cost/Month</label>
                        <select name="jrPrivateroomcostmonth_c" class="jr-search-range jrSearchOptions">
                          <option value="=">=</option>
                          <option value=">=">&gt;=</option>
                          <option value="<=">&lt;=</option>
                        </select>
                        <input type="number" name="jr_privateroomcostmonth" class="jr_privateroomcostmonth jrDecimal" data-search="1"><span class="jrHidden">
                      </div>
                      <div class="jrFieldDiv jrSharedroomcostmonth">
                        <label class="jrLabel">Shared Room Cost/Month</label>
                        <select name="jrSharedroomcostmonth_c" class="jr-search-range jrSearchOptions">
                          <option value="=">=</option>
                          <option value=">=">&gt;=</option>
                          <option value="<=">&lt;=</option>
                        </select>
                        <input type="number" name="jr_sharedroomcostmonth" class="jr_sharedroomcostmonth jrDecimal" data-search="1">
                      </div>
                    </fieldset>
                    <div class="jrFieldDiv" style="margin-top:15px;">
                      <button class="jr-search jrButton">Search</button>
                      <button class="jr-back jrButton" onclick="history.back();">Cancel</button>
                    </div>
                  </div>
                 
                </form>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</div>
<div id="loader"></div>

<script type="text/javascript">
jQuery(document).ready(function ($) {
    var spinner = $('#loader');

  $('#jr-form-adv-search').submit(function (e) {
  e.preventDefault();
spinner.show();
  var query = $(this).serializeArray().filter(function (i) {
    return i.value;
  });

   window.location.href = $(this).attr('action') + (query ? '?' + $.param(query) : '');
});

  $("input[name='jr_amenities[]']").change(function () {
      var maxAllowed = 4;
      var cnt = $("input[name='jr_amenities[]']:checked").length;
      if (cnt > maxAllowed){
          $(this).prop("checked", "");
          alert('Select maximum ' + maxAllowed + ' Amenities!');
      }
  });

    $("input[name='jr_services[]']").change(function () {
      var maxAllowed = 4;
      var cnt = $("input[name='jr_services[]']:checked").length;
      if (cnt > maxAllowed){
          $(this).prop("checked", "");
          alert('Select maximum ' + maxAllowed + ' Services!');
      }
  });

    $("input[name='jr_languagesspoken[]']").change(function () {
      var maxAllowed = 4;
      var cnt = $("input[name='jr_languagesspoken[]']:checked").length;
      if (cnt > maxAllowed){
          $(this).prop("checked", "");
          alert('Select maximum ' + maxAllowed + ' Languages!');
      }
  });

  var last_valid_selection = null;

  $('#jr_city').change(function(event) {

    if ($(this).val().length > 4) {

      $(this).val(last_valid_selection);
      alert('Select maximum 4 City!');
    } else {
      last_valid_selection = $(this).val();
    }
  });  

});
</script>
<style type="text/css">
  #loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/user/images/loader1.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }
</style>