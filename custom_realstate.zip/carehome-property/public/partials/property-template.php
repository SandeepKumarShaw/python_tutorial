<?php
  /**
   * Provide a public-facing view for the plugin
   *
   * This file is used to markup the public-facing aspects of the plugin.
   *
   * @link       http://example.com
   * @since      1.0.0
   *
   * @package    Carehome_Property
   * @subpackage Carehome_Property/public/partials
   */  
  get_header();
  ?>
<div id="primary" class="content-area">
  <main id="main" class="site-main" role="main">
    <div id="tm-main" class="tm-main uk-section uk-section-default" uk-height-viewport="expand: true" style="min-height: 107px;">
      <div class="uk-container uk-container-small">
        <div class="uk-grid uk-grid-divider uk-grid-stack" uk-grid="">
          <div class="uk-width-expand@m uk-first-column">
            <section id="primary">
              <div id="content" role="main">
                <div class="jr-main jrCategoriesSearch jrStyles ">
                  <div class="jr-page jr-listing-list jrPage jrListings jrThumbview">
                    <div class="jrListScope jrRoundedPanelLt">
                      <div class="jrListSearch">
                        <form class="jr-simple-search" action="<?php echo site_url() .'/properties/'; ?>" method="get">
                          <input class="jrText" type="text" name="keywords" value="<?php 

                          if(isset($_GET['keywords'])){
                            echo $_GET['keywords'];
                          }elseif(isset($_GET['jrTitle'])) {
                              echo $_GET['jrTitle'];
                          } 
                          ?>" placeholder="Search"> <button class="jr-search1 jrButton"><span class="jrIconSearch"></span>Search</button> &nbsp;<a href="<?php echo site_url() .'/property-advanced-search/'; ?>">Advanced search</a>                         
                        </form>
                      </div>
                    </div>            
                    
                    <?php //echo do_shortcode('[the_ad id="23307"]'); ?>
                    <?php if(function_exists('the_ad')) the_ad(23307); ?>


                    <div class="jrFiltersButtonContainer"><a href="#" onclick="javascript:;" class="jr-list-show-filters jrBlue jrButton jrFiltersButton"><span class="jrIconFilters"></span> Filters</a></div>
                    <div class="jrClear"></div>
                    <div id="jr-pagenav-ajax">
                      <?php 
                        load_template(plugin_dir_path( __FILE__ ) . '/content/property-content.php');
                        ?>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- .site-main -->
</div>
<!-- .content-area -->
<?php //get_sidebar(); ?>
<?php get_footer(); ?>