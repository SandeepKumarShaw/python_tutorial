<?php
  /**
  * Provide a public-facing view for the plugin
  *
  * This file is used to markup the public-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/public/partials/content
  */  

  //$args = array();
  global $WP_Query;
  $count = $wp_query->found_posts;
  $per_page = 10;
  $paged = get_query_var('paged') ? get_query_var('paged') : 1;
  $args = array(
      'post_type' => 'property', 
      'posts_per_page' => $per_page, 
      'paged' => $paged,
      'meta_key' => '_is_featured',
      'orderby' => 'meta_value_num',
      'order' =>'DESC'
  );
  
/*    $args['post_type'] = 'property';
  $args['posts_per_page'] = $per_page;
  $args['paged'] = $paged;*/
  
 /* if(isset($_GET['keywords'])){
  $args['_meta_or_title'] = $_GET['keywords'];
  
  }*/
  
  //print_r($args);
  
  $loop = new WP_Query( $args );
  $from = ($per_page * $paged) - ($per_page - 1);
  
  if(($per_page * $paged) <= ($loop->found_posts)){
    $to = ($per_page * $paged);
  }else{
    $to = $loop->found_posts;
  }
  if($from == $to){
    $from_to = $from;
  }else{
    $from_to = $from . ' - ' . $to;
  }  
/*echo '<pre>';
print_r($loop);
echo '</pre>';*/


  ?>
<div class="jrTableGrid jrPagination jrPaginationTop" data-ajax="1" data-push="1">
  <div class="jrCol4 jrPagenavResults"> 
    <?php if($count > 0): ?>
    <span class="jrPagenavResultsText"><?php echo $count; ?> results - showing <?php echo $from_to; ?></span>
    <?php endif; ?>
  </div>
  <div class="jrCol4 jrPagenavPages">
    <div class="jrButtonGroup fwd-flex-no-wrap"> 
      <?php
        echo do_shortcode("[WP_Property_Archieve_shortcode pagerange=" . $wp_query->max_num_pages . "]"); 
      ?>   
    </div>
  </div>
  <div class="jrCol4 jrPagenavLimit">
    <div class="jrOrdering">
      <span>Ordering</span> 
      <?php 
        $meta_key = !empty( $_GET['meta_key'] ) ? $_GET['meta_key'] : ''; 
        $orderby = !empty( $_GET['orderby'] ) ? $_GET['orderby'] : ''; 
        $order = !empty( $_GET['order'] ) ? $_GET['order'] : '';        
        ?>
      <select name="order" class="jr-list-sort jrSelect fwd-mr-0 jrSelect" size="1">
        <option value="<?php echo site_url(); ?>/properties/" selected="selected">Select Option</option>
        <!--     <option value="http://localhost/PracticeWP/properties/?_is_featured=yes" <?php if(!empty($_GET['_is_featured'])){ echo 'selected="selected"'; } ?>>Featured</option>
          <option value="<?php echo site_url(); ?>/properties/?order=rating&amp;dir=2&amp;criteria=2&amp;query=all">Highest user rating</option> -->
        <option value="<?php echo site_url(); ?>/properties/?meta_key=_is_featured&orderby=meta_value&order=DESC" <?php if($meta_key=='_is_featured'){ echo 'selected="selected"'; }?>>Featured</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=&orderby=title&order=ASC" <?php if($orderby=='title' && $order =='ASC'){ echo 'selected="selected"'; }?>>Title</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=&orderby=post_date&order=DESC" <?php if($orderby=='post_date' && $order =='DESC'){ echo 'selected="selected"'; }?>>Most recent</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=&orderby=comment_count&order=DESC" <?php if($orderby=='comment_count' && $order =='DESC'){ echo 'selected="selected"'; }?>>Most reviews</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=my_post_viewed&orderby=meta_value_num&order=DESC" <?php if($meta_key=='my_post_viewed' && $order =='DESC'){ echo 'selected="selected"'; }?>>Most popular</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=private_room_costmonth&orderby=meta_value_num&order=ASC" <?php if($meta_key=='private_room_costmonth' && $order =='ASC'){ echo 'selected="selected"'; }?>>Private Room Cost/Month ASC</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=private_room_costmonth&orderby=meta_value_num&order=DESC" <?php if($meta_key=='private_room_costmonth' && $order =='DESC'){ echo 'selected="selected"'; }?>>Private Room Cost/Month DESC</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=shared_room_costmonth&orderby=meta_value_num&order=ASC"<?php if($meta_key=='shared_room_costmonth' && $order =='ASC'){ echo 'selected="selected"'; }?>>Shared Room Cost/Month ASC</option>
        <option value="<?php echo site_url(); ?>/properties/?meta_key=shared_room_costmonth&orderby=meta_value_num&order=DESC"<?php if($meta_key=='shared_room_costmonth' && $order =='DESC'){ echo 'selected="selected"'; }?>>Shared Room Cost/Month DESC</option>
      </select>
      <script>
        jQuery(function($){
          // bind change event to select
          $('.jrSelect').on('change', function () {
              var url = $(this).val(); // get selected value
              if (url) { // require a URL
                  window.location = url; // redirect
              }
              return false;
          });         
        });
      </script>
    </div>
  </div>
</div>
<?php  
  if ( $loop->have_posts() ) :  
  ?>
<div class="jrResults">
  <div id="jr-listing-column" class="jrListingColumn jrListColumn2">
    <?php 
      // Start the Loop.
      while ( $loop->have_posts() ) :
          $loop->the_post(); 
      $is_featured = get_post_meta($post->ID, '_is_featured', TRUE);    
     ?>
    <div class="jr-listing-outer jrListItem  jrFeatured jrShadowBox">
      <div class="jrListingThumbnail jr-more-info jr-ready"> 
        <a href="<?php echo get_the_permalink($post->ID); ?>" data-map-lookup="1" data-listing-id="<?php echo $post->ID; ?>">
        <?php
          if(has_post_thumbnail() ) :
          $image_id = get_post_thumbnail_id($post->ID);          
          $src = wp_get_attachment_image_src($image_id, array( 5600,1000 ), false, '' );  
          $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);          
          ?>
        <img src="<?php echo $src[0];?>" alt="<?php echo $image_alt;?>" data-listingid="<?php echo $post->ID; ?>">
        <?php
          else:
          ?>
        <img src="<?php echo plugins_url();?>/carehome-property/public/images/chd_white-bg-temp_image.png" alt="Cameo Assisted Living - Lighthouse" data-listingid="<?php echo $post->ID; ?>">
        <?php
          endif;
          ?>
        </a>
      </div>
      <div class="jrListingTitle">
        <a href="<?php echo get_the_permalink($post->ID); ?>" data-map-lookup="1" data-listing-id="<?php echo $post->ID; ?>"><?php echo get_the_title($post->ID); ?></a> 
        <?php if($is_featured == 'yes'):?>
        <span class="jrStatusIndicators">
        <span title="" class="jrStatusLabel jrStatusFeatured jrBlue">Featured</span>
        </span>
        <?php endif; ?>
      </div>
      <div class="jrOverallRatings">
        <div class="jrOverallUser" title="User rating">
          <?php echo do_shortcode('[comment_rating_display_rating postid="' . $post->ID . '"]')//echo do_shortcode('[comment_rating_display_rating]'); ?>   
        </div>
      </div>
    </div>
    <?php
      endwhile;
    ?>
  </div>
  <?php load_template(plugin_dir_path( __FILE__ ) . '/property-content-map.php'); ?>
</div>
<?php
  // If no content, include the "No posts found" template.
  else :
   load_template(plugin_dir_path( __FILE__ ) . '/property-content-none.php');  
  endif;
  ?>
<div class="jrTableGrid jrPagination jrPaginationBottom" data-ajax="1" data-push="1">
  <div class="jrCol4 jrPagenavResults"> 
    <?php if($count > 0): ?>
    <span class="jrPagenavResultsText"><?php echo $count; ?> results - showing <?php echo $from_to; ?></span>
    <?php endif; ?>
  </div>
  <div class="jrCol4 jrPagenavPages">
    <div class="jrButtonGroup fwd-flex-no-wrap"> 
      <?php
        echo do_shortcode("[WP_Property_Archieve_shortcode pagerange=" . $wp_query->max_num_pages . "]"); 
        wp_reset_postdata();        
      ?>   
    </div>
  </div>
  <div class="jrCol4 jrPagenavLimit">
  </div>
</div>