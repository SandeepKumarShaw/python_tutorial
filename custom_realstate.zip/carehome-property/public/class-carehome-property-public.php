<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */
class Carehomesdirect_Property_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		//if ( get_post_type() == 'property' ) {
	        if ( is_single() || get_post_type() == 'property' || is_page('property-advanced-search') || is_post_type_archive( 'property' ) || is_page('your-listings') || is_page('add-your-care-home-property') || is_page('upgrade-membership') || is_page('property-map-search') || is_page('update-property') || is_page('property-sign-up') ) {

				wp_enqueue_style( $this->plugin_name . '-theme', plugin_dir_url( __FILE__ ) . 'css/theme_css/theme.min.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name . '-tmagnific-popup', plugin_dir_url( __FILE__ ) . 'css/theme_css/magnific/magnific-popup.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name . '-trix', plugin_dir_url( __FILE__ ) . 'css/theme_css/trix/trix.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name . '-galleria.classic', plugin_dir_url( __FILE__ ) . 'css/theme_css/galleria/galleria.classic.css', array(), $this->version, 'all' );

				//wp_enqueue_style( $this->plugin_name . '-video-js', plugin_dir_url( __FILE__ ) . 'css/theme_css/video-js/video-js.min.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name . '-custom_styles_nocache', plugin_dir_url( __FILE__ ) . 'css/theme_css/custom_styles_nocache.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/carehome-property-public.css', array(), $this->version, 'all' );

				wp_enqueue_style( $this->plugin_name . '-custom_styles_geomaps', plugin_dir_url( __FILE__ ) . 'css/theme_css/geomaps.min.css', array(), $this->version, 'all' );

				//wp_enqueue_style( $this->plugin_name . '-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), $this->version, 'all' );
			}
		//}

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		//if ( get_post_type() == 'property' ) {
	        if ( is_single() || get_post_type() == 'property' || is_post_type_archive( 'property' ) || is_page('add-your-care-home-property') || is_page('update-property')) {

		        wp_enqueue_script( $this->plugin_name . '-jquery-ui-1-js', plugin_dir_url( __FILE__ ) . 'js/jquery-ui-1.12.1/jquery-ui.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-jreviews-all-js', plugin_dir_url( __FILE__ ) . 'js/jreviews-all.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-jquery-magnific-popup-js', plugin_dir_url( __FILE__ ) . 'js/jquery/jquery.magnific-popup.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-jquery-bxslider-min-js', plugin_dir_url( __FILE__ ) . 'js/bxslider-4/jquery.bxslider.min.js', array( 'jquery' ), $this->version, true );
				//wp_enqueue_script( $this->plugin_name . '-ui-stars-min', plugin_dir_url( __FILE__ ) . 'js/jquery/ui.stars.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-trix-js', plugin_dir_url( __FILE__ ) . 'js/trix/trix.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-galleria-js', plugin_dir_url( __FILE__ ) . 'js/galleria/galleria.min.js', array( 'jquery' ), $this->version, true );
				wp_enqueue_script( $this->plugin_name . '-galleria-classic-js', plugin_dir_url( __FILE__ ) . 'js/galleria/galleria.classic.min.js', array( 'jquery' ), $this->version, true );
				//wp_enqueue_script( $this->plugin_name . '-video-js-min', plugin_dir_url( __FILE__ ) . 'js/video-js/video.min.js', array( 'jquery' ), $this->version, true );
		        wp_enqueue_script( $this->plugin_name . '-geomaps-min-js', plugin_dir_url( __FILE__ ) . 'js/geomaps.min.js', array( 'jquery' ), $this->version, true );
		         



				wp_enqueue_script( $this->plugin_name . '-carehome-property-public-js', plugin_dir_url( __FILE__ ) . 'js/carehome-property-public.js', array( 'jquery' ), $this->version, true );
			}
		//}

	}	
	public function include_template_function( $template_path ) {
	   if ( get_post_type() == 'property' ) {
	        if ( is_single() ) {
	            // checks if the file exists in the theme first,
	            // otherwise serve the file from the plugin
	            if ( $theme_file = locate_template( array ( 'single-property.php' ) ) ) {
	                $template_path = $theme_file;
	            } else {
	                $template_path = plugin_dir_path( __FILE__ ) . '/partials/single-property.php';
	            }
	        }
	    }
	    return $template_path;
	}
	public function contact_send_ajax_request(){
		if ( isset($_REQUEST) ) {

			$vistor_name = $_REQUEST['name'] ;
			$vistor_phone = $_REQUEST['jr_phn'] ;
			$vistor_email = $_REQUEST['jr_email'] ;
			$vistor_msg = $_REQUEST['jr_msg'] ;
			$author_mail = $_REQUEST['authorMail'] ;
			$listingName = $_REQUEST['listingName'] ;

			$to = $author_mail;
			$subject = "$listingName | Inquiry | Carehomes";
			$txt = "<strong>Name :</strong>" . $vistor_name . "<br><strong>Phone :</strong>" . $vistor_phone . "<br><strong>Email :</strong>" . $vistor_email . "<br><strong>listing Name :</strong>" . $listingName . "<br><strong>Message :</strong>" . $vistor_msg;
			$headers[] = "From: Info <info@carehomesdirect.com>";
			$headers[] = 'Content-Type: text/html; charset=UTF-8';


			if(wp_mail( $to, $subject, $txt, $headers )){
			   echo "<span style='color:green;'>Your message has been sent.</span>" ;
			}else{
			    echo "Some Error Ocuured";
			}

	    } 
	    die;
	}
	public function count_post_visits() {
		if ( get_post_type() == 'property' ) {
			 if( is_single() ) {
				 global $post;
				 $views = get_post_meta( $post->ID, 'my_post_viewed', true );
				 if( $views == '' ) {
					 update_post_meta( $post->ID, 'my_post_viewed', '1' ); 
				 } else {
					 $views_no = intval( $views );
					 update_post_meta( $post->ID, 'my_post_viewed', ++$views_no );
				 }
			 }
		}
	}
}