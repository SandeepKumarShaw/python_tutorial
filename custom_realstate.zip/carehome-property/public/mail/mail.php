<?php

add_action( 'wp_ajax_nopriv_contact_send_ajax_request', 'contact_send_ajax_request' );

add_action( 'wp_ajax_contact_send_ajax_request', 'contact_send_ajax_request' );
function contact_send_ajax_request() {
	if ( isset($_REQUEST) ) {

		$vistor_name = $_REQUEST['name'] ;
		$vistor_phone = $_REQUEST['phone'] ;
		$vistor_email = $_REQUEST['email'] ;
		$vistor_msg = $_REQUEST['msg'] ;
		$author_mail = $_REQUEST['authorMail'] ;
		$listingName = $_REQUEST['listingName'] ;

		$to = $author_mail;
		$subject = "$listingName | Inquiry | Carehomes";
		$txt = "<strong>Name :</strong> $vistor_name <br><strong>Phone :</strong> $vistor_phone <br><strong>Email :</strong> $vistor_email <br><strong>Message :</strong> $vistor_msg ";
		$headers[] = "From: Info <info@carehomesdirect.com>";
		$headers[] = 'Content-Type: text/html; charset=UTF-8';


		if(wp_mail( $to, $subject, $txt, $headers )){
		   echo "<span style='color:green;'>Your message has been sent.</span>" ;
		}else{
		    echo "Some Error Ocuured";
		}

    }     
}

?>