<?php
class Custom_Post_Search_Widget extends WP_Widget {
	public function __construct() {
	    parent::__construct(
	      false,
	      'Custom Property Search',
	      array( 'description' => 'My Custom Search Widget For Property' )
	    );
	}
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
	}	
	public function form( $instance ) {

	}
	public function widget( $args, $instance ) {
		echo $args['before_widget'];		
		require_once plugin_dir_path( __FILE__ ) . 'partials/form/search-form.php';
		echo $args['after_widget'];
	}

}	