<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin 
 */
class Carehomesdirect_Property_User {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */


	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style( 'carehome-property-user-'.$this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/carehome-property-user.css', array(), $this->version, 'all' );
		if(is_page('property-sign-up')){
			wp_enqueue_style( 'carehome-property-sign-up-'.$this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/userprofiles.min.css', array(), $this->version, 'all' );
			//wp_enqueue_style( 'carehome-property-bootstrap-sign-up-'.$this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );

		}


	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		//wp_localize_script( 'example-ajax-script', 'example_ajax_obj', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

		    //wp_enqueue_media();

       //wp_enqueue_script($this->plugin_name . '-jquery-tinymce-user', plugin_dir_url(__FILE__) . 'js/tinymce.min.js', array('jquery'), $this->version, false);
		if(is_page('add-your-care-home-property') || is_page('update-property')){

	        wp_enqueue_script($this->plugin_name . '-jquery-ckeditor-user', 'https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js', array('jquery'), $this->version, false);
	    }


	   wp_enqueue_script($this->plugin_name . '-jquery-validate-user', plugin_dir_url(__FILE__) . 'js/jquery.validate.min.js', array('jquery'), $this->version, false);


	   wp_enqueue_script($this->plugin_name . 'stripe-validation-js', 'https://js.stripe.com/v2/', '', $this->version, false );

	   	wp_enqueue_script($this->plugin_name . '-sweetalert-js-front', plugin_dir_url( __FILE__ ) . 'js/sweetalert.js', array('jquery'), $this->version, false);


	   wp_enqueue_script($this->plugin_name . 'user-ajax-js', plugin_dir_url( __FILE__ ) . 'js/carehome-property-user.js', array( 'jquery' ), $this->version, false );

	   // wp_localize_script( $this->plugin_name . 'user-ajax-js', 'ajax_params_user', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

	}
	public function welcome_dashboard_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			//var_dump($user_details);
			$user_id = $user_details->ID;	
			$user_role = $user_details->roles[0];
				//if($user_role == 'subscriber') {
				    require_once plugin_dir_path( __FILE__ ) . 'partials/dashboard.php';
				   // echo "Hello World";
			    //}		
		}else{
			$redirect_to = site_url() .'/property-sign-up/';
		    wp_redirect($redirect_to);
		}
		
	}
	public function upgrade_membership_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			//var_dump($user_details);
			$user_id = $user_details->ID;	
			$user_role = $user_details->roles[0];
				//if($user_role == 'subscriber') {
				    require_once plugin_dir_path( __FILE__ ) . 'partials/upgrade_membership.php';
				   // echo "Hello World";
			   // }		
		}else{
			$redirect_to = site_url() .'/property-sign-up/';
		    wp_redirect($redirect_to);
		}
		
	}
	public function your_listings_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			//var_dump($user_details);
			$user_id = $user_details->ID;	
			$user_role = $user_details->roles[0];
				//if($user_role == 'subscriber') {
				    require_once plugin_dir_path( __FILE__ ) . 'partials/your_listings.php';
				   // echo "Hello World";
			   // }		
		}else{
			$redirect_to = site_url() .'/property-sign-up/';
		    wp_redirect($redirect_to);
		}
		
	}
	public function add_your_care_home_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			//var_dump($user_details);
			$user_id = $user_details->ID;	
			$user_role = $user_details->roles[0];
				//if($user_role == 'subscriber') {
				    require_once plugin_dir_path( __FILE__ ) . 'partials/add_property.php';
				   // echo "Hello World";
			    //}		
		}else{
			$redirect_to = site_url() .'/property-sign-up/';
		    wp_redirect($redirect_to);
		}
		
	}
	public function edit_your_care_home_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			//var_dump($user_details);
			$user_id = $user_details->ID;	
			$user_role = $user_details->roles[0];
				//if($user_role == 'subscriber') {
				    require_once plugin_dir_path( __FILE__ ) . 'partials/edit_property.php';
				   // echo "Hello World";
			    //}		
		}else{
			$redirect_to = site_url() .'/property-sign-up/';
		    wp_redirect($redirect_to);
		}
		
	}	
	public function wp_property_my_acccount(){
		if( is_user_logged_in() ) {		
			$redirect_to = site_url() .'/welcome-dashboard-user/';
		   // wp_redirect($redirect_to);
		    echo'<script> window.location="' . $redirect_to . '"; </script> ';
		    //exit;
		}else{
		    require_once plugin_dir_path( __FILE__ ) . 'partials/my_account.php';
		}
	}
	public function stripe_membership_payment(){
		require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';


	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    $livemode = $stripeOption['is_live_0'];
	    if(isset($livemode) && $livemode === 'is_live_0'){
	       $publishable_key = $stripeOption['api_publishable_key_1'];
	       $secret_key      = $stripeOption['api_secret_key_2'];
	    }else{
	       $publishable_key = $stripeOption['api_publishable_key_test_3'];
	       $secret_key      = $stripeOption['api_secret_key_test_4'];
	    }

		$cardNumber = $_REQUEST['cardNumber'];
		$cardCVC = $_REQUEST['cardCVC'];
		$cardHolder = $_REQUEST['cardHolder'];
		$expMonth = $_REQUEST['expMonth'];
		$expYear = $_REQUEST['expYear'];
		$planid = $_REQUEST['plan'];
		$price = $_REQUEST['price'];
		$interval = $_REQUEST['interval'];
		$nickname = $_REQUEST['nickname'];

		$user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;

		//print_r($_REQUEST);



		if($price > 500){
			$plimit = 10000;
		}else{
			$plimit = 10;
		}
		$stripe = [
		    "secret_key"      => $secret_key,
		    "publishable_key" => $publishable_key,
		];

		  \Stripe\Stripe::setApiKey($stripe['secret_key']);
		  $email  = $user_details->user_email;

		   $token = \Stripe\Token::create(array(
			  "card" => array(
			    "number" => $cardNumber,
			    "exp_month" => $expMonth,
			    "exp_year" => $expYear,
			    "cvc" => $cardCVC
			  )
			));	

		  $customer = \Stripe\Customer::create([
		      'email' => $email,
		      'source'  => $token,
		  ]);

		   $subscription = \Stripe\Subscription::create(array(
		      "customer" => $customer->id,
		      "items" => array(
		          array(
		              "plan" => $planid,
		          ),
		      ),
		  ));

		   $subsId = $subscription->id;

		    update_user_meta( $user_id, 'property_upgrade_membership', $plimit );
            update_user_meta( $user_id, 'property_upgrade_membership_payment', $price );
            update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', $nickname );
            update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', $subsId );
            update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', $planid );


		  echo '<h1>Successfully charged $'.$price.'!</h1>';

		  die();


	    
	}
	public function stripe_membership_payment_upgrade(){

		require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    $livemode = $stripeOption['is_live_0'];
	    if(isset($livemode) && $livemode === 'is_live_0'){
	       $publishable_key = $stripeOption['api_publishable_key_1'];
	       $secret_key      = $stripeOption['api_secret_key_2'];
	    }else{
	       $publishable_key = $stripeOption['api_publishable_key_test_3'];
	       $secret_key      = $stripeOption['api_secret_key_test_4'];
	    }
	    $user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;

		$plan_id = $_REQUEST['plan_id'];
		$sub_id = $_REQUEST['sub_id'];

		$nplan_id = 'plan_GAIn3n7fK9XpQD';

		$stripe = [
			"secret_key"      => $secret_key,
			"publishable_key" => $publishable_key,
		];
		\Stripe\Stripe::setApiKey($stripe['secret_key']);

		$subscription = \Stripe\Subscription::retrieve($sub_id);
		\Stripe\Subscription::update($sub_id, [
		  'cancel_at_period_end' => false,
		  'items' => [
		    [
		      'id' => $subscription->items->data[0]->id,
		      'plan' => $nplan_id,
		    ],
		  ],
		]);

		$plan = \Stripe\Plan::retrieve($nplan_id);
		$price = $plan["amount"]/100;
		$nickname = $plan["nickname"];
		$subsId = $sub_id;		
		$plimit = 1000;

		update_user_meta( $user_id, 'property_upgrade_membership', $plimit );
		update_user_meta( $user_id, 'property_upgrade_membership_payment', $price );
		update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', $nickname );
		update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', $subsId );
		update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', $nplan_id );


		echo '<h1>Successfully Updated the Plan</h1>';
		die();
	}
	public function stripe_membership_payment_cancel(){

		require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    $livemode = $stripeOption['is_live_0'];
	    if(isset($livemode) && $livemode === 'is_live_0'){
	       $publishable_key = $stripeOption['api_publishable_key_1'];
	       $secret_key      = $stripeOption['api_secret_key_2'];
	    }else{
	       $publishable_key = $stripeOption['api_publishable_key_test_3'];
	       $secret_key      = $stripeOption['api_secret_key_test_4'];
	    }
	    $user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;

		//$plan_id = $_REQUEST['plan_id'];
		$sub_id = $_REQUEST['sub_id'];
		if(isset($sub_id) && ($sub_id !=0 || $sub_id !='0')){
			$stripe =   [
							"secret_key"      => $secret_key,
							"publishable_key" => $publishable_key,
						];
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			$subscription = \Stripe\Subscription::retrieve($sub_id);
			$cancel = $subscription->delete();
			update_user_meta( $user_id, 'property_upgrade_membership', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_payment', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', 0 );
		}else{
			update_user_meta( $user_id, 'property_upgrade_membership', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_payment', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', 0 );
			update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', 0 );
		}
		echo '<h1>Successfully Updated the Plan</h1>';
		die();
	}
	// numbered pagination
	public function userPropertyListingPagination($page) {
        $big = 999999999; 
        echo paginate_links(
            array(
	            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	            'format' => '?paged=%#%',
	            'current' => max( 1, get_query_var('paged') ),
	            'total' => $page,
	            'prev_text'       => __('&laquo;'),
                'next_text'       => __('&raquo;')

	        )
        );

	}
	public function Property_User_Archieve_shortcode($atts){
		return $this->userPropertyListingPagination($atts['pagerange']);
	}
	public function Add_Property_User_Submit(){



		$Listing_title = $_POST['Listing_title'];

		$cat_ids = $_POST['pcategory'];


		$contactInfo_phone_number = $_POST['contactInfo_phone_number'];
		$contactInfo_license = $_POST['contactInfo_license'];
		$contactInfo_website_url = $_POST['contactInfo_website_url'];


		$pro_location_address = $_POST['pro_location_address'];
		$pro_location_city = $_POST['pro_location_city'];
		$pro_location_state = $_POST['pro_location_state'];
		$pro_location_zip_code = $_POST['pro_location_zip_code'];

		$feature_listings = $_POST['feature_listing'];

		$amenities = $_POST['amenities'];
		$amni = explode(",",$amenities);
		$services = $_POST['services'];
		$servi = explode(",",$services);
		$languages_spoken = $_POST['languages_spoken'];
        $language = explode(",",$languages_spoken);
		$private_rooms = $_POST['private_rooms'];
		$shared_rooms = $_POST['shared_rooms'];

		$private_room_costmonth = $_POST['private_room_costmonth'];
		$shared_room_costmonth = $_POST['shared_room_costmonth'];
		$Listing_fulltext = $_POST['Listing_fulltext'];
		$Listing_video = $_POST['Listing_video'];

		$user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;

		$userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
		$user = get_userdata( $user_id );
	    if(!empty( $user ) && $user){     
	        if ( in_array( 'subscriber', $user->roles ) && ($userPlan > 0 || $userPlan !='0' || $userPlan != 0) ) {
		        $feature_listing = 'yes';
	        }else{
		     	$feature_listing = 'no';
	        }
	    }

		$post = array( //our wp_insert_post args
            'post_title'    => wp_strip_all_tags($Listing_title),
            'post_content'  => $Listing_fulltext,
            //'post_category' => array('0' => $_POST['cat']),
            //'tax_input' => array('thread_tag' => $tags),
            'post_status'   => 'publish',
            'post_type' => 'property',
            'post_author'   => $user_id
            );

        $post_id = wp_insert_post($post); 

        update_post_meta( $post_id, 'pro_location_address', $pro_location_address );
		update_post_meta( $post_id, 'pro_location_city', $pro_location_city);
		update_post_meta( $post_id, 'pro_location_state', $pro_location_state );
		update_post_meta( $post_id, 'pro_location_zip_code', $pro_location_zip_code );

		update_post_meta( $post_id, 'private_rooms', $private_rooms );
		update_post_meta( $post_id, 'shared_rooms', $shared_rooms );
		update_post_meta( $post_id, 'private_room_costmonth', $private_room_costmonth );
		update_post_meta( $post_id, 'shared_room_costmonth', $shared_room_costmonth );
		update_post_meta( $post_id, 'property_video', $Listing_video );

		update_post_meta( $post_id, 'amenities', $amni );
		update_post_meta( $post_id, 'services', $servi );
		update_post_meta( $post_id, 'languages_spoken', $language );

		update_post_meta( $post_id, 'contactInfo_phone_number', $contactInfo_phone_number );
		update_post_meta( $post_id, 'contactInfo_license', $contactInfo_license );
		update_post_meta( $post_id, 'contactInfo_website_url', $contactInfo_website_url );
		update_post_meta( $post_id, '_is_featured', $feature_listing );


		wp_set_post_terms($post_id, $cat_ids, 'category');

		$prepAddr = str_replace(' ','+',$pro_location_address);
        $geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&key=AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ');
        $output= json_decode($geocode);
        $latitude = $output->results[0]->geometry->location->lat;
        $longitude = $output->results[0]->geometry->location->lng;

        update_post_meta( $post_id, 'proerty_lat', $latitude );

		update_post_meta( $post_id, 'property_long', $longitude );



	  require_once(ABSPATH . "wp-admin" . '/includes/image.php');
	  require_once(ABSPATH . "wp-admin" . '/includes/file.php');
	  require_once(ABSPATH . "wp-admin" . '/includes/media.php');

	  $upload = wp_upload_bits($_FILES["pro_img"]["name"], null, file_get_contents($_FILES["pro_img"]["tmp_name"]));
     
    $filename = $upload['file'];
    $wp_filetype = wp_check_filetype($filename, null );
    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment( $attachment, $filename, $post_id );
    $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
    wp_update_attachment_metadata( $attach_id, $attach_data );
    set_post_thumbnail( $post_id, $attach_id );

    

    if (!empty($_FILES['add_propertymedia']['name'][0])) {    
        $files = $_FILES['add_propertymedia'];
        $count = 0;
        $galleryImages = array();
        foreach ($files['name'] as $count => $value) {
            if ($files['name'][$count]) {
                $file = array(
                    'name'     => $files['name'][$count],
                    'type'     => $files['type'][$count],
                    'tmp_name' => $files['tmp_name'][$count],
                    'error'    => $files['error'][$count],
                    'size'     => $files['size'][$count]
                );
                $upload_overrides = array( 'test_form' => false );
                $upload = wp_handle_upload($file, $upload_overrides);
                // $filename should be the path to a file in the upload directory.
                $filename = $upload['file'];
                // The ID of the post this attachment is for.
                $parent_post_id = $post_id;
                // Check the type of tile. We'll use this as the 'post_mime_type'.
                $filetype = wp_check_filetype( basename( $filename ), null );
                // Get the path to the upload directory.
                $wp_upload_dir = wp_upload_dir();
                // Prepare an array of post data for the attachment.
                $attachment = array(
                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
                    'post_mime_type' => $filetype['type'],
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );
                // Insert the attachment.
                $attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
                wp_update_attachment_metadata( $attach_id, $attach_data );
                array_push($galleryImages, $attach_id);
            }
            $count++;
            // add images to the gallery field
            update_field('field_5da56e09db77a', $galleryImages, $post_id);

        }
    }
	die();
	}
	public function update_Property_User_Submit(){

		require_once(ABSPATH . "wp-admin" . '/includes/image.php');
        require_once(ABSPATH . "wp-admin" . '/includes/file.php');
        require_once(ABSPATH . "wp-admin" . '/includes/media.php');

		$post_id = $_POST['post_id'];
		$feature_listings = $_POST['feature_listing'];		
        $Listing_title = $_POST['Listing_title'];
		$contactInfo_phone_number = $_POST['contactInfo_phone_number'];
		$contactInfo_license = $_POST['contactInfo_license'];
		$contactInfo_website_url = $_POST['contactInfo_website_url'];


		$pro_location_address = $_POST['pro_location_address'];
		$pro_location_city = $_POST['pro_location_city'];
		$pro_location_state = $_POST['pro_location_state'];
		$pro_location_zip_code = $_POST['pro_location_zip_code'];

		$amenities = $_POST['amenities'];
		$amni = explode(",",$amenities);
		$services = $_POST['services'];
		$servi = explode(",",$services);
		$languages_spoken = $_POST['languages_spoken'];
        $language = explode(",",$languages_spoken);
		$private_rooms = $_POST['private_rooms'];
		$shared_rooms = $_POST['shared_rooms'];

		$cat_ids = $_POST['pcategory'];

		$private_room_costmonth = $_POST['private_room_costmonth'];
		$shared_room_costmonth = $_POST['shared_room_costmonth'];
		$Listing_fulltext = $_POST['Listing_fulltext'];
		$Listing_video = $_POST['Listing_video'];

		$user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;

		$userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
		$user = get_userdata( $user_id );
	    if(!empty( $user ) && $user){     
	        if ( in_array( 'subscriber', $user->roles ) && ($userPlan > 0 || $userPlan !='0' || $userPlan != 0) ) {
		        $feature_listing = 'yes';
	        }else{
		     	$feature_listing = 'no';
	        }
	    }




		$post = array( //our wp_insert_post args
			'ID'             => esc_sql($post_id),
            'post_title'    => wp_strip_all_tags($Listing_title),
            'post_content'  => $Listing_fulltext,
            //'post_category' => array('0' => $_POST['cat']),
            //'tax_input' => array('thread_tag' => $tags),
            'post_status'   => 'publish',
            'post_type' => 'property',
            'post_author'   => $user_id
            );

        $post_id = wp_update_post($post); 

        update_post_meta( $post_id, 'pro_location_address', $pro_location_address );
		update_post_meta( $post_id, 'pro_location_city', $pro_location_city);
		update_post_meta( $post_id, 'pro_location_state', $pro_location_state );
		update_post_meta( $post_id, 'pro_location_zip_code', $pro_location_zip_code );

		update_post_meta( $post_id, '_is_featured', $feature_listing );


		update_post_meta( $post_id, 'private_rooms', $private_rooms );
		update_post_meta( $post_id, 'shared_rooms', $shared_rooms );
		update_post_meta( $post_id, 'private_room_costmonth', $private_room_costmonth );
		update_post_meta( $post_id, 'shared_room_costmonth', $shared_room_costmonth );
		update_post_meta( $post_id, 'property_video', $Listing_video );

		update_post_meta( $post_id, 'amenities', $amni );
		update_post_meta( $post_id, 'services', $servi );
		update_post_meta( $post_id, 'languages_spoken', $language );

		update_post_meta( $post_id, 'contactInfo_phone_number', $contactInfo_phone_number );
		update_post_meta( $post_id, 'contactInfo_license', $contactInfo_license );
		update_post_meta( $post_id, 'contactInfo_website_url', $contactInfo_website_url );

		wp_set_post_terms($post_id, $cat_ids, 'category');

		$prepAddr = str_replace(' ','+',$pro_location_address);
        $geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&key=AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ');
        $output= json_decode($geocode);
        $latitude = $output->results[0]->geometry->location->lat;
        $longitude = $output->results[0]->geometry->location->lng;

        update_post_meta( $post_id, 'proerty_lat', $latitude );

		update_post_meta( $post_id, 'property_long', $longitude );





        if(isset($_FILES['pro_img']['name'])){
	        $upload = wp_upload_bits($_FILES["pro_img"]["name"], null, file_get_contents($_FILES["pro_img"]["tmp_name"]));     
		    $filename = $upload['file'];
		    $wp_filetype = wp_check_filetype($filename, null );
		    $attachment = array(
		        'post_mime_type' => $wp_filetype['type'],
		        'post_title' => sanitize_file_name($filename),
		        'post_content' => '',
		        'post_status' => 'inherit'
		    );
		    $attach_id = wp_insert_attachment( $attachment, $filename, $post_id );
		    $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
		    wp_update_attachment_metadata( $attach_id, $attach_data );
		    set_post_thumbnail( $post_id, $attach_id );
        }    

    if (isset($_FILES['add_propertymedia']['name'])) {    
        $files = $_FILES['add_propertymedia'];
        $count = 0;
        $galleryImages = array();
        foreach ($files['name'] as $count => $value) {
            if ($files['name'][$count]) {
                $file = array(
                    'name'     => $files['name'][$count],
                    'type'     => $files['type'][$count],
                    'tmp_name' => $files['tmp_name'][$count],
                    'error'    => $files['error'][$count],
                    'size'     => $files['size'][$count]
                );
                $upload_overrides = array( 'test_form' => false );
                $upload = wp_handle_upload($file, $upload_overrides);
                // $filename should be the path to a file in the upload directory.
                $filename = $upload['file'];
                // The ID of the post this attachment is for.
                $parent_post_id = $post_id;
                // Check the type of tile. We'll use this as the 'post_mime_type'.
                $filetype = wp_check_filetype( basename( $filename ), null );
                // Get the path to the upload directory.
                $wp_upload_dir = wp_upload_dir();
                // Prepare an array of post data for the attachment.
                $attachment = array(
                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
                    'post_mime_type' => $filetype['type'],
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );
                // Insert the attachment.
                $attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
                $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
                wp_update_attachment_metadata( $attach_id, $attach_data );
                array_push($galleryImages, $attach_id);
            }
            $count++;
            // add images to the gallery field
            update_field('field_5da56e09db77a', $galleryImages, $post_id);

        }
    }
	die();
	}
	public function delete_Property_User_Submit(){
		$post_id = $_POST['id'];
		wp_delete_post( $post_id );
        echo 'success';
        die();
	}  
	public function ClaimListingProcess(){
		global $wpdb; 
		$response = array();
		$table_name = $wpdb->prefix . 'claim_details';

		$user_id = $_POST['listing_user_id'];
		$property_id = $_POST['listing_post_id'];
		$name = $_POST['listing_name'];
		$emailid = $_POST['listing_email'];
		$message = $_POST['listing_message'];

		$sql = "SELECT  COUNT(*) FROM " . $table_name . " WHERE user_id = '" . $user_id . "' AND property_id = '" . $property_id . "'";
		$results = $wpdb->get_var($sql);
		if($results == 0){
			$sql = "INSERT INTO " . $table_name . " (`user_id`, `property_id`,`name`,`emailid`,`message`) values ('" . $user_id . "', '". $property_id . "', '" . $name . "', '" . $emailid . "', '" . $message . "')";
		    $result = $wpdb->query($sql);
	        if($result){
				$to = get_option('admin_email');

				$subject = "Claim Listing | Inquiry | Carehomes";
				$txt = "<strong>Name :</strong> $name <br><strong>Email :</strong> $emailid <br><strong>Message :</strong> $message ";
				$headers[] = "From: Info <info@carehomesdirect.com>";
				$headers[] = 'Content-Type: text/html; charset=UTF-8';

				if(wp_mail( $to, $subject, $txt, $headers )){
				   $response['reg_status'] = true;	
				   $response['success'] = __('You have successfully Claim the property.', $this->plugin_name);
				   
				}else{
					$response['reg_status'] = false;
					$response['error'] = __('Some Error Ocuured.', $this->plugin_name);
				}
	        }else{
	        	$response['reg_status'] = false;
	        	$response['error'] = __('Some Error Ocuured.', $this->plugin_name);
	        }

		}else{
			$response['reg_status'] = false;
			$response['error'] = __('You have Already Claim this property!.', $this->plugin_name);
		}
		wp_send_json($response);

		die();
	} 
	public function PropertyLoginProcess(){
		//print_r($_POST);

		$info = array();
	    $info['user_login'] = $_POST['prop_wpmp_email1'];
	    $info['user_password'] = $_POST['prop_wpmp_password1'];
	    $info['remember'] = true;

	    $user_signon = wp_signon( $info, false );
	    if ( is_wp_error($user_signon) ){
	        echo json_encode(array('loggedin'=>false, 'message'=>__('Wrong username or password.')));
	    } else {
	        echo json_encode(array('loggedin'=>true, 'message'=>__('Login successful, redirecting...')));
	    }
        die();
	}
	public function PropertyRegistrationProcess(){
		//print_r($_POST);
		$prop_redirection_url = $_POST['prop_redirection_url'];
		$prop_wpmp_fname = $_POST['prop_wpmp_fname'];
		$prop_wpmp_email = $_POST['prop_wpmp_email'];
		$prop_wpmp_password = $_POST['prop_wpmp_password'];

		$response = array();

       // checking post data
        if (isset($_POST) && $_POST) {
        	$exists = $this->property_email_exists( $prop_wpmp_email );
			if ( $exists ) {
				$response['reg_status'] = false;
				$response['error'] = __('This E-mail is Already registered.', $this->plugin_name);
			} else {
				    
				// preparing user array and added required filters
	            $userdata = array(
	                'user_login' => apply_filters('pre_user_login', trim($prop_wpmp_email)),
	                'user_pass' => apply_filters('pre_user_pass', trim($prop_wpmp_password)),
	                'user_email' => apply_filters('pre_user_email', trim($prop_wpmp_email)),
	                'first_name' => apply_filters('pre_user_first_name', trim($prop_wpmp_fname)),
	                'role' => get_option('default_role'),
	                'user_registered' => date('Y-m-d H:i:s')
	            );
	            // creating new user
	            $user_id = wp_insert_user($userdata);            
	            update_user_meta( $user_id, 'property_upgrade_membership', 0 );
	            update_user_meta( $user_id, 'property_upgrade_membership_payment', 0 );
	            update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', 0 );
	            update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', 0 );
	            update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', 0 );

	            // checking for errors while user registration
	            if (is_wp_error($user_id)) {
	                $response['error'] = $user_id->get_error_message();
	            }else {
	                // Adding hook so that anyone can add action on user registration
	                do_action('user_register', $user_id);

	                wp_set_auth_cookie( $user_id );
	                wp_set_current_user( $user_id );

	                $response['reg_status'] = true;
	                $this->property_user_registration_mail($userdata);
	                $response['success'] = __('You are successfully registered.', $this->plugin_name);
	              
	            }
			}    
            // sending back the response in right header
            wp_send_json($response);
        }

        die();
	}
	public function property_email_exists( $email ) {
	    $user = get_user_by( 'email', $email );
	    if ( $user ) {
	        return $user->ID;
	    }
	    return false;
	}
	public function property_user_registration_mail($userdata){

   
        $to['admin'] = get_option('admin_email');

        $subject['admin'] = get_option('blogname') . ' | New user registered';

        // using content type html for emails
        $headers = array('Content-Type: text/html; charset=UTF-8');

        //Make body of admin message
        $userprofile.= '<br><strong>' . __('Username : ') . '</strong>' . $userdata['user_email'];
        $userprofile.= '<br><strong>' . __('Email : ') . '</strong>' . $userdata['user_email'];

        $message['admin'] = sprintf(__('A new user has registered on %s with following details:'), get_option('blogname'));

      

        $footer['admin'] = '<br><br>' . __('Thanks.');

        $body['admin'] = $message['admin'] . $userprofile . $footer['admin'];


        //sending email notification to admin
        wp_mail($to['admin'], $subject['admin'], $body['admin'], $headers);

    } 
	public function my_login_redirect( $redirect_to, $request, $user ) {
	    //is there a user to check?
	    global $user;
	    if ( isset( $user->roles ) && is_array( $user->roles ) ) {

	        if ( in_array( 'subscriber', $user->roles ) ) {
	            // redirect them to the default place
	            $data_login = get_option('welcome_dashboard_page_name');

	            return site_url() .'/welcome-dashboard-user/';
	        }else{
	        	return site_url() .'/wp-admin/';
	        }
	    } else {
	        return $redirect_to;
	    }
	}
}
