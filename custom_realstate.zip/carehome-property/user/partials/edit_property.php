<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/user/partials
  */ 
  
  
  $user_details = new WP_User(get_current_user_id());
  $user_id = $user_details->ID; 
 
  $userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
  $userPay = get_user_meta( $user_id, 'property_upgrade_membership_payment', true );
  $userPayName = get_user_meta( $user_id, 'property_upgrade_membership_payment_plan', true );
  $subscriber_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', true );
  $plan_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', true );
  
  $post_id = $_GET['post'];
  
  //echo $post_id;
   
  ?>
<div class="uk-container">
  <div class="uk-grid uk-grid-divider uk-grid-stack" uk-grid="">
    <div class="uk-width-expand@m uk-first-column">
      <section id="primary">
        <div id="content" role="main">
          <div class="jr-page jr-form-listing-outer jrPage jrListingCreate">
            <div class="jrListingCreateHelp">
              <h1>Submission instructions</h1>
              <ul>
                <li>All form inputs marked <span class="jrIconRequired"></span> are required.</li>
              </ul>
            </div>
            <div id="add-success" class="hidden">
              <i class="fa fa-check"></i>
              <p>Property Updated Successful!</p>
            </div>
            <div class="jrAccountButtons jrClearfix"> <a href="<?php echo site_url() .'/your-listings/'; ?>" class="jrButton jrBlue jrAddListing jrRight"><span class="jrIconAddListing"></span>View All Listings</a></div>
            <form id="jr-form-property-form-edit" class="jr-form-property-form" method="post" action="javascript:void(0);" enctype="multipart/form-data">
              <input type="hidden" name="ajaxUrl_action" id="ajaxUrl_action" value="<?php echo admin_url('admin-ajax.php'); ?>">
              <input type="hidden" name="action" id="action" value="update_Property_User_Submit">
              <input type="hidden" name="post_id" id="post_id" value="<?php echo $post_id;?>">
              <!-- START MAIN DIV -->
              <div class="jr-form-listing-fields jrForm jrFormContainer jrHidden" style="display: block;">
                <fieldset>
                  <div class="jrDataList">
                    <div class="jrCol8">
                      <div class="jrListingTitle jrFieldDiv">
                        <label class="jrLabel">Listing Title<span class="jrIconRequired"></span></label>
                        <input type="text" class="jr-listing-title jrTitle" id="Listing_title" name="Listing_title" value="<?php echo get_the_title( $post_id ); ?>">
                      </div>
                    </div>
                    <div class="jrCol4">
                      <div class="jrListingTitle jrFieldDiv" style="display:none;">
                        <label class="jrLabel">Feature Property</label>
                        <?php
                          $is_featured = get_post_meta($post_id, '_is_featured', TRUE);    
                          
                          
                          ?>
                        <input type="checkbox" class="jr-listing-title jrTitle" id="feature_listing" name="feature_listing" <?php if($is_featured == 'yes'){ echo 'checked'; } ?> value="yes">Yes
                      </div>
                    </div>
                  </div>
                </fieldset>
                <?php
                  //$categories = get_categories(); 
                   $categories=get_categories(array( 'parent' => 17 ));
                  
                  $arr = array();
                  
                  $pcategories = get_the_category($post_id);
                  foreach ($pcategories as $pcategory) {
                    $arr[] = $pcategory->term_id;
                  }  


                  echo '<fieldset id="group_category" class="jrHidden jrFieldsetMargin" style="display: block;">';
                  echo '<legend>Listing Category</legend>';
                  echo '<div class="jrFieldDiv jrServices">';
                  foreach( $categories as $category )
                  {
                    echo '<div class="jr-option jrFieldOption" style="min-width: 324px;">';?>
                <input type="checkbox" name="pcategory[]" id="pcategory" class="jr_services pcategory" data-search="1" value="<?php echo $category->term_id; ?>" <?php if (in_array($category->term_id, $arr)) { echo 'checked';} ?>>
                <?php 
                  echo '<label for="jr_services_bathing-dressing-assistance-search">' . $category->cat_name . '</label>';    
                  echo '</div>';       
                  }
                  echo '</fieldset>';
                  
                  ?>
                <fieldset id="group_location" class="jrHidden jrFieldsetMargin" style="display: block;">
                  <legend>Location</legend>
                  <div class="jrDataList">
                    <div class="jrCol6">
                      <?php 
                        $pro_location_address = get_field( 'pro_location_address', $post_id );                        
                        ?>
                      <div class="jrFieldDiv jrPhonenumber" style="">
                        <label class="jrLabel">Address<span class="jrIconRequired"></span></label>
                        <textarea rows="4" cols="50" id="pro_location_address" name="pro_location_address" class="jr_phonenumber jrText">
                        <?php
                          if($pro_location_address):
                              echo $pro_location_address;
                          endif;
                          ?>                            
                        </textarea>
                      </div>
                    </div>
                    <div class="jrCol6">
                      <?php 
                        $pro_location_state = get_field( 'pro_location_state', $post_id );                       
                        ?>
                      <div class="jrFieldDiv jrPhonenumber" style="">
                        <label class="jrLabel">State<span class="jrIconRequired"></span></label>
                        <input type="text" name="pro_location_state" id="pro_location_state" class="jr_phonenumber jrText" value="<?php 
                          if($pro_location_state):
                              echo $pro_location_state;
                          endif;?>">
                      </div>
                      <div class="jrFieldDiv jrPhonenumber" style="">
                        <label class="jrLabel">City<span class="jrIconRequired"></span></label>
                        <select name="pro_location_city" id="pro_location_city" class="jr_city" data-search="1">
                          <?php 
                            $pro_location_city = get_field( 'pro_location_city', $post_id );
                            
                            $array = array(
                                array("name" => "ADELANTO", "index" => "adelanto"),
                                array("name" => "AGOURA HILLS", "index" => "agoura-hills"),
                                array("name" => "ALAMEDA", "index" => "alameda"),
                                array("name" => "ALAMO", "index" => "alamo"),
                                array("name" => "ALBANY", "index" => "albany"),
                                array("name" => "ALBION", "index" => "albion"),
                                array("name" => "ALHAMBRA", "index" => "alhambra"),
                                array("name" => "Aliso Viejo", "index" => "aliso-viejo"),
                                array("name" => "ALPINE", "index" => "alpine"),
                                array("name" => "ALTA LOMA", "index" => "alta-loma"),
                                array("name" => "ALTADENA", "index" => "altadena"),
                                array("name" => "AMERICAN CANYON", "index" => "american-canyon"),
                                array("name" => "ANAHEIM", "index" => "anaheim"),
                                array("name" => "ANAHEIM HILL", "index" => "anaheim-hill"),
                                array("name" => "ANAHEIM HILLS", "index" => "anaheim-hills"),
                                array("name" => "ANDERSON", "index" => "anderson"),
                                array("name" => "ANGELS CAMP", "index" => "angels-camp"),
                                array("name" => "ANGELUS OAKS", "index" => "angelus-oaks"),
                                array("name" => "ANGWIN", "index" => "angwin"),
                                array("name" => "ANTELOPE", "index" => "antelope"),
                                array("name" => "ANTIOCH", "index" => "antioch"),
                                array("name" => "APPLE VALLEY", "index" => "apple-valley"),
                                array("name" => "APTOS", "index" => "aptos"),
                                array("name" => "ARCADIA", "index" => "arcadia"),
                                array("name" => "ARLETA", "index" => "arleta"),
                                array("name" => "ARROYO GRANDE", "index" => "arroyo-grande"),
                                array("name" => "ARTESIA", "index" => "artesia"),
                                array("name" => "ATASCADERO", "index" => "atascadero"),
                                array("name" => "ATWATER", "index" => "atwater"),
                                array("name" => "AUBURN", "index" => "auburn"),
                                array("name" => "AZUSA", "index" => "azusa"),
                                array("name" => "BAKERSFIELD", "index" => "bakersfield"),
                                array("name" => "BALBOA ISLAND", "index" => "balboa-island"),
                                array("name" => "BALDWIN PARK", "index" => "baldwin-park"),
                                array("name" => "BANNING", "index" => "banning"),
                                array("name" => "BARSTOW", "index" => "barstow"),
                                array("name" => "BAY POINT", "index" => "bay-point"),
                                array("name" => "BAYSIDE", "index" => "bayside"),
                                array("name" => "BEAUMONT", "index" => "beaumont"),
                                array("name" => "BELLA VISTA", "index" => "bella-vista"),
                                array("name" => "BELLFLOWER", "index" => "bellflower"),
                                array("name" => "BELMONT", "index" => "belmont"),
                                array("name" => "BEN LOMOND", "index" => "ben-lomond"),
                                array("name" => "BENICIA", "index" => "benicia"),
                                array("name" => "BERKELEY", "index" => "berkeley"),
                                array("name" => "BERMUDA DUNES", "index" => "bermuda-dunes"),
                                array("name" => "BERMUDAS DUNES", "index" => "bermudas-dunes"),
                                array("name" => "BEVERLY HILLS", "index" => "beverly-hills"),
                                array("name" => "BIG BEAR CITY", "index" => "big-bear-city"),
                                array("name" => "BISHOP", "index" => "bishop"),
                                array("name" => "BLOOMINGTON", "index" => "bloomington"),
                                array("name" => "BOLINAS", "index" => "bolinas"),
                                array("name" => "BONITA", "index" => "bonita"),
                                array("name" => "BONSALL", "index" => "bonsall"),
                                array("name" => "BORREGO SPRINGS", "index" => "borrego-springs"),
                                array("name" => "BRAWLEY", "index" => "brawley"),
                                array("name" => "BREA", "index" => "brea"),
                                array("name" => "BRENTWOOD", "index" => "brentwood"),
                                array("name" => "BROWNS VALLEY", "index" => "browns-valley"),
                                array("name" => "BUENA PARK", "index" => "buena-park"),
                                array("name" => "BURBANK", "index" => "burbank"),
                                array("name" => "BURLINGAME", "index" => "burlingame"),
                                array("name" => "CALABASAS", "index" => "calabasas"),
                                array("name" => "CALIMESA", "index" => "calimesa"),
                                array("name" => "CALISTOGA", "index" => "calistoga"),
                                array("name" => "CAMARILLO", "index" => "camarillo"),
                                array("name" => "CAMBRIA", "index" => "cambria"),
                                array("name" => "CAMERON PARK", "index" => "cameron-park"),
                                array("name" => "CAMINO", "index" => "camino"),
                                array("name" => "CAMPBELL", "index" => "campbell"),
                                array("name" => "CANOGA PARK", "index" => "canoga-park"),
                                array("name" => "CANYON COUNTRY", "index" => "canyon-country"),
                                array("name" => "CANYON LAKE", "index" => "canyon-lake"),
                                array("name" => "CAPISTRANO BEACH", "index" => "capistrano-beach"),
                                array("name" => "CARDIFF BY THE SEA", "index" => "cardiff-by-the-sea"),
                                array("name" => "CARLSBAD", "index" => "carlsbad"),
                                array("name" => "CARMEL", "index" => "carmel"),
                                array("name" => "CARMEL VALLEY", "index" => "carmel-valley"),
                                array("name" => "CARMICHAEL", "index" => "carmichael"),
                                array("name" => "CARPINTERIA", "index" => "carpinteria"),
                                array("name" => "CARSON", "index" => "carson"),
                                array("name" => "CASTAIC", "index" => "castaic"),
                                array("name" => "CASTRO VALLEY", "index" => "castro-valley"),
                                array("name" => "CASTROVILLE", "index" => "castroville"),
                                array("name" => "CATHEDRAL CITY", "index" => "cathedral-city"),
                                array("name" => "CATHEDRAL WAY", "index" => "cathedral-way"),
                                array("name" => "CERES", "index" => "ceres"),
                                array("name" => "CERRITOS", "index" => "cerritos"),
                                array("name" => "CHASTWORTH", "index" => "chastworth"),
                                array("name" => "CHATSWORTH", "index" => "chatsworth"),
                                array("name" => "CHERRY VALLEY", "index" => "cherry-valley"),
                                array("name" => "CHICO", "index" => "chico"),
                                array("name" => "CHINO", "index" => "chino"),
                                array("name" => "CHINO HILLS", "index" => "chino-hills"),
                                array("name" => "CHOWCHILLA", "index" => "chowchilla"),
                                array("name" => "CHULA VISTA", "index" => "chula-vista"),
                                array("name" => "CITRUS HEIGHTS", "index" => "citrus-heights"),
                                array("name" => "CLAREMONT", "index" => "claremont"),
                                array("name" => "CLAYTON", "index" => "clayton"),
                                array("name" => "CLEARLAKE", "index" => "clearlake"),
                                array("name" => "CLOVERDALE", "index" => "cloverdale"),
                                array("name" => "CLOVIS", "index" => "clovis"),
                                array("name" => "COALINGA", "index" => "coalinga"),
                                array("name" => "COARSEGOLD", "index" => "coarsegold"),
                                array("name" => "COLFAX", "index" => "colfax"),
                                array("name" => "COLMA", "index" => "colma"),
                                array("name" => "COLTON", "index" => "colton"),
                                array("name" => "COMPTON", "index" => "compton"),
                                array("name" => "CONCORD", "index" => "concord"),
                                array("name" => "CONTRA COSTA", "index" => "contra-costa"),
                                array("name" => "CORNING", "index" => "corning"),
                                array("name" => "Corona", "index" => "corona"),
                                array("name" => "CORONA DEL MAR", "index" => "corona-del-mar"),
                                array("name" => "CORONADO", "index" => "coronado"),
                                array("name" => "CORRALITOS", "index" => "corralitos"),
                                array("name" => "CORTE MADERA", "index" => "corte-madera"),
                                array("name" => "Costa Mesa", "index" => "costa-mesa"),
                                array("name" => "COTATI", "index" => "cotati"),
                                array("name" => "COULTERVILLE", "index" => "coulterville"),
                                array("name" => "COVINA", "index" => "covina"),
                                array("name" => "CRESCENT CITY", "index" => "crescent-city"),
                                array("name" => "CUDAHY", "index" => "cudahy"),
                                array("name" => "CULVER CITY", "index" => "culver-city"),
                                array("name" => "CUPERTINO", "index" => "cupertino"),
                                array("name" => "CYPRESS", "index" => "cypress"),
                                array("name" => "DALY CITY", "index" => "daly-city"),
                                array("name" => "DANA POINT", "index" => "dana-point"),
                                array("name" => "DANVILLE", "index" => "danville"),
                                array("name" => "DAVIS", "index" => "davis"),
                                array("name" => "DEL MAR", "index" => "del-mar"),
                                array("name" => "DEL REY OAKS", "index" => "del-rey-oaks"),
                                array("name" => "DELANO", "index" => "delano"),
                                array("name" => "DESERT HOT SPRINGS", "index" => "desert-hot-springs"),
                                array("name" => "DIAMOND", "index" => "diamond"),
                                array("name" => "DIAMOND BAR", "index" => "diamond-bar"),
                                array("name" => "DINUBA", "index" => "dinuba"),
                                array("name" => "DIXON", "index" => "dixon"),
                                array("name" => "DOWNEY", "index" => "downey"),
                                array("name" => "DUARTE", "index" => "duarte"),
                                array("name" => "DUBLIN", "index" => "dublin"),
                                array("name" => "EAGLE ROCK", "index" => "eagle-rock"),
                                array("name" => "EAST PALO ALTO", "index" => "east-palo-alto"),
                                array("name" => "EASTVALE", "index" => "eastvale"),
                                array("name" => "EL CAJON", "index" => "el-cajon"),
                                array("name" => "EL CENTRO", "index" => "el-centro"),
                                array("name" => "EL CERRITO", "index" => "el-cerrito"),
                                array("name" => "EL DORADO", "index" => "el-dorado"),
                                array("name" => "EL DORADO HILLS", "index" => "el-dorado-hills"),
                                array("name" => "EL DORADO HILS", "index" => "el-dorado-hils"),
                                array("name" => "EL MONTE", "index" => "el-monte"),
                                array("name" => "EL SOBRANTE", "index" => "el-sobrante"),
                                array("name" => "ELK GROVE", "index" => "elk-grove"),
                                array("name" => "ELVERTA", "index" => "elverta"),
                                array("name" => "EMERALD HILLS", "index" => "emerald-hills"),
                                array("name" => "EMERYVILLE", "index" => "emeryville"),
                                array("name" => "EMPIRE", "index" => "empire"),
                                array("name" => "ENCINITAS", "index" => "encinitas"),
                                array("name" => "ENCINO", "index" => "encino"),
                                array("name" => "ESCALON", "index" => "escalon"),
                                array("name" => "ESCONDIDO", "index" => "escondido"),
                                array("name" => "ESPARTO", "index" => "esparto"),
                                array("name" => "ETNA", "index" => "etna"),
                                array("name" => "EUREKA", "index" => "eureka"),
                                array("name" => "EXETER", "index" => "exeter"),
                                array("name" => "FAIR OAKS", "index" => "fair-oaks"),
                                array("name" => "FAIRFIELD", "index" => "fairfield"),
                                array("name" => "FALLBROOK", "index" => "fallbrook"),
                                array("name" => "FILLMORE", "index" => "fillmore"),
                                array("name" => "FOLSOM", "index" => "folsom"),
                                array("name" => "FONTANA", "index" => "fontana"),
                                array("name" => "FORESTHILL", "index" => "foresthill"),
                                array("name" => "FORESTVILLE", "index" => "forestville"),
                                array("name" => "FORT BRAGG", "index" => "fort-bragg"),
                                array("name" => "FORTUNA", "index" => "fortuna"),
                                array("name" => "FOSTER CITY", "index" => "foster-city"),
                                array("name" => "Fountain Valley", "index" => "fountain-valley"),
                                array("name" => "FOWLER", "index" => "fowler"),
                                array("name" => "FREEDOM", "index" => "freedom"),
                                array("name" => "FREMONT", "index" => "fremont"),
                                array("name" => "FRENCH CAMP", "index" => "french-camp"),
                                array("name" => "FRESNO", "index" => "fresno"),
                                array("name" => "FULLERTON", "index" => "fullerton"),
                                array("name" => "GALT", "index" => "galt"),
                                array("name" => "GARDEN GROVE", "index" => "garden-grove"),
                                array("name" => "GARDENA", "index" => "gardena"),
                                array("name" => "GILROY", "index" => "gilroy"),
                                array("name" => "GLENDALE", "index" => "glendale"),
                                array("name" => "GLENDORA", "index" => "glendora"),
                                array("name" => "GLENN", "index" => "glenn"),
                                array("name" => "GOLD RIVER", "index" => "gold-river"),
                                array("name" => "GOLETA", "index" => "goleta"),
                                array("name" => "GRANADA HILLS", "index" => "granada-hills"),
                                array("name" => "GRAND TERRACE", "index" => "grand-terrace"),
                                array("name" => "GRANDA HILLS", "index" => "granda-hills"),
                                array("name" => "GRANITE BAY", "index" => "granite-bay"),
                                array("name" => "GRASS VALLEY", "index" => "grass-valley"),
                                array("name" => "GREENBRAE", "index" => "greenbrae"),
                                array("name" => "GRENADA", "index" => "grenada"),
                                array("name" => "GRIDLEY", "index" => "gridley"),
                                array("name" => "GROVER BEACH", "index" => "grover-beach"),
                                array("name" => "GUALALA", "index" => "gualala"),
                                array("name" => "HACIENDA HEIGHTS", "index" => "hacienda-heights"),
                                array("name" => "HANFORD", "index" => "hanford"),
                                array("name" => "HARBOR CITY", "index" => "harbor-city"),
                                array("name" => "HAWTHORNE", "index" => "hawthorne"),
                                array("name" => "HAYWARD", "index" => "hayward"),
                                array("name" => "HEALDSBURG", "index" => "healdsburg"),
                                array("name" => "HELENDALE", "index" => "helendale"),
                                array("name" => "HEMET", "index" => "hemet"),
                                array("name" => "HERCULES", "index" => "hercules"),
                                array("name" => "HERMOSA BEACH", "index" => "hermosa-beach"),
                                array("name" => "HESPERIA", "index" => "hesperia"),
                                array("name" => "HIGHLAND", "index" => "highland"),
                                array("name" => "HILMAR", "index" => "hilmar"),
                                array("name" => "HOLLISTER", "index" => "hollister"),
                                array("name" => "HOLTVILLE", "index" => "holtville"),
                                array("name" => "HUGHSON", "index" => "hughson"),
                                array("name" => "HUNTINGTON", "index" => "huntington"),
                                array("name" => "HUNTINGTON BEACH", "index" => "huntington-beach"),
                                array("name" => "IMPERIAL BEACH", "index" => "imperial-beach"),
                                array("name" => "INDIO", "index" => "indio"),
                                array("name" => "INGLEWOOD", "index" => "inglewood"),
                                array("name" => "IONE", "index" => "ione"),
                                array("name" => "Irvine", "index" => "irvine"),
                                array("name" => "JACKSON", "index" => "jackson"),
                                array("name" => "jaipur", "index" => "jaipur"),
                                array("name" => "JAMESTOWN", "index" => "jamestown"),
                                array("name" => "JAMUL", "index" => "jamul"),
                                array("name" => "JOSHUA TREE", "index" => "joshua-tree"),
                                array("name" => "JULIAN", "index" => "julian"),
                                array("name" => "JURUPA VALLEY", "index" => "jurupa-valley"),
                                array("name" => "KELSEYVILLE", "index" => "kelseyville"),
                                array("name" => "KENTFIELD", "index" => "kentfield"),
                                array("name" => "KENWOOD", "index" => "kenwood"),
                                array("name" => "KERMAN", "index" => "kerman"),
                                array("name" => "KERNVILLE", "index" => "kernville"),
                                array("name" => "LA CANADA", "index" => "la-canada"),
                                array("name" => "LA CRESCENTA", "index" => "la-crescenta"),
                                array("name" => "LA HABRA", "index" => "la-habra"),
                                array("name" => "LA HABRA HEIGHTS", "index" => "la-habra-heights"),
                                array("name" => "LA JOLLA", "index" => "la-jolla"),
                                array("name" => "LA MESA", "index" => "la-mesa"),
                                array("name" => "LA MIRADA", "index" => "la-mirada"),
                                array("name" => "LA PALMA", "index" => "la-palma"),
                                array("name" => "LA PUENTE", "index" => "la-puente"),
                                array("name" => "LA QUINTA", "index" => "la-quinta"),
                                array("name" => "LA SELVA BEACH", "index" => "la-selva-beach"),
                                array("name" => "LA VERNE", "index" => "la-verne"),
                                array("name" => "LAFAYETTE", "index" => "lafayette"),
                                array("name" => "LAGUNA BEACH", "index" => "laguna-beach"),
                                array("name" => "LAGUNA HILLS", "index" => "laguna-hills"),
                                array("name" => "LAGUNA NIGUEL", "index" => "laguna-niguel"),
                                array("name" => "LAGUNA WOODS", "index" => "laguna-woods"),
                                array("name" => "LAKE BALBOA", "index" => "lake-balboa"),
                                array("name" => "LAKE ELSINORE", "index" => "lake-elsinore"),
                                array("name" => "LAKE FOREST", "index" => "lake-forest"),
                                array("name" => "LAKEPORT", "index" => "lakeport"),
                                array("name" => "LAKESIDE", "index" => "lakeside"),
                                array("name" => "LAKEWOOD", "index" => "lakewood"),
                                array("name" => "LANCASTER", "index" => "lancaster"),
                                array("name" => "LATHROP", "index" => "lathrop"),
                                array("name" => "LAWNDALE", "index" => "lawndale"),
                                array("name" => "LEMON GROVE", "index" => "lemon-grove"),
                                array("name" => "LEMOORE", "index" => "lemoore"),
                                array("name" => "LINCOLN", "index" => "lincoln"),
                                array("name" => "LITTLE RIVER", "index" => "little-river"),
                                array("name" => "LITTLEROCK", "index" => "littlerock"),
                                array("name" => "LIVERMORE", "index" => "livermore"),
                                array("name" => "LODI", "index" => "lodi"),
                                array("name" => "LOMA LINDA", "index" => "loma-linda"),
                                array("name" => "LOMITA", "index" => "lomita"),
                                array("name" => "LOMPOC", "index" => "lompoc"),
                                array("name" => "LONG BEACH", "index" => "long-beach"),
                                array("name" => "LOOMIS", "index" => "loomis"),
                                array("name" => "LOS ALAMITOS", "index" => "los-alamitos"),
                                array("name" => "LOS ALTOS", "index" => "los-altos"),
                                array("name" => "LOS ANGELES", "index" => "los-angeles"),
                                array("name" => "LOS BANOS", "index" => "los-banos"),
                                array("name" => "LOS GATOS", "index" => "los-gatos"),
                                array("name" => "LOS MOLINOS", "index" => "los-molinos"),
                                array("name" => "LOS OSOS", "index" => "los-osos"),
                                array("name" => "LOWER LAKE", "index" => "lower-lake"),
                                array("name" => "LYNWOOD", "index" => "lynwood"),
                                array("name" => "MADER", "index" => "mader"),
                                array("name" => "MADERA", "index" => "madera"),
                                array("name" => "MALIBU", "index" => "malibu"),
                                array("name" => "MANHATTAN BEACH", "index" => "manhattan-beach"),
                                array("name" => "MANTECA", "index" => "manteca"),
                                array("name" => "MARINA", "index" => "marina"),
                                array("name" => "MARIPOSA", "index" => "mariposa"),
                                array("name" => "MARTINEZ", "index" => "martinez"),
                                array("name" => "MARYSVILLE", "index" => "marysville"),
                                array("name" => "MCCLOUD", "index" => "mccloud"),
                                array("name" => "MCKINLEYVILLE", "index" => "mckinleyville"),
                                array("name" => "MENIFEE", "index" => "menifee"),
                                array("name" => "MENLO PARK", "index" => "menlo-park"),
                                array("name" => "MENTONE", "index" => "mentone"),
                                array("name" => "MERCED", "index" => "merced"),
                                array("name" => "MIDWAY CITY", "index" => "midway-city"),
                                array("name" => "MILL VALLEY", "index" => "mill-valley"),
                                array("name" => "MILLBRAE", "index" => "millbrae"),
                                array("name" => "MILPITAS", "index" => "milpitas"),
                                array("name" => "MIRA LOMA", "index" => "mira-loma"),
                                array("name" => "MISSION HILLS", "index" => "mission-hills"),
                                array("name" => "MISSION VIEJO", "index" => "mission-viejo"),
                                array("name" => "MODESTO", "index" => "modesto"),
                                array("name" => "MODJESKA CANYON", "index" => "modjeska-canyon"),
                                array("name" => "MONARCH BEACH", "index" => "monarch-beach"),
                                array("name" => "MONROVIA", "index" => "monrovia"),
                                array("name" => "MONTARA", "index" => "montara"),
                                array("name" => "MONTCLAIR", "index" => "montclair"),
                                array("name" => "MONTEBELLO", "index" => "montebello"),
                                array("name" => "MONTEREY", "index" => "monterey"),
                                array("name" => "MONTEREY PARK", "index" => "monterey-park"),
                                array("name" => "MONTROSE", "index" => "montrose"),
                                array("name" => "MOORPARK", "index" => "moorpark"),
                                array("name" => "MORAGA", "index" => "moraga"),
                                array("name" => "MORENO VALLEY", "index" => "moreno-valley"),
                                array("name" => "MORGAN HILL", "index" => "morgan-hill"),
                                array("name" => "MORRO BAY", "index" => "morro-bay"),
                                array("name" => "MOSS BEACH", "index" => "moss-beach"),
                                array("name" => "MOUNTAIN VIEW", "index" => "mountain-view"),
                                array("name" => "MT. VIEW", "index" => "mt-view"),
                                array("name" => "MURRIETA", "index" => "murrieta"),
                                array("name" => "N HOLLYWOOD", "index" => "n-hollywood"),
                                array("name" => "NAPA", "index" => "napa"),
                                array("name" => "NATIONAL CITY", "index" => "national-city"),
                                array("name" => "NEVADA CITY", "index" => "nevada-city"),
                                array("name" => "NEWARK", "index" => "newark"),
                                array("name" => "NEWBURY PARK", "index" => "newbury-park"),
                                array("name" => "NEWCASTLE", "index" => "newcastle"),
                                array("name" => "NEWHALL", "index" => "newhall"),
                                array("name" => "NEWMAN", "index" => "newman"),
                                array("name" => "Newport Beach", "index" => "newport-beach"),
                                array("name" => "NICE", "index" => "nice"),
                                array("name" => "NIPOMO", "index" => "nipomo"),
                                array("name" => "NORCO", "index" => "norco"),
                                array("name" => "NORTH FORK", "index" => "north-fork"),
                                array("name" => "NORTH HIGHLANDS", "index" => "north-highlands"),
                                array("name" => "NORTH HILLS", "index" => "north-hills"),
                                array("name" => "NORTH HOLLYWOOD", "index" => "north-hollywood"),
                                array("name" => "NORTH TUSTIN", "index" => "north-tustin"),
                                array("name" => "NORTHRIDGE", "index" => "northridge"),
                                array("name" => "NORWALK", "index" => "norwalk"),
                                array("name" => "NOVATO", "index" => "novato"),
                                array("name" => "NUEVO", "index" => "nuevo"),
                                array("name" => "OAK PARK", "index" => "oak-park"),
                                array("name" => "OAK VIEW", "index" => "oak-view"),
                                array("name" => "OAKDALE", "index" => "oakdale"),
                                array("name" => "OAKHURST", "index" => "oakhurst"),
                                array("name" => "OAKLAND", "index" => "oakland"),
                                array("name" => "OAKLEY", "index" => "oakley"),
                                array("name" => "OCEANSIDE", "index" => "oceanside"),
                                array("name" => "OJAI", "index" => "ojai"),
                                array("name" => "OLIVEHURST", "index" => "olivehurst"),
                                array("name" => "ONTARIO", "index" => "ontario"),
                                array("name" => "ORANGE", "index" => "orange"),
                                array("name" => "ORANGEVALE", "index" => "orangevale"),
                                array("name" => "ORCUTT", "index" => "orcutt"),
                                array("name" => "ORINDA", "index" => "orinda"),
                                array("name" => "ORLAND", "index" => "orland"),
                                array("name" => "OROVILLE", "index" => "oroville"),
                                array("name" => "OXNARD", "index" => "oxnard"),
                                array("name" => "PACIFIC GROVE", "index" => "pacific-grove"),
                                array("name" => "PACIFIC PALISADES", "index" => "pacific-palisades"),
                                array("name" => "PACIFICA", "index" => "pacifica"),
                                array("name" => "PACOIMA", "index" => "pacoima"),
                                array("name" => "PALM DESERT", "index" => "palm-desert"),
                                array("name" => "PALM SPRING", "index" => "palm-spring"),
                                array("name" => "PALM SPRINGS", "index" => "palm-springs"),
                                array("name" => "PALMDALE", "index" => "palmdale"),
                                array("name" => "PALO ALTO", "index" => "palo-alto"),
                                array("name" => "PALOS VERDES ESTATES", "index" => "palos-verdes-estates"),
                                array("name" => "PANORAMA", "index" => "panorama"),
                                array("name" => "PANORAMA CITY", "index" => "panorama-city"),
                                array("name" => "PARADISE", "index" => "paradise"),
                                array("name" => "PASADENA", "index" => "pasadena"),
                                array("name" => "PASO ROBLES", "index" => "paso-robles"),
                                array("name" => "PATTERSON", "index" => "patterson"),
                                array("name" => "PENN VALLEY", "index" => "penn-valley"),
                                array("name" => "PENNGROVE", "index" => "penngrove"),
                                array("name" => "PENRYN", "index" => "penryn"),
                                array("name" => "PERRIS", "index" => "perris"),
                                array("name" => "PETALUMA", "index" => "petaluma"),
                                array("name" => "PHELAN", "index" => "phelan"),
                                array("name" => "PHILLIPS RANCH", "index" => "phillips-ranch"),
                                array("name" => "PINOLE", "index" => "pinole"),
                                array("name" => "PINON HILLS", "index" => "pinon-hills"),
                                array("name" => "PISMO BEACH", "index" => "pismo-beach"),
                                array("name" => "PITTSBURG", "index" => "pittsburg"),
                                array("name" => "PLACENTIA", "index" => "placentia"),
                                array("name" => "PLACERVILLE", "index" => "placerville"),
                                array("name" => "PLAYA VISTA", "index" => "playa-vista"),
                                array("name" => "PLEASANT HILL", "index" => "pleasant-hill"),
                                array("name" => "PLEASANTON", "index" => "pleasanton"),
                                array("name" => "POINT REYES STATION", "index" => "point-reyes-station"),
                                array("name" => "POMONA", "index" => "pomona"),
                                array("name" => "PORT HUENEME", "index" => "port-hueneme"),
                                array("name" => "PORTER RANCH", "index" => "porter-ranch"),
                                array("name" => "PORTERVILLE", "index" => "porterville"),
                                array("name" => "PORTOLA", "index" => "portola"),
                                array("name" => "PORTOLA VALLEY", "index" => "portola-valley"),
                                array("name" => "POWAY", "index" => "poway"),
                                array("name" => "QUAIL VALLEY", "index" => "quail-valley"),
                                array("name" => "QUARTZ HILL", "index" => "quartz-hill"),
                                array("name" => "RAMONA", "index" => "ramona"),
                                array("name" => "RANCH CUCAMONGA", "index" => "ranch-cucamonga"),
                                array("name" => "RANCHO CORDOVA", "index" => "rancho-cordova"),
                                array("name" => "RANCHO CUCAMONGA", "index" => "rancho-cucamonga"),
                                array("name" => "RANCHO MIRAGE", "index" => "rancho-mirage"),
                                array("name" => "RANCHO MISSION VIEJO", "index" => "rancho-mission-viejo"),
                                array("name" => "RANCHO PALOS VERDES", "index" => "rancho-palos-verdes"),
                                array("name" => "RANCHO SAN DIEGO", "index" => "rancho-san-diego"),
                                array("name" => "RANCHO SANTA MARGARI", "index" => "rancho-santa-margari"),
                                array("name" => "RED BLUFF", "index" => "red-bluff"),
                                array("name" => "REDDING", "index" => "redding"),
                                array("name" => "REDLANDS", "index" => "redlands"),
                                array("name" => "REDONDO BEACH", "index" => "redondo-beach"),
                                array("name" => "REDWOOD CITY", "index" => "redwood-city"),
                                array("name" => "REEDLEY", "index" => "reedley"),
                                array("name" => "RESEDA", "index" => "reseda"),
                                array("name" => "RIALTO", "index" => "rialto"),
                                array("name" => "RICHMOND", "index" => "richmond"),
                                array("name" => "RIDGECREST", "index" => "ridgecrest"),
                                array("name" => "RIO DELL", "index" => "rio-dell"),
                                array("name" => "RIO LINDA", "index" => "rio-linda"),
                                array("name" => "RIO VISTA", "index" => "rio-vista"),
                                array("name" => "RIPON", "index" => "ripon"),
                                array("name" => "RIVERBANK", "index" => "riverbank"),
                                array("name" => "Riverside", "index" => "riverside"),
                                array("name" => "RNACHO MIRAGE", "index" => "rnacho-mirage"),
                                array("name" => "ROCKLIN", "index" => "rocklin"),
                                array("name" => "RODEO", "index" => "rodeo"),
                                array("name" => "ROHNERT PARK", "index" => "rohnert-park"),
                                array("name" => "ROLLING HILLS ESTATE", "index" => "rolling-hills-estate"),
                                array("name" => "ROSEMEAD", "index" => "rosemead"),
                                array("name" => "ROSEVILLE", "index" => "roseville"),
                                array("name" => "ROSSMOOR", "index" => "rossmoor"),
                                array("name" => "ROWLAND HEIGHTS", "index" => "rowland-heights"),
                                array("name" => "S SAN FRANCISCO", "index" => "s-san-francisco"),
                                array("name" => "SACRAMENTO", "index" => "sacramento"),
                                array("name" => "SALIDA", "index" => "salida"),
                                array("name" => "SALINAS", "index" => "salinas"),
                                array("name" => "SAN ANDREAS", "index" => "san-andreas"),
                                array("name" => "SAN ANSELMO", "index" => "san-anselmo"),
                                array("name" => "SAN BERNARDINO", "index" => "san-bernardino"),
                                array("name" => "SAN BRUNO", "index" => "san-bruno"),
                                array("name" => "SAN CARLOS", "index" => "san-carlos"),
                                array("name" => "SAN CLEMENTE", "index" => "san-clemente"),
                                array("name" => "SAN DIEGO", "index" => "san-diego"),
                                array("name" => "SAN DIMAS", "index" => "san-dimas"),
                                array("name" => "SAN FERNANDO", "index" => "san-fernando"),
                                array("name" => "SAN FRANCISCO", "index" => "san-francisco"),
                                array("name" => "SAN GABRIEL", "index" => "san-gabriel"),
                                array("name" => "SAN JACINTO", "index" => "san-jacinto"),
                                array("name" => "SAN JOSE", "index" => "san-jose"),
                                array("name" => "SAN JUAN CAPISTANO", "index" => "san-juan-capistano"),
                                array("name" => "SAN JUAN CAPISTRANO", "index" => "san-juan-capistrano"),
                                array("name" => "SAN LEANDRO", "index" => "san-leandro"),
                                array("name" => "SAN LORENZO", "index" => "san-lorenzo"),
                                array("name" => "SAN LUIS OBISPO", "index" => "san-luis-obispo"),
                                array("name" => "SAN MARCOS", "index" => "san-marcos"),
                                array("name" => "SAN MARTIN", "index" => "san-martin"),
                                array("name" => "SAN MATEO", "index" => "san-mateo"),
                                array("name" => "SAN PABLO", "index" => "san-pablo"),
                                array("name" => "SAN PEDRO", "index" => "san-pedro"),
                                array("name" => "SAN RAFAEL", "index" => "san-rafael"),
                                array("name" => "SAN RAMON", "index" => "san-ramon"),
                                array("name" => "SANGER", "index" => "sanger"),
                                array("name" => "Santa Ana", "index" => "santa-ana"),
                                array("name" => "SANTA BARBARA", "index" => "santa-barbara"),
                                array("name" => "SANTA CLARA", "index" => "santa-clara"),
                                array("name" => "SANTA CLARITA", "index" => "santa-clarita"),
                                array("name" => "SANTA CRUZ", "index" => "santa-cruz"),
                                array("name" => "SANTA MARIA", "index" => "santa-maria"),
                                array("name" => "SANTA MONICA", "index" => "santa-monica"),
                                array("name" => "SANTA PAULA", "index" => "santa-paula"),
                                array("name" => "SANTA ROSA", "index" => "santa-rosa"),
                                array("name" => "SANTEE", "index" => "santee"),
                                array("name" => "SARATOGA", "index" => "saratoga"),
                                array("name" => "SAUGUS", "index" => "saugus"),
                                array("name" => "SCOTTS VALLEY", "index" => "scotts-valley"),
                                array("name" => "SEAL BEACH", "index" => "seal-beach"),
                                array("name" => "SEASIDE", "index" => "seaside"),
                                array("name" => "SEBASTOPOL", "index" => "sebastopol"),
                                array("name" => "SELMA", "index" => "selma"),
                                array("name" => "SHAFTER", "index" => "shafter"),
                                array("name" => "SHASTA LAKE CITY", "index" => "shasta-lake-city"),
                                array("name" => "SHERMAN OAKS", "index" => "sherman-oaks"),
                                array("name" => "SHERWOOD FOREST", "index" => "sherwood-forest"),
                                array("name" => "SHINGLE SPRINGS", "index" => "shingle-springs"),
                                array("name" => "SIERRA MADRE", "index" => "sierra-madre"),
                                array("name" => "SIMI VALLEY", "index" => "simi-valley"),
                                array("name" => "SKY VALLEY", "index" => "sky-valley"),
                                array("name" => "SO SAN FRANCISCO", "index" => "so-san-francisco"),
                                array("name" => "SOLANA BEACH", "index" => "solana-beach"),
                                array("name" => "SOLVANG", "index" => "solvang"),
                                array("name" => "SOMIS", "index" => "somis"),
                                array("name" => "SONOMA", "index" => "sonoma"),
                                array("name" => "SONORA", "index" => "sonora"),
                                array("name" => "SOQUEL", "index" => "soquel"),
                                array("name" => "SOULSBYVILLE", "index" => "soulsbyville"),
                                array("name" => "SOUTH PASADENA", "index" => "south-pasadena"),
                                array("name" => "SOUTH SAN FRANCISCO", "index" => "south-san-francisco"),
                                array("name" => "SPRING VALLEY", "index" => "spring-valley"),
                                array("name" => "ST HELENA", "index" => "st-helena"),
                                array("name" => "STALLION SPRINGS", "index" => "stallion-springs"),
                                array("name" => "STANTON", "index" => "stanton"),
                                array("name" => "STEVENSON RANCH", "index" => "stevenson-ranch"),
                                array("name" => "STOCKTON", "index" => "stockton"),
                                array("name" => "STRATHMORE", "index" => "strathmore"),
                                array("name" => "STUDIO CITY", "index" => "studio-city"),
                                array("name" => "SUISUN", "index" => "suisun"),
                                array("name" => "SUISUN CITY", "index" => "suisun-city"),
                                array("name" => "SUN CITY", "index" => "sun-city"),
                                array("name" => "SUN VALLEY", "index" => "sun-valley"),
                                array("name" => "SUNLAND", "index" => "sunland"),
                                array("name" => "SUNNYVALE", "index" => "sunnyvale"),
                                array("name" => "SUSANVILLE", "index" => "susanville"),
                                array("name" => "SUTTER CREEK", "index" => "sutter-creek"),
                                array("name" => "SYLMAR", "index" => "sylmar"),
                                array("name" => "TAFT", "index" => "taft"),
                                array("name" => "TARZANA", "index" => "tarzana"),
                                array("name" => "TEHACHAPI", "index" => "tehachapi"),
                                array("name" => "TEMECULA", "index" => "temecula"),
                                array("name" => "TEMPLE CITY", "index" => "temple-city"),
                                array("name" => "TEMPLETON", "index" => "templeton"),
                                array("name" => "THERMALITO", "index" => "thermalito"),
                                array("name" => "THOUSAND OAKS", "index" => "thousand-oaks"),
                                array("name" => "TOLUCA LAKE", "index" => "toluca-lake"),
                                array("name" => "TOMALES", "index" => "tomales"),
                                array("name" => "TORRANCE", "index" => "torrance"),
                                array("name" => "TRACY", "index" => "tracy"),
                                array("name" => "TUJUNGA", "index" => "tujunga"),
                                array("name" => "TULARE", "index" => "tulare"),
                                array("name" => "TURLOCK", "index" => "turlock"),
                                array("name" => "TUSTIN", "index" => "tustin"),
                                array("name" => "TWENTYNINE PALMS", "index" => "twentynine-palms"),
                                array("name" => "UKIAH", "index" => "ukiah"),
                                array("name" => "UNION CITY", "index" => "union-city"),
                                array("name" => "UPLAND", "index" => "upland"),
                                array("name" => "UPPER LAKE", "index" => "upper-lake"),
                                array("name" => "VACAVILLE", "index" => "vacaville"),
                                array("name" => "VACVILLE", "index" => "vacville"),
                                array("name" => "VAL VERDE", "index" => "val-verde"),
                                array("name" => "VALENCIA", "index" => "valencia"),
                                array("name" => "VALINDA", "index" => "valinda"),
                                array("name" => "VALLEJO", "index" => "vallejo"),
                                array("name" => "VALLEY CENTER", "index" => "valley-center"),
                                array("name" => "VALLEY GLEN", "index" => "valley-glen"),
                                array("name" => "VALLEY VILLAGE", "index" => "valley-village"),
                                array("name" => "VAN NUYS", "index" => "van-nuys"),
                                array("name" => "VENICE", "index" => "venice"),
                                array("name" => "VENTURA", "index" => "ventura"),
                                array("name" => "VICTORVILLE", "index" => "victorville"),
                                array("name" => "VILLA PARK", "index" => "villa-park"),
                                array("name" => "VISALA", "index" => "visala"),
                                array("name" => "VISALIA", "index" => "visalia"),
                                array("name" => "VISTA", "index" => "vista"),
                                array("name" => "WALNUT", "index" => "walnut"),
                                array("name" => "WALNUT CREEK", "index" => "walnut-creek"),
                                array("name" => "WASCO", "index" => "wasco"),
                                array("name" => "WATSONVILLE", "index" => "watsonville"),
                                array("name" => "WEIMAR", "index" => "weimar"),
                                array("name" => "WEST COVINA", "index" => "west-covina"),
                                array("name" => "WEST HILLS", "index" => "west-hills"),
                                array("name" => "WEST HOLLYWOOD", "index" => "west-hollywood"),
                                array("name" => "WEST LOS ANGELES", "index" => "west-los-angeles"),
                                array("name" => "WEST SACRAMENTO", "index" => "west-sacramento"),
                                array("name" => "WESTLAKE VILLAGE", "index" => "westlake-village"),
                                array("name" => "WESTMINISTER", "index" => "westminister"),
                                array("name" => "WESTMINSTER", "index" => "westminster"),
                                array("name" => "WESTWOOD", "index" => "westwood"),
                                array("name" => "WHITTIER", "index" => "whittier"),
                                array("name" => "WILDOMAR", "index" => "wildomar"),
                                array("name" => "WILLIAMS", "index" => "williams"),
                                array("name" => "WILLITS", "index" => "willits"),
                                array("name" => "WILTON", "index" => "wilton"),
                                array("name" => "WINCHESTER", "index" => "winchester"),
                                array("name" => "WINDSOR", "index" => "windsor"),
                                array("name" => "WINNETKA", "index" => "winnetka"),
                                array("name" => "WOFFORD HEIGHTS", "index" => "wofford-heights"),
                                array("name" => "WOODLAND", "index" => "woodland"),
                                array("name" => "WOODLAND HILLS", "index" => "woodland-hills"),
                                array("name" => "WOODSIDE", "index" => "woodside"),
                                array("name" => "YORBA LINDA", "index" => "yorba-linda"),
                                array("name" => "YOUNTVILLE", "index" => "yountville"),
                                array("name" => "YREKA", "index" => "yreka"),
                                array("name" => "YUBA CITY", "index" => "yuba-city"),
                                array("name" => "YUCAIPA", "index" => "yucaipa"),
                                array("name" => "YUCCA VALLEY", "index" => "yucca-valley")
                            );
                            echo '<option value="0">Select City</option>';
                            foreach ($array as $arrays) {?>
                          <option value="<?php echo $arrays['index']; ?>" <?php if($pro_location_city == $arrays['index']){ echo 'selected="selected"'; } ?>><?php echo $arrays['name']; ?></option>
                          <?php 
                            }
                            ?>
                        </select>
                      </div>
                      <?php 
                        $pro_location_zip_code = get_field( 'pro_location_zip_code', $post_id );                        
                        ?>    
                      <div class="jrFieldDiv jrPhonenumber" style=""><label class="jrLabel">Zip Code<span class="jrIconRequired"></span></label><input type="text" id="pro_location_zip_code" name="pro_location_zip_code" class="jr_phonenumber jrText" value="<?php if($pro_location_zip_code):
                        echo $pro_location_zip_code;
                        endif;
                        ?>"></div>
                    </div>
                  </div>
                </fieldset>
                <fieldset id="group_contact-info" class="jrHidden jrFieldsetMargin" style="display: block;">
                  <legend>Contact Information</legend>
                  <div class="jrDataList">
                    <div class="jrCol4">
                      <?php 
                        $contactInfo_phone_number = get_field( 'contactInfo_phone_number', $post_id );
                        
                        ?>  
                      <div class="jrFieldDiv jrPhonenumber" style=""><label class="jrLabel">Phone Number<span class="jrIconRequired"></span></label><input type="text" name="contactInfo_phone_number" id="contactInfo_phone_number" class="jr_phonenumber jrText" value="<?php  if($contactInfo_phone_number):
                        echo $contactInfo_phone_number;
                        endif; ?>"></div>
                    </div>
                    <div class="jrCol4">
                      <?php 
                        $contactInfo_license = get_field( 'contactInfo_license', $post_id );
                        
                        ?>  
                      <div class="jrFieldDiv jrPhonenumber" style=""><label class="jrLabel">License#<span class="jrIconRequired"></span></label><input type="text" name="contactInfo_license" id="contactInfo_license" class="jr_phonenumber jrText" value="<?php  if($contactInfo_license):
                        echo $contactInfo_license;
                        endif; ?>"></div>
                    </div>
                    <div class="jrCol4">
                      <?php 
                        $contactInfo_website_url = get_field( 'contactInfo_website_url', $post_id );
                        
                        ?>  
                      <div class="jrFieldDiv jrPhonenumber" style=""><label class="jrLabel">Website</label><input type="text" name="contactInfo_website_url" id="contactInfo_website_url" class="jr_phonenumber jrText" value="<?php  if($contactInfo_website_url):
                        echo $contactInfo_website_url;
                        endif; ?>"></div>
                    </div>
                  </div>
                </fieldset>
                <?php 
                  $amenitiesvalues = get_field('amenities', $post_id);
                  $Amenities = "field_5dadac5d891b6";
                  $Amenitiy = get_field_object($Amenities);


                 //var_dump($Amenitiy);
                  
                  if( $Amenitiy )
                  {
                          echo '<fieldset id="group_amenities" class="jrHidden jrFieldsetMargin" style="display: block;">';
                          echo '<legend>Amenities</legend>';
                          echo '<div class="jrFieldDiv jrAmenities">';
                         // echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Amenities</label>';
                  
                          foreach( $Amenitiy['choices'] as $k => $v )
                          {
                            echo '<div class="jr-option jrFieldOption" style="min-width: 324px;">';?>
                <input type="checkbox" name="amenities[]" id="jr_amenities_activity-center-search amenities" class="jr_amenities" data-search="1" value="<?php echo $k; ?>" <?php if($amenitiesvalues){ if (in_array($k, $amenitiesvalues)) { echo 'checked';}} ?>>
                <?php echo '<label for="jr_amenities_activity-center-search">' . $v . '</label>';    
                  echo '</div>';       
                  }
                  
                  //echo '</div>';
                  echo '</fieldset>';
                  
                  }            
                  $servicevalues = get_field('services', $post_id);
                  
                  $services = "field_5dadae53141ef";
                  $service = get_field_object($services);
                  if( $service )
                  {
                  echo '<fieldset id="group_services" class="jrHidden jrFieldsetMargin" style="display: block;">';
                  echo '<legend>Services</legend>';
                  echo '<div class="jrFieldDiv jrServices">';
                  //echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Services</label>';
                  
                  foreach( $service['choices'] as $k => $v )
                  {
                  echo '<div class="jr-option jrFieldOption" style="min-width: 324px;">';?>
                <input type="checkbox" name="services[]" id="jr_services_bathing-dressing-assistance-search" class="jr_services" data-search="1" value="<?php echo $k; ?>" <?php if($servicevalues){ if (in_array($k, $servicevalues)) { echo 'checked';} } ?>>
                <?php echo '<label for="jr_services_bathing-dressing-assistance-search">' . $v . '</label>';    
                  echo '</div>';       
                  }
                  
                  // echo '</div>';
                  echo '</fieldset>';
                  
                  }            
                  $languagevalues = get_field('languages_spoken', $post_id);      
                  $languages = "field_5dadae98b8c24";
                  $language = get_field_object($languages);
                  if( $language )
                  {
                  echo '<fieldset id="group_languages" class="jrHidden jrFieldsetMargin" style="display: block;">';
                  echo '<legend>Languages</legend>';
                  echo '<div class="jrFieldDiv jrLanguagesspoken">';
                  // echo '<span class="jrFieldBefore">Search ALL selected options</span><label class="jrLabel">Languages Spoken</label>';
                  
                  foreach( $language['choices'] as $k => $v )
                  {
                  echo '<div class="jr-option jrFieldOption" style="min-width: 157px;">';?>
                <input type="checkbox" name="languages_spoken[]" id="jr_languagesspoken_cantonese-search" class="jr_languagesspoken" data-search="1" value="<?php echo $k; ?>" <?php if($languagevalues){ if (in_array($k, $languagevalues)) { echo 'checked';} } ?>>
                <?php echo '<label for="jr_services_bathing-dressing-assistance-search">' . $v . '</label>';    
                  echo '</div>';       
                  }
                  
                  //echo '</div>';
                  echo '</fieldset>';
                  
                  }            
                  ?>
                <fieldset>
                  <?php if($subscriber_id != '0'){?>
                  <div class="jrDataList" id="subscriber_image">
                    <div class="jrCol8">
                      <div class="field">
                        <legend>Gallery Images</legend>
                        <input type="file" class="inputfile" id="files" name="add_propertymedia[]" multiple />
                        <?php
                          $images = get_field('add_propertymedia', $post_id);
                          if( $images ):
                              foreach( $images as $image ): 
                          ?>
                        <span class="pip"><img class="imageThumb" src="<?php echo esc_url($image['url']); ?>" title="<?php echo esc_attr($image['alt']); ?>"><br><span class="remove">Remove image</span></span>
                        <?php 
                          endforeach;
                          endif; 
                          ?>
                      </div>
                    </div>
                    <div class="jrCol4">
                      <div class="field1">
                        <legend>Feature Image</legend>
                        <div class="footer custom-file mt-3 mb-3" style="text-align:center">
                          <input type="file" id="pro_img" name="pro_img" class="form-control" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                        </div>
                        <div class="tm-product-img-dummy mx-auto">
                          <?php
                            $src = wp_get_attachment_image_src( get_post_thumbnail_id($post_id), array( 5600,1000 ), false, '' );
                            if($src):
                            ?>
                          <img src="<?php echo $src[0]; ?>" id="blah" alt="your image" width="" />
                          <?php else: ?>
                          <img src="<?php echo plugins_url();?>/carehome-property/public/images/chd_white-bg-temp_image.png" id="blah" alt="your image" width="" />
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php }else{
                    } ?>
                </fieldset>
                <fieldset id="group_availability" class="jrHidden jrFieldsetMargin" style="display: block;">
                  <legend>Availability</legend>
                  <?php 
                    $private_rooms = get_field( 'private_rooms', $post_id);
                    
                    ?>  
                  <div class="jrFieldDiv jrAvailablebedsinprivaterooms" style="">
                    <label class="jrLabel">Private Rooms</label>
                    <input type="number" name="private_rooms" class="jr_availablebedsinprivaterooms jrInteger" id="private_rooms" value="<?php  if($private_rooms):
                      echo $private_rooms;
                      endif; ?>">
                  </div>
                  <?php 
                    $shared_rooms = get_field( 'shared_rooms', $post_id );                               
                    ?>  
                  <div class="jrFieldDiv jrAvailablebedsinsharedrooms" style="">
                    <label class="jrLabel">Shared Rooms</label>
                    <input type="number" name="shared_rooms" class="jr_availablebedsinsharedrooms jrInteger" id="shared_rooms" value="<?php  if($shared_rooms):
                      echo $shared_rooms;
                      endif; ?>">
                  </div>
                </fieldset>
                <fieldset id="group_pricing" class="jrHidden jrFieldsetMargin" style="display: block;">
                  <legend>Pricing</legend>
                  <?php 
                    $private_room_costmonth = get_field( 'private_room_costmonth', $post_id );
                    ?>
                  <div class="jrFieldDiv jrPrivateroomcostmonth" style="">
                    <label class="jrLabel">Private Room Cost/Month</label>
                    <div class="jrFieldDescription jrAbove">Add pricing in simple numbers (ex: 3500). The $ sign will display automatically.</div>
                    <input type="number" name="private_room_costmonth" class="jr_privateroomcostmonth jrDecimal" id="private_room_costmonth" value="<?php  if($private_room_costmonth):
                      echo $private_room_costmonth;
                      endif; ?>">
                  </div>
                  <?php 
                    $shared_room_costmonth = get_field( 'shared_room_costmonth', $post_id );
                    ?>
                  <div class="jrFieldDiv jrSharedroomcostmonth" style="">
                    <label class="jrLabel">Shared Room Cost/Month</label>
                    <div class="jrFieldDescription jrAbove">As mentioned above, add pricing in simple numbers form (ex: 3500). The $ sign will display automatically.</div>
                    <input type="number" name="shared_room_costmonth" class="jr_sharedroomcostmonth jrDecimal" id="shared_room_costmonth" value="<?php  if($shared_room_costmonth):
                      echo $shared_room_costmonth;
                      endif; ?>">
                  </div>
                </fieldset>
                <fieldset>
                  <div class="jrFieldDiv">
                    <label class="jrLabel">Description<span class="jrIconRequired"></span></label>
                    <!--  <input id="Listing_fulltext" type="hidden" name="Listing_fulltext">
                      <trix-editor input="Listing_fulltext"></trix-editor> -->
                    <textarea rows="4" cols="50" id="Listing_fulltext" name="Listing_fulltext" class="jr_phonenumber jrText">
                            <?php
                      $content = get_post_field('post_content', $post_id);
                          if($content):
                              echo $content;
                          endif;
                      ?>                            
                        </textarea>
                  </div>
                </fieldset>
                <?php if($subscriber_id != '0'){?>
                <fieldset>
                  <div class="jrFieldDiv">
                    <label class="jrLabel">Video Iframe</label>
                    <?php 
                      $property_video = get_field( 'property_video', $post_id );
                      
                      ?>
                    <textarea rows="4" cols="50" id="Listing_video" name="Listing_video" class="jr_phonenumber jrText">
                    <?php
                      if($property_video):
                          echo $property_video;
                      endif;
                      ?>                            
                    </textarea>
                  </div>
                  
                </fieldset>
                <?php } ?>
                <div class="jr-buttons jrButtons">
                  <button class="jr-submit-listing jrButton jrLarge jrGreen">Update</button>
                  <button class="jr-cancel-listing jrButton jrLarge">Cancel</button>
                </div>
              </div>
              <!-- END MAIN DIV -->
              <div id="loader"></div>
            </form>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
<?php
  echo '<script type="text/javascript">
          var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
  
  ?>
<!-- <script type="text/javascript">
  tinymce.init({
    selector: "textarea#Listing_fulltext",
    setup: function (editor) {
        editor.on('change', function () {
            tinymce.triggerSave();
        });
    }
  });
  tinymce.init({
    selector: "textarea#Listing_video",
    setup: function (editor) {
        editor.on('change', function () {
            tinymce.triggerSave();
        });
    }
  });  
</script> -->
 <script>
  CKEDITOR.config.allowedContent = true;

        CKEDITOR.replace( 'Listing_fulltext' );
       // CKEDITOR.replace( 'Listing_video' );
</script>
<style type="text/css">
  #loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/user/images/loader1.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }
</style>