  jQuery(document).ready(function($){
    /*==================================  Custom Tab Functionality ================================*/   
    $('ul.tabs li').click(function(){
      var tab_id = $(this).attr('data-tab');

      $('ul.tabs li').removeClass('ui-state-active');
      $('.tab-content').removeClass('ui-state-active');

      $(this).addClass('ui-state-active');
      $("#"+tab_id).addClass('ui-state-active');
    });
    
    var spinner = $('#loader');
/*+++++++++++++++++++++++++++ Stripe Card Form Display ++++++++++++++++++++++++++++++*/

    $('input[name=jr_paid_plan]').click(function () {
      $("#form-container-payment").show();
    }); 
/*+++++++++++++++++++++++++++ Stripe Card Checking +++++++++++++++++++++++++++++++++*/

    Stripe.setPublishableKey('pk_test_YGkT6VfeY5cJY9Wl1fkxCu8I00LSiBOVdK');
    var cardNumber, cardMonth, cardYear, cardCVC, cardHolder;
    // check for any empty inputs
    function findEmpty() {
        var emptyText = $('#form-container input').filter(function () {
            return $(this).val == null;
        });
        // add invalid class to empty inputs
        console.log(emptyText.prevObject);
        emptyText.prevObject.addClass('invalid');
    } 

    // check card type on card number input blur 
    $('#card-number').blur(function (event) {
        event.preventDefault();
       // checkCardType();
    });

/*+++++++++++++++++++++++++++ Stripe Subscription +++++++++++++++++++++++++++++++++*/
    $('#card-btn').click(function (event) {

        var plan = $("input[name='jr_paid_plan']:checked").val();
        var price = $('input[name="jr_paid_plan"]:checked').attr("data-AmtPrice");
        var interval = $('input[name="jr_paid_plan"]:checked').attr("data-interval");
        var nickname = $('input[name="jr_paid_plan"]:checked').attr("data-nickname");
        // get each input value and use Stripe to determine whether they are valid
        var cardNumber = $('#card-number').val();
        var isValidNo = Stripe.card.validateCardNumber(cardNumber);
        var expMonth = $('#card-month').val();
        var expYear = $('#card-year').val();
        var isValidExpiry = Stripe.card.validateExpiry(expMonth, expYear);

        var cardCVC = $('#card-cvc').val();
        var isValidCVC = Stripe.card.validateCVC(cardCVC);
        var cardHolder = $('#card-holder').val();
        event.preventDefault();

        // alert the user if any fields are missing
        if (!cardNumber || !cardCVC || !cardHolder || !expMonth || !expYear) {
            console.log(cardNumber + cardCVC + cardHolder + expMonth + expYear);
            $('#form-errors').addClass('hidden');
            $('#card-success').addClass('hidden');
            $('#form-errors').removeClass('hidden');
            $('#card-error').text('Please complete all fields.');
            findEmpty();
        } else {
            // alert the user if any fields are invalid
            if (!isValidNo || !isValidExpiry || !isValidCVC) {
                $('#form-errors').css('display', 'block');
                if (!isValidNo) {
                    $('#card-error').text('Invalid credit card number.');
                } else if (!isValidExpiry) {
                    $('#card-error').text('Invalid expiration date.')
                } else if (!isValidCVC) {
                    $('#card-error').text('Invalid CVC code.')
                }

            } else {
                $('#form-errors').addClass('hidden');
                spinner.show();
                jQuery.ajax({
                  url: ajaxurl, // or example_ajax_obj.ajaxurl if using on frontend
                  type: 'post',
                  data: {
                      'action': 'stripe_membership_payment',
                      'cardNumber' : cardNumber,
                      'cardCVC' : cardCVC,
                      'cardHolder' : cardHolder,
                      'expMonth' : expMonth,
                      'expYear' : expYear,
                      'plan' : plan,
                      'price' : price,
                      'interval':interval,
                      'nickname':nickname
                  },
                  success:function(data) {
                    //console.log(data);
                    spinner.hide();
                    $('#card-success').removeClass('hidden');
                    setTimeout(function(){// wait for 5 secs(2)
                         location.reload(); // then reload the page.(3)
                    }, 3000); 
                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
              });
            }
        }
    });
    /*++++++++++++++++++++++ Multiple File Upload Preview ++++++++++++++++++++*/  
      if (window.File && window.FileList && window.FileReader) {
        $("#files").on("change", function(e) {
          var files = e.target.files,
            filesLength = files.length;
          for (var i = 0; i < filesLength; i++) {
            var f = files[i]
            var fileReader = new FileReader();
            fileReader.onload = (function(e) {
              var file = e.target;
              $("<span class=\"pip\">" +
                "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
                "<br/><span class=\"remove\">Remove image</span>" +
                "</span>").insertAfter("#files");
              $(".remove").click(function(){
                $(this).parent(".pip").remove();
              });
            });
            fileReader.readAsDataURL(f);
          }
        });
      } else {
        alert("Your browser doesn't support to File API")
      }
       $("#jr-form-property-form .pip span.remove").click(function(){
        //alert('hi');
                $(this).parent(".pip").remove();
              });
    /*++++++++++++++++++++++ Add Property with Validation ++++++++++++++++++++*/ 
    $.validator.addMethod('selectcheck', function (value) {
        return (value != '0');
    }, "Please select City");



/*$.validator.addMethod("extension", function(value, element, param) {
  param = typeof param === "string" ? param.replace(/,/g, '|') : "png|jpe?g|gif";
  return this.optional(element) || value.match(new RegExp(".(" + param + ")$", "i"));
}, $.format("Please enter a value Like (jpg, jpeg, png) a valid extension."));*/

/*$.validator.addMethod('maxfilesize', function(value, element, param) {
   var length = ( element.files.length );
    var fileSize = 0;
           if (length > 0) {
               for (var i = 0; i < length; i++) {
                   fileSize = element.files[i].size; // get file size
                    // console.log("if" +length);
                        fileSize = fileSize / 1024; //file size in Kb
                        fileSize = fileSize / 1024; //file size in Mb
                     return this.optional( element ) || fileSize <= param;
               }
            }
            else
            {
                return this.optional( element ) || fileSize <= param;
                    //console.log("else" +length);
            }
});*/



      $('#jr-form-property-form').validate({

            rules: {
                Listing_title: {         
                    required: true
                },
                pro_location_city: {          
                    selectcheck: true 
                },
                pro_location_address: {         
                    required: true
                },
                pro_location_state: {         
                    required: true
                },
                pro_location_zip_code: {         
                    required: true
                },
                contactInfo_phone_number: {         
                    required: true
                },
                contactInfo_license: {         
                    required: true
                },
                Listing_fulltext:{
                    required: true
                },
                pro_img:{
                  required: true,
                //  maxfilesize : 2,
                   //  extension: "jpg|jpeg|png",
                    // filesize: 2097152
                },
                'add_propertymedia[]': {
                     required: true,
                    // maxfilesize : 2,
                    // extension: "jpg|jpeg|png",
                     //filesize: 2097152
                  }
            },
            messages: {              
                Listing_title: {
                      required:"Please Enter Listing Title."
                },
                pro_location_address: {
                      required:"Please Enter Address."
                },
                pro_location_state: {
                      required:"Please Enter State."
                },
                pro_location_zip_code: {
                      required:"Please Enter Zip Code."
                },
                contactInfo_phone_number: {
                      required:"Please Enter Phone Number."
                },
                contactInfo_license: {
                      required:"Please Enter License#."
                },
                Listing_fulltext: {
                      required:"Please Enter Description."
                },
              /*  pro_img:{
                  maxfilesize : "File size must not be more than 2 MB."
                },*/
                'add_propertymedia[]':{
                     maxfilesize : "File size must not be more than 2 MB."
                }
            },

            submitHandler: function(form) {  
            //var form = $(form);

              var fulltext = $("#Listing_fulltext").attr('name');
              //var video = $("#Listing_video").attr('name');
              CKEDITOR.instances[fulltext].updateElement();
              //CKEDITOR.instances[video].updateElement();

                spinner.show();
                var vidFileLength = $( "#subscriber_image" ).length;
                if ($("#feature_listing").is(":checked")){
                  var feature_listing = $("#feature_listing").val();

                }else{
                  var feature_listing = '';
                }

               //console.log(vidFileLength);
                var Listing_title = $("#Listing_title").val();
                var ajaxUrl_action = $("#ajaxUrl_action").val();
               // console.log(Listing_title);
                var contactInfo_phone_number = $("#contactInfo_phone_number").val();
                var contactInfo_license = $("#contactInfo_license").val();
                var contactInfo_website_url = $("#contactInfo_website_url").val();

                var pro_location_address = $("#pro_location_address").val();
                var pro_location_city = $("#pro_location_city").val();
                var pro_location_state = $("#pro_location_state").val();
                var pro_location_zip_code = $("#pro_location_zip_code").val();
                var amenities=[];
                $("input:checkbox[name*=amenities]:checked").each(function(){
                     amenities.push($(this).val());
                });
                var pcategory=[];
                $("input:checkbox[name*=pcategory]:checked").each(function(){
                     pcategory.push($(this).val());
                });
                var services=[];
                $("input:checkbox[name*=services]:checked").each(function(){
                     services.push($(this).val());
                });
                var languages_spoken=[];
                $("input:checkbox[name*=languages_spoken]:checked").each(function(){
                     languages_spoken.push($(this).val());
                });
                if(vidFileLength > 0){
                var pro_img = $('input[name=pro_img]')[0].files[0];
                var files =$('input[name^=add_propertymedia')[0].files;

                }


                var private_rooms = $("#private_rooms").val();
                var shared_rooms = $("#shared_rooms").val();
                var private_room_costmonth = $("#private_room_costmonth").val();
                var shared_room_costmonth = $("#shared_room_costmonth").val();
                var Listing_fulltext = $("#Listing_fulltext").val();
                var Listing_video = $("#Listing_video").val();
                var action = 'Add_Property_User_Submit';


                var post_data = new FormData();    
                post_data.append( 'Listing_title', Listing_title );

                post_data.append( 'pro_location_address', pro_location_address );
                post_data.append( 'pro_location_city', pro_location_city );
                post_data.append( 'pro_location_state', pro_location_state );
                post_data.append( 'pro_location_zip_code', pro_location_zip_code );

                post_data.append( 'contactInfo_phone_number', contactInfo_phone_number );
                post_data.append( 'contactInfo_license', contactInfo_license );
                post_data.append( 'contactInfo_website_url', contactInfo_website_url );
                post_data.append( 'pcategory', pcategory );
                post_data.append( 'amenities', amenities );
                post_data.append( 'services', services );
                post_data.append( 'languages_spoken', languages_spoken );
                post_data.append( 'pro_img', pro_img );

              /*  for(var i=0;i<files.length;i++){
                    post_data.append("add_propertymedia[]", files[i], files[i]['name']);
                }*/
                var files_data = $('#jr-form-property-form .inputfile'); 
                // Loop through each data and create an array file[] containing our files data.
                $.each($(files_data), function(i, obj) {
                    $.each(obj.files,function(j,file){
                        post_data.append('add_propertymedia[' + j + ']', file);
                    })
                });
                post_data.append( 'private_rooms', private_rooms );
                post_data.append( 'shared_rooms', shared_rooms );
                post_data.append( 'private_room_costmonth', private_room_costmonth );
                post_data.append( 'shared_room_costmonth', shared_room_costmonth );
                post_data.append( 'Listing_fulltext', Listing_fulltext );
                post_data.append( 'Listing_video', Listing_video );
                post_data.append( 'action', action );
                post_data.append('feature_listing', feature_listing);

              

              
                $.ajax({
                  url: ajaxUrl_action,
                  type: 'post',
                  processData: false,
                  contentType: false,
                  data: post_data,
                  success:function(data) {
                    console.log(data);
                    $("#jr-form-property-form")[0].reset();
                    $('.pip').hide();
                    $('img#blah').hide();
                    spinner.hide();
                    $('#add-success').removeClass('hidden');
                    setTimeout(function(){// wait for 5 secs(2)
                            location.reload(); // then reload the page.(3)
                            }, 1000);

                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
              });
            }
        });   
/*++++++++++++++++++++++++++++++ EDIT USER PROPERTY +++++++++++++++++++++++++++++++++++++++*/
      $('#jr-form-property-form-edit').validate({

            rules: {
                Listing_title: {         
                    required: true
                },
                pro_location_city: {          
                    selectcheck: true 
                },
                pro_location_address: {         
                    required: true
                },
                pro_location_state: {         
                    required: true
                },
                pro_location_zip_code: {         
                    required: true
                },
                contactInfo_phone_number: {         
                    required: true
                },
                contactInfo_license: {         
                    required: true
                },
                Listing_fulltext:{
                    required: true
                }/*,
                pro_img:{
                  required: true,
                //  maxfilesize : 2,
                   //  extension: "jpg|jpeg|png",
                    // filesize: 2097152
                },
                'add_propertymedia[]': {
                     required: true,
                    // maxfilesize : 2,
                    // extension: "jpg|jpeg|png",
                     //filesize: 2097152
                  }*/
            },
            messages: {              
                Listing_title: {
                      required:"Please Enter Listing Title."
                },
                pro_location_address: {
                      required:"Please Enter Address."
                },
                pro_location_state: {
                      required:"Please Enter State."
                },
                pro_location_zip_code: {
                      required:"Please Enter Zip Code."
                },
                contactInfo_phone_number: {
                      required:"Please Enter Phone Number."
                },
                contactInfo_license: {
                      required:"Please Enter License#."
                },
                Listing_fulltext: {
                      required:"Please Enter Description."
                },
              /*  pro_img:{
                  maxfilesize : "File size must not be more than 2 MB."
                },*/
              /*  'add_propertymedia[]':{
                     maxfilesize : "File size must not be more than 2 MB."
                }*/
            },

            submitHandler: function(form) {  
            //var form = $(form);
                          //tinyMCE.triggerSave();

              var fulltext = $("#Listing_fulltext").attr('name');
             // var video = $("#Listing_video").attr('name');
              CKEDITOR.instances[fulltext].updateElement();
            //  CKEDITOR.instances[video].updateElement();

               spinner.show();
               var vidFileLength = $( "#subscriber_image" ).length;
               //console.log(vidFileLength);
                var Listing_title = $("#Listing_title").val();
                var ajaxUrl_action = $("#ajaxUrl_action").val();
               // console.log(Listing_title);
                if ($("#feature_listing").is(":checked")){
                  var feature_listing = $("#feature_listing").val();

                }else{
                  var feature_listing = '';
                }

                var contactInfo_phone_number = $("#contactInfo_phone_number").val();
                var contactInfo_license = $("#contactInfo_license").val();
                var contactInfo_website_url = $("#contactInfo_website_url").val();

                var pro_location_address = $("#pro_location_address").val();
                var pro_location_city = $("#pro_location_city").val();
                var pro_location_state = $("#pro_location_state").val();
                var pro_location_zip_code = $("#pro_location_zip_code").val();
                var amenities=[];
                $("input:checkbox[name*=amenities]:checked").each(function(){
                     amenities.push($(this).val());
                });
                var services=[];
                $("input:checkbox[name*=services]:checked").each(function(){
                     services.push($(this).val());
                });
                var languages_spoken=[];
                $("input:checkbox[name*=languages_spoken]:checked").each(function(){
                     languages_spoken.push($(this).val());
                });
                if(vidFileLength > 0){
                var pro_img = $('input[name=pro_img]')[0].files[0];
                var files =$('input[name^=add_propertymedia')[0].files;

                }
                 var pcategory=[];
                $("input:checkbox[name*=pcategory]:checked").each(function(){
                     pcategory.push($(this).val());
                });
                //console.log(pcategory);
                var private_rooms = $("#private_rooms").val();
                var shared_rooms = $("#shared_rooms").val();
                var private_room_costmonth = $("#private_room_costmonth").val();
                var shared_room_costmonth = $("#shared_room_costmonth").val();
                var Listing_fulltext = $("#Listing_fulltext").val();
                var Listing_video = $("#Listing_video").val();
                var action = 'update_Property_User_Submit';
                var post_id = $("#post_id").val();
                var post_data = new FormData();    
                post_data.append( 'Listing_title', Listing_title );
                post_data.append( 'pro_location_address', pro_location_address );
                post_data.append( 'pro_location_city', pro_location_city );
                post_data.append( 'pro_location_state', pro_location_state );
                post_data.append( 'pro_location_zip_code', pro_location_zip_code );
                post_data.append( 'contactInfo_phone_number', contactInfo_phone_number );
                post_data.append( 'contactInfo_license', contactInfo_license );
                post_data.append( 'contactInfo_website_url', contactInfo_website_url );
                post_data.append( 'amenities', amenities );
                post_data.append( 'pcategory', pcategory );
                post_data.append( 'services', services );
                post_data.append( 'languages_spoken', languages_spoken );
                post_data.append( 'pro_img', pro_img );
                var files_data = $('#jr-form-property-form-edit .inputfile');
                $.each($(files_data), function(i, obj) {
                    $.each(obj.files,function(j,file){
                        post_data.append('add_propertymedia[' + j + ']', file);
                    })
                });
                post_data.append( 'private_rooms', private_rooms );
                post_data.append( 'shared_rooms', shared_rooms );
                post_data.append( 'private_room_costmonth', private_room_costmonth );
                post_data.append( 'shared_room_costmonth', shared_room_costmonth );
                post_data.append( 'Listing_fulltext', Listing_fulltext );
                post_data.append( 'Listing_video', Listing_video );
                post_data.append( 'action', action );
                post_data.append( 'post_id', post_id );
                post_data.append('feature_listing', feature_listing);
                $.ajax({
                  url: ajaxUrl_action,
                  type: 'post',
                  processData: false,
                  contentType: false,
                  data: post_data,
                  success:function(data) {
                    $("#jr-form-property-form-edit")[0].reset();
                    $('.pip').hide();
                    $('img#blah').hide();
                    spinner.hide();
                    $('#add-success').removeClass('hidden');
                    setTimeout(function(){// wait for 5 secs(2)
                    location.reload(); // then reload the page.(3)
                    }, 1000); 

                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
             });
            }
        });
    /*+++++++++++++++++++ LOGIN AJAX SUBMIT WITH VALIDATION ++++++++++++++++*/
          $('#user-account-log-in').validate({

            rules: {                
                prop_wpmp_email1: {
                  required: true,
                  email: true
                },
                prop_wpmp_password1: {         
                    required: true
                }
            },
            messages: {            
                
                prop_wpmp_email1: {
                  required:"The email is required.",              
                  email: "The email should be in the format: abc@domain.tld"
                },               
                prop_wpmp_password1: {
                      required:"The password is required."
                }
            },


            submitHandler: function(form) { 
               spinner.show(); 
                var ajaxUrl_action = $("#pro_ajaxUrl_action").val();  

                var action               = $("#logaction").val();  
                var prop_redirect_to = $("#prop_redirect_to").val();  
                var prop_wpmp_email1      = $("#prop_wpmp_email1").val();  
                var prop_wpmp_password1   = $("#prop_wpmp_password1").val(); 

                $.ajax({
                  url: ajaxUrl_action,
                  type: 'POST',
                  dataType: 'json',
                  data: {
                    'action'               : action, 
                    'prop_redirect_to' :prop_redirect_to,
                    'prop_wpmp_email1'      :prop_wpmp_email1,
                    'prop_wpmp_password1'   :prop_wpmp_password1
                  },
                  success:function(data) {
                    console.log(data);
                    spinner.hide();
                    if(data.loggedin == false){
                      $('#log-error').html(data.message);
                    }
                    if(data.loggedin == true){
                      $('#log-success').html(data.message);
                      $("#user-account-log-in")[0].reset();
                      if(prop_redirect_to == '1'){
                        location.reload();

                      }else{
                        window.location.replace(prop_redirect_to);
                      }
                      

                    }
                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
             });
            }
        });
/*+++++++++++++++++++ Registration AJAX SUBMIT WITH VALIDATION ++++++++++++++++*/


          $('#user-account-register').validate({
            ignore: ".ignore",

            rules: {
                prop_wpmp_fname: {         
                    required: true
                },
                prop_wpmp_email: {
                  required: true,
                  email: true
                },
                prop_wpmp_password: {         
                    required: true
                },
                prop_wpmp_password2: {
                    equalTo: "#prop_wpmp_password"
                },
                prop_wpmp_checkbox: {         
                    required: true
                },
               hiddenRecaptcha: {
                  required: function () {
                      if (grecaptcha.getResponse() == '') {
                          return true;
                      } else {
                          return false;
                      }
                  }
              }
            },
            messages: {              
                prop_wpmp_fname: {
                      required:"The Name is required."
                },
                prop_wpmp_email: {
                  required:"The email is required.",              
                  email: "The email should be in the format: abc@domain.tld"
                },               
                prop_wpmp_password: {
                      required:"The password is required."
                },
                prop_wpmp_password2: {
                  equalTo: "Please enter the same password as above."
                },
                prop_wpmp_checkbox: {
                      required:"Please accept the Terms of Service to register on the site."
                }
            },

            submitHandler: function(form) { 
            spinner.show(); 
                var ajaxUrl_action = $("#pro_ajaxUrl_action_reg").val();  

                var action               = $("#regaction").val();  
                var prop_redirection_url = $("#prop_redirection_url").val();  
                var prop_wpmp_fname      = $("#prop_wpmp_fname").val();  
                var prop_wpmp_email      = $("#prop_wpmp_email").val();  
                var prop_wpmp_password   = $("#prop_wpmp_password").val(); 

                $.ajax({
                  url: ajaxUrl_action,
                  type: 'POST',
                  data: {
                    'action'               : action, 
                    'prop_redirection_url' :prop_redirection_url,
                    'prop_wpmp_fname'      :prop_wpmp_fname,
                    'prop_wpmp_email'      :prop_wpmp_email,
                    'prop_wpmp_password'   :prop_wpmp_password
                  },
                  success:function(data) {
                    spinner.hide();
                    if(data.reg_status == false){
                      $('#reg-error').html(data.error);
                    }
                    if(data.reg_status == true){
                      $('#reg-success').html(data.success);
                      $("#user-account-register")[0].reset();
                      window.location.replace(prop_redirection_url);

                    }
                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
             });
            }
        }); 
  /*+++++++++++++++++++++++++++ Submit Claim Listing Form +++++++++++++++++++++++++++++++++*/

  $('.listing_submit').click(function() {
    var ajaxUrl_action         = $("#listing_ajaxUrl_action").val();
    var action                 = $("#listingaction").val();  
    var listing_user_id        = $("#listing_user_id").val();  
    var listing_post_id        = $("#listing_post_id").val();  
    var listing_name           = $("#listing_name").val();  
    var listing_email          = $("#listing_email").val(); 
    var listing_message        = $("#listing_message").val();
      $.ajax({
          url: ajaxUrl_action,
          type: 'POST',
          data: {
            'action'               : action, 
            'listing_user_id'      :listing_user_id,
            'listing_post_id'      :listing_post_id,
            'listing_name'         :listing_name,
            'listing_email'        :listing_email,
            'listing_message'      :listing_message
          },
          success:function(data) {
            if(data.reg_status == false){
              $('#pro-error').html(data.error);
            }
            if(data.reg_status == true){
              $('#listing_submit_form').hide();
              $('#pro-success').html(data.success);
              setTimeout(function(){// wait for 5 secs(2)
                location.reload(); // then reload the page.(3)
              }, 1000); 
             
            }
          },
          error: function(errorThrown){
              console.log(errorThrown);
          }
     });
  });                   
  
});

/*+++++++++++++++++++++++++++ Stripe Upgrade Subscription +++++++++++++++++++++++++++++++++*/

  function updateSubPlan(plan_id, sub_id){
      
            swal({
                title: "Are you sure?",
                text: "You Want to Upgrade Your Plan!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajaxurl,
                        type : "POST",
                        data : {'action' : 'stripe_membership_payment_upgrade', 'plan_id' :plan_id, 'sub_id' :sub_id},
                        success: function(data){
                            swal("Poof! Your Subscrition Plan has been Updated!", {
                            icon: "success",
                            });
                           location.reload(); 
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Subscription is safe!");
                }
            });
  } 
  /*+++++++++++++++++++++++++++ Stripe Cancel Subscription +++++++++++++++++++++++++++++++++*/

  function cancelSubPlan(plan_id, sub_id){
      
            swal({
                title: "Are you sure?",
                text: "You Want to Cancel Your Subscription!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajaxurl,
                        type : "POST",
                        data : {'action' : 'stripe_membership_payment_cancel', 'plan_id' :plan_id, 'sub_id' :sub_id},
                        success: function(data){
                            swal("Poof! Your Subscrition Plan has been Canceled!", {
                            icon: "success",
                            });
                           location.reload(); 
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Subscription is safe!");
                }
            });
  }       
/*============================================ DELETE Property ===========================================*/
  function delProperty(id){
      
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this Property!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajaxurl,
                        type : "POST",
                        data : {'action' : 'delete_Property_User_Submit', 'id' :id},
                        success: function(data){
                            swal("Poof! Your Property has been deleted!", {
                            icon: "success",
                            });
                            setTimeout(function(){// wait for 5 secs(2)
                            location.reload(); // then reload the page.(3)
                            }, 1000);
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Property is safe!");
                }
            });
  }
/*========================================= Google Capcha Validation ===============================*/
/*function submitUserRegistrationForm() {
    var response = grecaptcha.getResponse();
    if(response.length == 0) {
        //document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:#a94442;">Please verify you are not a robot.</span>';
        return false;
    }
    return true;
}
 
function verifyCaptcha() {
    document.getElementById('google-recaptcha-error').innerHTML = '';*/
/*}  
*//*============================================ END =================================================*/

