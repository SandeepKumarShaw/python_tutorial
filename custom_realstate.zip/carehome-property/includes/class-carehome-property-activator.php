<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */
class Carehome_Property_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		 require_once plugin_dir_path( __FILE__ ) . 'inc/Page_creation.php';
		 require_once plugin_dir_path( __FILE__ ) . 'inc/Table_creation.php';
		 /*--------- Corn Activate ------------------*/
		    if( !wp_next_scheduled( 'isa_add_every_three_minutes_event' ) ){
		        wp_schedule_event( time(), 'every_three_minutes', 'isa_add_every_three_minutes_event' );
		    }
		    if( !wp_next_scheduled( 'isa_add_every_weak_event_1st' ) ){
		        wp_schedule_event( time(), 'every_weakly_1st', 'isa_add_every_weak_event_1st' );
		    }
		    if( !wp_next_scheduled( 'isa_add_every_weak_event_2nd' ) ){
		        wp_schedule_event( time(), 'every_weakly_2nd', 'isa_add_every_weak_event_2nd' );
		    }
	}

}
