<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */
class Carehome_Property {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Carehome_Property_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'CAREHOME_PROPERTY_VERSION' ) ) {
			$this->version = CAREHOME_PROPERTY_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'carehome-property';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_admin_page_hooks();
		$this->define_public_rating_hooks();
		$this->define_public_archive_hooks();

		$this->define_user_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Carehomesdirect_Property_Loader. Orchestrates the hooks of the plugin.
	 * - Carehomesdirect_Property_i18n. Defines internationalization functionality.
	 * - Carehomesdirect_Property_Admin. Defines all hooks for the admin area.
	 * - Carehomesdirect_Property_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-carehome-property-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-carehome-property-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-carehome-property-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-carehome-property-admin-page.php';

		/**
		 * The class responsible for defining all actions that occur in the user area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'user/class-carehome-property-user.php';


		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-carehome-property-public.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-comment-rating.php';
		
		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-carehome-property-archieve-public.php';

		$this->loader = new Carehomesdirect_Property_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Carehomesdirect_Property_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Carehomesdirect_Property_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Carehomesdirect_Property_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$this->loader->add_action( 'init', $plugin_admin, 'propert_post_type_register' );

		$this->loader->add_filter( 'manage_posts_custom_column', $plugin_admin, 'site_custom_columns' );
		$this->loader->add_action( 'manage_edit-site_columns', $plugin_admin, 'site_edit_columns' );

		$this->loader->add_action( 'admin_init', $plugin_admin, 'add_custom_caps_property' );

		$this->loader->add_action( 'save_post', $plugin_admin, 'Lat_Long_save' );

		//$this->loader->add_filter( 'pre_get_posts', $plugin_admin, 'searchExcludeOldMatches', 999 );



		//$this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'location_add_meta_box' );

		//$this->loader->add_action( 'save_post', $plugin_admin, 'location_save' );
		//$this->loader->add_action( 'save_post', $plugin_admin, 'contact_information_save' );
		//$this->loader->add_action( 'save_post', $plugin_admin, 'gallery_meta_save' );

		//$this->loader->add_action( 'admin_menu', $plugin_admin, 'property_importer_page' );

               $this->loader->add_filter( 'cron_schedules', $plugin_admin, 'isa_add_every_three_minutes' );
        $this->loader->add_action( 'isa_add_every_three_minutes_event', $plugin_admin, 'isa_every_three_minutes_event_func' );
        $this->loader->add_action( 'isa_add_every_weak_event_1st', $plugin_admin, 'isa_add_every_weak_event_1st_func' );
        $this->loader->add_action( 'isa_add_every_weak_event_2nd', $plugin_admin, 'isa_add_every_weak_event_2nd_func' );

        $this->loader->add_filter( 'parse_query', $plugin_admin, 'wp_feature_property_filter',10,2 );

        $this->loader->add_action( 'after_setup_theme', $plugin_admin, 'remove_admin_bar' );

        

	}
	private function define_admin_page_hooks() {

		$plugin_admin_page = new Carehomesdirect_Property_Admin_Page();

		$this->loader->add_action( 'admin_menu', $plugin_admin_page, 'property_importer_page' );
		//$this->loader->add_action( 'admin_init', $plugin_admin_page, 'form_handler' );

		$this->loader->add_action( 'admin_init', $plugin_admin_page, 'stripepayments_settings_page_init' );
		$this->loader->add_action( 'admin_init', $plugin_admin_page, 'googlemap_capcha_api_settings_page_init' );
		$this->loader->add_action( 'wp_ajax_nopriv_property_stripe_plan_add', $plugin_admin_page, 'property_stripe_plan_add' );
		$this->loader->add_action( 'wp_ajax_property_stripe_plan_add', $plugin_admin_page, 'property_stripe_plan_add' );

		$this->loader->add_action( 'wp_ajax_nopriv_property_stripe_plan_del', $plugin_admin_page, 'property_stripe_plan_del' );
		$this->loader->add_action( 'wp_ajax_property_stripe_plan_del', $plugin_admin_page, 'property_stripe_plan_del' );

		$this->loader->add_action( 'wp_ajax_nopriv_property_claim_approved', $plugin_admin_page, 'property_claim_approved' );
		$this->loader->add_action( 'wp_ajax_property_claim_approved', $plugin_admin_page, 'property_claim_approved' );

		$this->loader->add_action( 'wp_ajax_nopriv_property_claim_unapproved', $plugin_admin_page, 'property_claim_unapproved' );
		$this->loader->add_action( 'wp_ajax_property_claim_unapproved', $plugin_admin_page, 'property_claim_unapproved' );

		$this->loader->add_filter( 'upload_size_limit', $plugin_admin_page, 'filter_site_upload_size_limit', 20 );

		$this->loader->add_action( 'wp_ajax_nopriv_property_form_handler', $plugin_admin_page, 'property_form_handler' );
		$this->loader->add_action( 'wp_ajax_property_form_handler', $plugin_admin_page, 'property_form_handler' );


        $this->loader->add_action( 'edit_user_profile', $plugin_admin_page, 'add_extra_user_fields' );
        $this->loader->add_action( 'edit_user_profile_update', $plugin_admin_page, 'save_extra_user_fields' );


	}
	/**
	 * Register all of the hooks related to the user area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_user_hooks() {

		$plugin_user_page = new Carehomesdirect_Property_User( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_user_page, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_user_page, 'enqueue_scripts' );


		$this->loader->add_shortcode( 'wp_welcome_dashboard_shortcode', $plugin_user_page, 'welcome_dashboard_shortcode' );
		$this->loader->add_shortcode( 'wp_upgrade_membership_shortcode', $plugin_user_page, 'upgrade_membership_shortcode' );

		$this->loader->add_shortcode( 'wp_your_listings_shortcode', $plugin_user_page, 'your_listings_shortcode' );
		$this->loader->add_shortcode( 'wp_add_your_care_home_shortcode', $plugin_user_page, 'add_your_care_home_shortcode' );

		$this->loader->add_shortcode( 'wp_update_your_property_shortcode', $plugin_user_page, 'edit_your_care_home_shortcode' );

		$this->loader->add_shortcode( 'wp_property_sign_up_shortcode', $plugin_user_page, 'wp_property_my_acccount' );



		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment', $plugin_user_page, 'stripe_membership_payment' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment', $plugin_user_page, 'stripe_membership_payment' );

		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment_upgrade', $plugin_user_page, 'stripe_membership_payment_upgrade' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment_upgrade', $plugin_user_page, 'stripe_membership_payment_upgrade' );

		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment_cancel', $plugin_user_page, 'stripe_membership_payment_cancel' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment_cancel', $plugin_user_page, 'stripe_membership_payment_cancel' );


		$this->loader->add_shortcode( 'WP_Property_User_Archieve_shortcode', $plugin_user_page, 'Property_User_Archieve_shortcode' );

		$this->loader->add_action( 'wp_ajax_nopriv_Add_Property_User_Submit', $plugin_user_page, 'Add_Property_User_Submit' );
		$this->loader->add_action( 'wp_ajax_Add_Property_User_Submit', $plugin_user_page, 'Add_Property_User_Submit' );


		$this->loader->add_action( 'wp_ajax_nopriv_update_Property_User_Submit', $plugin_user_page, 'update_Property_User_Submit' );
		$this->loader->add_action( 'wp_ajax_update_Property_User_Submit', $plugin_user_page, 'update_Property_User_Submit' );

		$this->loader->add_action( 'wp_ajax_nopriv_delete_Property_User_Submit', $plugin_user_page, 'delete_Property_User_Submit' );
		$this->loader->add_action( 'wp_ajax_delete_Property_User_Submit', $plugin_user_page, 'delete_Property_User_Submit' );

		$this->loader->add_action( 'wp_ajax_nopriv_PropertyLoginProcess', $plugin_user_page, 'PropertyLoginProcess' );
		$this->loader->add_action( 'wp_ajax_PropertyLoginProcess', $plugin_user_page, 'PropertyLoginProcess' );

		$this->loader->add_action( 'wp_ajax_nopriv_PropertyRegistrationProcess', $plugin_user_page, 'PropertyRegistrationProcess' );
		$this->loader->add_action( 'wp_ajax_PropertyRegistrationProcess', $plugin_user_page, 'PropertyRegistrationProcess' );

		$this->loader->add_filter( 'login_redirect', $plugin_user_page, 'my_login_redirect', 10, 3 );

		$this->loader->add_action( 'wp_ajax_nopriv_ClaimListingProcess', $plugin_user_page, 'ClaimListingProcess' );
		$this->loader->add_action( 'wp_ajax_ClaimListingProcess', $plugin_user_page, 'ClaimListingProcess' );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Carehomesdirect_Property_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		$this->loader->add_filter( 'template_include', $plugin_public, 'include_template_function', 1 );


		$this->loader->add_action( 'wp_ajax_nopriv_contact_send_ajax_request', $plugin_public, 'contact_send_ajax_request' );
		$this->loader->add_action( 'wp_ajax_contact_send_ajax_request', $plugin_public, 'contact_send_ajax_request' );

		$this->loader->add_action( 'wp_head', $plugin_public, 'count_post_visits' );

	}
	private function define_public_rating_hooks() {

		$plugin_public_rating = new Comment_Rating( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public_rating, 'property_comment_rating_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public_rating, 'property_ajax_comments_scripts' );

		$this->loader->add_action( 'comment_form_logged_in_after', $plugin_public_rating, 'property_comment_rating_rating_field' );
		$this->loader->add_action( 'comment_form_after_fields', $plugin_public_rating, 'property_comment_rating_rating_field' );
		$this->loader->add_action( 'comment_post', $plugin_public_rating, 'property_comment_rating_save_comment_rating' );
		$this->loader->add_filter( 'preprocess_comment', $plugin_public_rating, 'property_comment_rating_require_rating' );
		$this->loader->add_filter( 'comment_text', $plugin_public_rating, 'property_comment_rating_display_rating' );
		$this->loader->add_shortcode( 'comment_rating_display_rating', $plugin_public_rating, 'property_comment_rating_display_average_rating' );

		$this->loader->add_filter( 'comment_form_default_fields', $plugin_public_rating, 'property_comment_remove_comment_url' );
		//$this->loader->add_filter( 'comment_form_logged_in', $plugin_public_rating, 'property_comment_form_logged_in', 10, 3 );
		$this->loader->add_filter( 'comments_open', $plugin_public_rating, 'property_comments_open', 10, 2 );


		$this->loader->add_action( 'wp_ajax_ajaxcomments', $plugin_public_rating, 'property_submit_ajax_comment' );
		$this->loader->add_action( 'wp_ajax_nopriv_ajaxcomments', $plugin_public_rating, 'property_submit_ajax_comment' );

		$this->loader->add_action( 'comment_form_before', $plugin_public_rating, 'property_comment_top_button' );
       // $this->loader->add_filter( 'comments_open', $plugin_public_rating, 'restrict_users', 10, 2);



    }
    private function define_public_archive_hooks() {

		$plugin_public_archive = new Carehomesdirect_Property_Archieve_Public( $this->get_plugin_name(), $this->get_version() );
			
		$this->loader->add_filter( 'archive_template', $plugin_public_archive, 'get_property_template' );
		$this->loader->add_action( 'pre_get_posts', $plugin_public_archive, 'property_meta_query_page' );

		$this->loader->add_shortcode( 'WP_Property_Archieve_shortcode', $plugin_public_archive, 'Property_Archieve_shortcode' );

		$this->loader->add_shortcode( 'WP_Property_Advanced_Search_shortcode', $plugin_public_archive, 'Property_Advanced_Search_shortcode' );

		$this->loader->add_action( 'wp_loaded', $plugin_public_archive, 'my_custom_redirect' );

		$this->loader->add_action( 'widgets_init', $plugin_public_archive, 'Property_Search_load_widget' );

		$this->loader->add_shortcode( 'wp_property_map_search_shortcode', $plugin_public_archive, 'property_map_search_shortcode' );


		$this->loader->add_action( 'wp_ajax_nopriv_property_map_search_Ajax', $plugin_public_archive, 'property_map_search_Ajax' );
		$this->loader->add_action( 'wp_ajax_property_map_search_Ajax', $plugin_public_archive, 'property_map_search_Ajax' );


		$this->loader->add_action( 'posts_where', $plugin_public_archive, 'wpse18703_posts_where', 10, 2 );





	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Carehomesdirect_Property_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
