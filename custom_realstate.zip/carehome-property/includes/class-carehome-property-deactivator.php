<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Carehome_Property
 * @subpackage Carehome_Property/includes
 */
class Carehome_Property_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

        global $wpdb;


        $advanced_search_title = get_option( "advanced_search_page_title" );
        $advanced_search_name = get_option( "advanced_search_page_name" );
        //  the id of our page...
        $advanced_search_id = get_option( 'advanced_search_page_id' );
        if( $advanced_search_id ) {
            wp_delete_post( $advanced_search_id ); // this will trash, not delete
        }
        delete_option("advanced_search_page_title");
        delete_option("advanced_search_page_name");
        delete_option("advanced_search_page_id");

        

        $welcome_dashboard_title = get_option( "welcome_dashboard_page_title" );
        $welcome_dashboard_name = get_option( "welcome_dashboard_page_name" );
        //  the id of our page...
        $welcome_dashboard_id = get_option( 'welcome_dashboard_page_id' );
        if( $welcome_dashboard_id ) {
            wp_delete_post( $welcome_dashboard_id ); // this will trash, not delete
        }
        delete_option("welcome_dashboard_page_title");
        delete_option("welcome_dashboard_page_name");
        delete_option("welcome_dashboard_page_id");




        $your_listings_title = get_option( "your_listings_page_title" );
        $your_listings_name = get_option( "your_listings_page_name" );
        //  the id of our page...
        $your_listings_id = get_option( 'your_listings_page_id' );
        if( $your_listings_id ) {
            wp_delete_post( $your_listings_id ); // this will trash, not delete
        }
        delete_option("your_listings_page_title");
        delete_option("your_listings_page_name");
        delete_option("your_listings_page_id");




        $add_your_care_home_title = get_option( "add_your_care_home_page_title" );
        $add_your_care_home_name = get_option( "add_your_care_home_page_name" );
        //  the id of our page...
        $add_your_care_home_id = get_option( 'add_your_care_home_page_id' );
        if( $add_your_care_home_id ) {
            wp_delete_post( $add_your_care_home_id ); // this will trash, not delete
        }
        delete_option("add_your_care_home_page_title");
        delete_option("add_your_care_home_page_name");
        delete_option("add_your_care_home_page_id");


        $upgrade_membership_title = get_option( "upgrade_membership_page_title" );
        $upgrade_membership_name = get_option( "upgrade_membership_page_name" );
        //  the id of our page...
        $upgrade_membership_id = get_option( 'upgrade_membership_page_id' );
        if( $upgrade_membership_id ) {
            wp_delete_post( $upgrade_membership_id ); // this will trash, not delete
        }
        delete_option("upgrade_membership_page_title");
        delete_option("upgrade_membership_page_name");
        delete_option("upgrade_membership_page_id");

        $property_map_search_title = get_option( "property_map_search_page_title" );
        $property_map_search_name = get_option( "property_map_search_page_name" );
        //  the id of our page...
        $property_map_search_id = get_option( 'property_map_search_page_id' );
        if( $property_map_search_id ) {
            wp_delete_post( $property_map_search_id ); // this will trash, not delete
        }
        delete_option("property_map_search_page_title");
        delete_option("property_map_search_page_name");
        delete_option("property_map_search_page_id");

        $update_your_property_title = get_option( "update_your_property_page_title" );
        $update_your_property_name = get_option( "update_your_property_page_name" );
        //  the id of our page...
        $update_your_property_id = get_option( 'update_your_property_page_id' );
        if( $update_your_property_id ) {
            wp_delete_post( $update_your_property_id ); // this will trash, not delete
        }
        delete_option("update_your_property_page_title");
        delete_option("update_your_property_page_name");
        delete_option("update_your_property_page_id");

        $property_sign_up_title = get_option( "property_sign_up_page_title" );
        $property_sign_up_name = get_option( "property_sign_up_page_name" );
        //  the id of our page...
        $property_sign_up_id = get_option( 'property_sign_up_page_id' );
        if( $property_sign_up_id ) {
            wp_delete_post( $property_sign_up_id ); // this will trash, not delete
        }
        delete_option("property_sign_up_page_title");
        delete_option("property_sign_up_page_name");
        delete_option("property_sign_up_page_id");

        /*--------- Corn Deactivate ------------------*/
            if( wp_next_scheduled( 'isa_add_every_three_minutes_event' ) ){
                wp_clear_scheduled_hook( 'isa_add_every_three_minutes_event' );
            }
            if( wp_next_scheduled( 'isa_add_every_weak_event_1st' ) ){
                wp_clear_scheduled_hook( 'isa_add_every_weak_event_1st' );
            }
             if( wp_next_scheduled( 'isa_add_every_weak_event_2nd' ) ){
                wp_clear_scheduled_hook( 'isa_add_every_weak_event_2nd' );
            }
        /*--------------------- Delete CSV FIle -------------------------*/
        $filepath = ABSPATH . 'wp-content/uploads/sample.csv';
        if ( file_exists( $filepath ) ) {
           @unlink( $filepath );
           $filepathName = ABSPATH . 'wp-content/uploads/sample.csv';
        }

        $filepath1 = ABSPATH . 'wp-content/uploads/sample1.csv';
        if ( file_exists( $filepath1 ) ) {
           @unlink( $filepath1 );
        }


	}

}
