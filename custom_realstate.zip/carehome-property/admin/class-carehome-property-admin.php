<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin
 */
class Carehomesdirect_Property_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */

    private $type = 'property';
    private $slug = 'properties';
    private $name = 'Properties';
    private $singular_name = 'Property';

    public $meta_fields = array(
        'title',
        'description',
        'siteurl',
        'category',
        'post_tags'
    );

    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/carehome-property-admin.css', array() , $this->version, 'all');

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wp-gallery-metabox-admin.css', array() , $this->version, 'all');
        wp_enqueue_style('custm_wp_gallery_metabox', plugin_dir_url(__FILE__) . 'css/custm_wp_gallery_metabox.css', '', time());
        wp_enqueue_style('gallery-metabox_cstm_css', plugin_dir_url(__FILE__) . 'css/gallery-metabox.css', '', time());
        wp_enqueue_style('datatables-min_css', plugin_dir_url(__FILE__) . 'DataTables/datatables.min.css', '', time());
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name . '-jquery-validate', plugin_dir_url(__FILE__) . 'js/jquery.validate.min.js', array(
            'jquery'
        ) , $this->version, false);

        wp_enqueue_script($this->plugin_name . '-sweetalert-js', plugin_dir_url(__FILE__) . 'js/sweetalert.min.js', array(
            'jquery'
        ) , $this->version, false);

        wp_enqueue_script($this->plugin_name . '-datatables-js', plugin_dir_url(__FILE__) . 'DataTables/datatables.min.js', array(
            'jquery'
        ) , $this->version, false);
        //wp_enqueue_script($this->plugin_name . '-sweetalert-js', 'https://unpkg.com/sweetalert/dist/sweetalert.min.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->plugin_name . 'ajax-js', plugin_dir_url(__FILE__) . 'js/test.js', array(
            'jquery'
        ) , $this->version, false);
        wp_localize_script($this->plugin_name . 'ajax-js', 'ajax_params', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/carehome-property-admin.js', array(
            'jquery'
        ) , $this->version, false);
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wp-gallery-metabox-admin.js', array(
            'jquery'
        ) , $this->version, false);
        wp_enqueue_script('gallery_metabox_cstm_js', plugin_dir_url(__FILE__) . 'js/gallery-metabox.js', '', time());
    }
    public function propert_post_type_register()
    {
        $labels = array(
            'name' => $this->name,
            'singular_name' => $this->singular_name,
            'add_new' => 'Add New',
            'add_new_item' => 'Add New ' . $this->singular_name,
            'edit_item' => 'Edit ' . $this->singular_name,
            'new_item' => 'New ' . $this->singular_name,
            'all_items' => 'All ' . $this->name,
            'view_item' => 'View ' . $this->name,
            'search_items' => 'Search ' . $this->name,
            'not_found' => 'No ' . strtolower($this->name) . ' found',
            'not_found_in_trash' => 'No ' . strtolower($this->name) . ' found in Trash',
            'parent_item_colon' => '',
            'menu_name' => $this->name
        );
        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array(
                'slug' => $this->slug
            ) ,
            'map_meta_cap' => true,
            // map_meta_cap will allow us to remap the existing capabilities with new capabilities to match the new custom post type
            // capabilities are what we are customising so lets remap them
            'capabilities' => array(
                'edit_post' => 'edit_' . $this->type,
                'edit_posts' => 'edit_' . $this->slug,
                'edit_others_posts' => 'edit_other_' . $this->slug,
                'publish_posts' => 'publish_' . $this->slug,
                'edit_publish_posts' => 'edit_publish_' . $this->slug,
                'read_post' => 'read_' . $this->slug,
                'read_private_posts' => 'read_private_' . $this->slug,
                'delete_post' => 'delete_' . $this->type
            ) ,
            // capability_type defines how to make words plural, by default the
            // second word has an 's' added to it and for 'article' that's fine
            // however when it comes to words like book the plural would become
            // books so it's worth adding your own regardless of the plural.
            'capability_type' => array(
                $this->type,
                $this->slug
            ) ,

            'has_archive' => true,
            'hierarchical' => true,
            'menu_position' => 8,
            'taxonomies' => array(
                'category'
            ) ,
            'menu_icon' => 'dashicons-admin-home',
            'supports' => array(
                'title',
                'editor',
                'author',
                'thumbnail',
                'comments'
            ) ,
            'yarpp_support' => true
        );
        register_post_type($this->type, $args);

    }
    public function site_edit_columns($columns)
    {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => 'Property Title',
            'url' => 'URL',
            'category' => 'Category',
            'post_tags' => 'Tags',
            'siteurl' => 'Screenshot',
        );
        return $columns;
    }
    public function site_custom_columns($column)
    {
        global $post;
        switch ($column)
        {
            case "title":
                the_title();
            break;
            case "url":
                $m = $this->mshot(150);
                echo '<a href="' . $m[0] . '" target="_blank">' . $m[0] . '</a>';
            break;
            case "category":
                the_category();
            break;
            case "post_tags":
                the_tags('', ', ');
            break;
            case "siteurl":
                $m = $this->mshot(150);
                echo $m[1];
            break;
        }
    }
    public function add_custom_caps_property()
    {
        // gets the subscriber role
        $role = get_role('subscriber');

        // gets the role to add capabilities to
        $admin = get_role('administrator');
        $subscriber = get_role('subscriber');
        // replicate all the remapped capabilites from the custom post type article
        $caps = array(
            'edit_' . $this->type,
            'edit_' . $this->slug,
            'edit_other_' . $this->slug,
            'publish_' . $this->slug,
            'edit_published_' . $this->slug,
            'read_' . $this->slug,
            'read_private_' . $this->slug,
            //'delete_'.$this->type,
            'delete_' . $this->slug,
            'delete_private_' . $this->slug,
            'delete_published_' . $this->slug,
            'delete_others_' . $this->slug,
        );
        // give all the capabilities to the administrator
        foreach ($caps as $cap)
        {
            $admin->add_cap($cap);
        }
        // limited the capabilities to the subscriber or a custom role
        /*$subscriber->remove_cap( 'edit_'.$this->type );
        $subscriber->remove_cap( 'edit_'.$this->slug );
        $subscriber->remove_cap( 'read_'.$this->slug );
        $subscriber->remove_cap( 'publish_'.$this->slug );
        $subscriber->remove_cap( 'delete_'.$this->slug );*/
    }
    public function Lat_Long_save($post_id)
    {
        global $post;
        if (get_post_type() == 'property')
        {
            return;
        }    
        $proerty_lat = get_post_meta($post_id, 'proerty_lat', true);
        $property_long = get_post_meta($post_id, 'property_long', true);

        // Check if the custom field has a value.
        if (empty($proerty_lat) && empty($property_long))
        {
            $jr_address = get_post_meta($post_id, 'pro_location_address', true);
            if (isset($jr_address) && !empty($jr_address))
            {

                $googlemap_capcha_api = get_option('googlemap_capcha_api_settings_option_name');
                $Mapkey = $googlemap_capcha_api['google_maps_api_browser_key_2'];
                if (isset($Mapkey))
                {
                    $mapApiKey = $Mapkey;
                }
                else
                {
                    $mapApiKey = 'AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ';
                }

                $pro_location_address = $result->jr_address;
                $prepAddr = str_replace(' ', '+', $pro_location_address);
                $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $prepAddr . '&key=' . $mapApiKey);
                $output = json_decode($geocode);
                $latitude = $output->results[0]
                    ->geometry
                    ->location->lat;
                $longitude = $output->results[0]
                    ->geometry
                    ->location->lng;

                update_post_meta($post_id, 'proerty_lat', $latitude);
                update_post_meta($post_id, 'property_long', $longitude);

            }
            else
            {
                $latitude = '';
                $longitude = '';
                update_post_meta($post_id, 'proerty_lat', $latitude);
                update_post_meta($post_id, 'property_long', $longitude);

            }
        }

    }
    // The schedule filter hook
    public function isa_add_every_three_minutes($schedules)
    {
        $schedules['every_three_minutes'] = array(
            'interval' => 180,
            'display' => __('Every 3 Minutes', 'textdomain')
        );
        $schedules['every_weakly_1st'] = array(
            'interval' => 604800, //2592000
            'display' => __('Every 1 Week 1st Corn', 'textdomain')
        );
        $schedules['every_weakly_2nd'] = array(
            'interval' => 605800, //2592000
            'display' => __('Every 1 Week 2nd Corn', 'textdomain')
        );
        return $schedules;
    }
    // The WP Cron event callback function
    public function isa_every_three_minutes_event_func()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'corn_property_mapping';
        $status = 1;
        $sql = "SELECT * FROM " . $table_name . " WHERE status = " . $status . " LIMIT 0,10";
        $results = $wpdb->get_results($sql);
        if (!empty($results))
        {
            $count = 0;
            foreach ($results as $result)
            {
                $count++;
                $title = $result->post_title;
                if (empty(get_page_by_title($title, OBJECT, 'property')))
                {
                    if ($result->post_author == 0)
                    {
                        $uesr_id = 41;
                    }
                    else
                    {
                        $uesr_id = $result->post_author;
                    }
                    $post = array( //our wp_insert_post args
                        'post_title' => wp_strip_all_tags($result->post_title) ,
                        'post_content' => $result->post_content,
                        'post_name' => $result->post_name,
                        'post_date' => $result->post_date,
                        'post_status' => $result->post_status,
                        'post_type' => 'property',
                        'post_author' => $uesr_id
                    );
                    $post_id = wp_insert_post($post);
                    if (isset($result->jr_amenities) && !empty($result->jr_amenities))
                    {
                        $jr_amenities = unserialize($result->jr_amenities);
                        foreach ($jr_amenities as $key => $value)
                        {
                            if (empty($value))
                            {
                                //echo "$key empty <br/>";
                                
                            }
                            else
                            {
                                update_post_meta($post_id, 'amenities', $jr_amenities);
                            }
                        }
                    }
                    if (isset($result->jr_services) && !empty($result->jr_services))
                    {
                        $jr_services = unserialize($result->jr_services);
                        foreach ($jr_services as $key => $value)
                        {
                            if (empty($value))
                            {
                                //echo "$key empty <br/>";
                                
                            }
                            else
                            {
                                update_post_meta($post_id, 'services', $jr_services);
                            }
                        }
                    }
                    if (isset($result->jr_languagesspoken) && !empty($result->jr_languagesspoken))
                    {
                        $jr_languagesspoken = unserialize($result->jr_languagesspoken);
                        foreach ($jr_languagesspoken as $key => $value)
                        {
                            if (empty($value))
                            {
                                //echo "$key empty <br/>";
                                
                            }
                            else
                            {
                                update_post_meta($post_id, 'languages_spoken', $jr_languagesspoken);
                            }
                        }
                    }
                    update_post_meta($post_id, '_is_featured', $result->featured);

                    update_post_meta($post_id, 'pro_location_address', $result->jr_address);
                    update_post_meta($post_id, 'pro_location_city', $result->jr_city);
                    update_post_meta($post_id, 'pro_location_state', $result->jr_state);
                    update_post_meta($post_id, 'pro_location_zip_code', $result->jr_postalcode);
                    update_post_meta($post_id, 'private_rooms', $result->jr_availablebedsinprivaterooms);
                    update_post_meta($post_id, 'shared_rooms', $result->jr_availablebedsinsharedrooms);
                    update_post_meta($post_id, 'private_room_costmonth', $result->jr_privateroomcostmonth);
                    update_post_meta($post_id, 'shared_room_costmonth', $result->jr_sharedroomcostmonth);
                    //update_post_meta( $post_id, 'property_video', $result->post_author );
                    update_post_meta($post_id, 'contactInfo_phone_number', $result->jr_phonenumber);
                    update_post_meta($post_id, 'contactInfo_license', $result->jr_license);
                    update_post_meta($post_id, 'contactInfo_website_url', $result->jr_website);
                    wp_set_post_terms($post_id, $result->term_id, 'category');

                    $proerty_lat = get_post_meta($post_id, 'proerty_lat', true);
                    $property_long = get_post_meta($post_id, 'property_long', true);

                    // Check if the custom field has a value.
                    if (empty($proerty_lat) && empty($property_long))
                    {

                        if (isset($result->jr_address) && !empty($result->jr_address))
                        {

                            $googlemap_capcha_api = get_option('googlemap_capcha_api_settings_option_name');
                            $Mapkey = $googlemap_capcha_api['google_maps_api_browser_key_2'];
                            if (isset($Mapkey))
                            {
                                $mapApiKey = $Mapkey;
                            }
                            else
                            {
                                $mapApiKey = 'AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ';
                            }

                            $pro_location_address = $result->jr_address;
                            $prepAddr = str_replace(' ', '+', $pro_location_address);
                            $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $prepAddr . '&key=' . $mapApiKey);
                            $output = json_decode($geocode);
                            $latitude = $output->results[0]
                                ->geometry
                                ->location->lat;
                            $longitude = $output->results[0]
                                ->geometry
                                ->location->lng;

                            update_post_meta($post_id, 'proerty_lat', $latitude);
                            update_post_meta($post_id, 'property_long', $longitude);

                        }
                        else
                        {
                            $latitude = '';
                            $longitude = '';
                            update_post_meta($post_id, 'proerty_lat', $latitude);
                            update_post_meta($post_id, 'property_long', $longitude);

                        }
                    }

                    if (isset($result->term_name))
                    {
                        //$cat1 = trim($result->term_name);
                        $cat1 = trim($result->term_name);
                    }
                    /*	            $cat_ids = [];
                    $cat1_id = $this->insert_cat_id($cat1, 0);
                    if($cat1_id) $cat_ids[] = $cat1_id;  */
                    wp_set_post_terms($post_id, $cat1, 'category');
                    $cstatus = 0;

                    $delSql = "UPDATE " . $table_name . " SET status= " . $cstatus . " WHERE ID = '" . $result->ID . "'";
                    $wpdb->query($delSql);
                    if (($count % 2) == 0)
                    {
                        sleep(1);
                    }

                }
                else
                {

                    $cstatus = 0;
                    $delSql = "UPDATE " . $table_name . " SET status= " . $cstatus . " WHERE ID = '" . $result->ID . "'";
                    $wpdb->query($delSql);
                    if (($count % 2) == 0)
                    {
                        sleep(1);
                    }

                }
            }
        }
        //@mysqli_close( $wpdb->dbh );
        $wpdb->close();
        die();
    }
    public function isa_add_every_weak_event_1st_func()
    {
        // If the function it's not available, require it.
        if (!function_exists('download_url'))
        {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // Now you can use it!
        $file_url = 'https://www.ccld.dss.ca.gov/transparencyapi/api/DownloadStateData?id=ResidentialElderCareFacility&GUID=77262e17-8559-490d-9af0-fdd7814c493d';
        $tmp_file = download_url($file_url);

        // Sets file final destination.
        $filepath = ABSPATH . 'wp-content/uploads/sample1.csv';
        if (file_exists($filepath))
        {
            @unlink($filepath);
            $filepathName = ABSPATH . 'wp-content/uploads/sample1.csv';
        }
        else
        {
            $filepathName = $filepath;
        }

        // Copies the file to the final destination and deletes temporary file.
        copy($tmp_file, $filepathName);
        @chmod($filepathName, 0777);

        @unlink($tmp_file);

        //$fullsize_path = get_attached_file($upload_id);
        if (!empty($filepathName))
        {
            @ini_set('max_execution_time', 0);
            $ext = pathinfo($filepathName, PATHINFO_EXTENSION);
            if ($ext != 'csv')
            {
                'Not a .csv file.';
                return;
            }

            $row = 0;
            $headers = [];
            if (($handle = fopen($filepathName, "r")) !== false)
            {
                while (($data = fgetcsv($handle, 1000, ",")) !== false)
                {
                    if (++$row == 1)
                    {
                        $headers = array_flip($data); // Get the column names from the header.
                        continue;
                    }
                    else
                    {
                        if (isset($data[$headers['Facility Name']]))
                        {
                            $col1 = $data[$headers['Facility Name']]; // Read row by the column name.
                            $col11 = str_replace("'", "", $col1);
                            $col111 = str_replace(",", "", $col11);
                        }
                        if (isset($data[$headers['Licensee']]))
                        {
                            $col2 = $data[$headers['Licensee']];
                            $col4 = str_replace("'", "", $col2);
                            $col3 = str_replace(",", "", $col4);
                        }
                        if (isset($data[$headers['Facility Telephone Number']]))
                        {
                            $col5 = $data[$headers['Facility Telephone Number']];
                        }
                        if (isset($data[$headers['Facility Address']]))
                        {
                            $col46 = $data[$headers['Facility Address']];
                            $col466 = str_replace("'", "", $col46);
                            $col6 = str_replace(",", "", $col466);
                            $latitude = '';
                            $longitude = '';
                        }
                        else
                        {
                            $latitude = '';
                            $longitude = '';
                            $col6 = '';
                        }
                        if (isset($data[$headers['Facility City']]))
                        {
                            $col7 = $data[$headers['Facility City']];
                        }
                        if (isset($data[$headers['Facility State']]))
                        {
                            $col8 = $data[$headers['Facility State']];
                        }
                        if (isset($data[$headers['Facility Zip']]))
                        {
                            $col9 = $data[$headers['Facility Zip']];
                        }
                        if (isset($data[$headers['Facility Type']]))
                        {
                            $colftype = $data[$headers['Facility Type']];
                        }
                        /*if(isset($data[$headers['Facility Gallery']])){
                        $wordpress_upload_dir = wp_upload_dir();
                        $col11 = $data[$headers['Facility Gallery']];
                        $allimages = explode("|",trim($col11));
                        $attarray = array();
                        foreach($allimages as $imgname) {
                        array_push($attarray, $imgname);
                        }
                        $image_url = Serialize($attarray);
                        
                        }else{
                        $image_url = '';
                        }*/

                        $col10 = '6';
                        $image_url = '';

                        global $wpdb;
                        $table_name = $wpdb->prefix . 'corn_property_mapping';
                        $sqls = "SELECT  COUNT(*) FROM " . $table_name . " WHERE post_title = '" . $col111 . "'";
                        $resultss = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `" . $table_name . "` WHERE `post_title` = %s", $col111));

                        //$resultss = $wpdb->get_var($sqls);
                        if ($resultss == 0)
                        {
                            $user_id = get_current_user_id();
                            $status = 1;

                            $sql1 = "INSERT INTO " . $table_name . " (`post_title`,`post_status`,`post_type`,`post_name`,`jr_state`,`jr_city`,`jr_address`,`jr_postalcode`,`jr_phonenumber`,`jr_latitude`,`jr_longitude`, `jr_license`, `term_name`, `new_rel_path`,`post_author`, `status`) values ('" . $col111 . "', 'publish', 'property', '" . $col111 . "', '" . $col8 . "', '" . $col7 . "', '" . $col6 . "', '" . $col9 . "', '" . $col5 . "', '" . $latitude . "', '" . $longitude . "', '" . $col3 . "', '" . $col10 . "', '" . $image_url . "', '" . $user_id . "', '" . $status . "')";
                            $wpdb->query($sql1);
                        }
                    }
                }
                fclose($handle);
                $args = ['page' => 'property-importer', ];
                $actionurl = add_query_arg($args, admin_url('admin.php'));
                wp_redirect($actionurl);
                die;
            }
        }
    }
    public function isa_add_every_weak_event_2nd_func()
    {
        // If the function it's not available, require it.
        if (!function_exists('download_url'))
        {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // Now you can use it!
        $file_url = 'https://www.ccld.dss.ca.gov/transparencyapi/api/DownloadStateData?id=AdultResidentialFacilities&GUID=77262e17-8559-490d-9af0-fdd7814c493d';
        $tmp_file = download_url($file_url);

        // Sets file final destination.
        $filepath = ABSPATH . 'wp-content/uploads/sample.csv';
        if (file_exists($filepath))
        {
            @unlink($filepath);
            $filepathName = ABSPATH . 'wp-content/uploads/sample.csv';
        }
        else
        {
            $filepathName = $filepath;
        }
        // Copies the file to the final destination and deletes temporary file.
        copy($tmp_file, $filepathName);
        @chmod($filepathName, 0777);
        @unlink($tmp_file);
        //$fullsize_path = get_attached_file($upload_id);
        if (!empty($filepathName))
        {
            @ini_set('max_execution_time', 0);
            $ext = pathinfo($filepathName, PATHINFO_EXTENSION);
            if ($ext != 'csv')
            {
                'Not a .csv file.';
                return;
            }

            $row = 0;
            $headers = [];
            if (($handle = fopen($filepathName, "r")) !== false)
            {
                while (($data = fgetcsv($handle, 1000, ",")) !== false)
                {
                    if (++$row == 1)
                    {
                        $headers = array_flip($data); // Get the column names from the header.
                        continue;
                    }
                    else
                    {

                        if (isset($data[$headers['Facility Name']]))
                        {
                            $col1 = $data[$headers['Facility Name']]; // Read row by the column name.
                            $col11 = str_replace("'", "", $col1);
                            $col111 = str_replace(",", "", $col11);
                        }
                        if (isset($data[$headers['Licensee']]))
                        {
                            $col2 = $data[$headers['Licensee']];
                            $col4 = str_replace("'", "", $col2);
                            $col3 = str_replace(",", "", $col4);
                        }
                        if (isset($data[$headers['Facility Telephone Number']]))
                        {
                            $col5 = $data[$headers['Facility Telephone Number']];
                        }
                        if (isset($data[$headers['Facility Address']]))
                        {
                            $col46 = $data[$headers['Facility Address']];
                            $col466 = str_replace("'", "", $col46);
                            $col6 = str_replace(",", "", $col466);
                            $latitude = '';
                            $longitude = '';
                        }
                        else
                        {
                            $latitude = '';
                            $longitude = '';
                            $col6 = '';
                        }
                        if (isset($data[$headers['Facility City']]))
                        {
                            $col7 = $data[$headers['Facility City']];
                        }
                        if (isset($data[$headers['Facility State']]))
                        {
                            $col8 = $data[$headers['Facility State']];
                        }
                        if (isset($data[$headers['Facility Zip']]))
                        {
                            $col9 = $data[$headers['Facility Zip']];
                        }
                        if (isset($data[$headers['Facility Type']]))
                        {
                            $colftype = $data[$headers['Facility Type']];
                        }
                        /*if(isset($data[$headers['Facility Gallery']])){
                        $wordpress_upload_dir = wp_upload_dir();
                        $col11 = $data[$headers['Facility Gallery']];
                        $allimages = explode("|",trim($col11));
                        $attarray = array();
                        foreach($allimages as $imgname) {
                        array_push($attarray, $imgname);
                        }
                        $image_url = Serialize($attarray);
                        
                        }else{
                        $image_url = '';
                        }*/

                        /*if(isset($colftype)){
                        $col10 = $colftype;
                        }else{
                        $col10 = '';
                        }*/

                        $col10 = '6';
                        $image_url = '';

                        global $wpdb;
                        $table_name = $wpdb->prefix . 'corn_property_mapping';
                        $sqls = "SELECT  COUNT(*) FROM " . $table_name . " WHERE post_title = '" . $col111 . "'";
                        //$resultss = $wpdb->get_var($sqls);
                        $resultss = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `" . $table_name . "` WHERE `post_title` = %s", $col111));

                        if ($resultss == 0)
                        {
                            $user_id = get_current_user_id();
                            $status = 1;

                            $sql1 = "INSERT INTO " . $table_name . " (`post_title`,`post_status`,`post_type`,`post_name`,`jr_state`,`jr_city`,`jr_address`,`jr_postalcode`,`jr_phonenumber`,`jr_latitude`,`jr_longitude`, `jr_license`, `term_name`, `new_rel_path`,`post_author`, `status`) values ('" . $col111 . "', 'publish', 'property', '" . $col111 . "', '" . $col8 . "', '" . $col7 . "', '" . $col6 . "', '" . $col9 . "', '" . $col5 . "', '" . $latitude . "', '" . $longitude . "', '" . $col3 . "', '" . $col10 . "', '" . $image_url . "', '" . $user_id . "', '" . $status . "')";
                            $wpdb->query($sql1);
                        }
                    }
                }
                fclose($handle);
                $args = ['page' => 'property-importer', ];
                $actionurl = add_query_arg($args, admin_url('admin.php'));
                wp_redirect($actionurl);
                die;
            }
        }
    }
    public function insert_cat_id($name = '', $parent = 0)
    {
        $cats = get_terms('category', ['hide_empty' => false, ]);

        $cat_id = 0;
        if (!empty($cats))
        {
            foreach ($cats as $cat)
            {
                if ($cat->name == $name && $cat->parent == $parent)
                {
                    $cat_id = $cat->term_id;
                }
            }
        }
        if ((int)$cat_id == 0)
        {
            $arg = ['parent' => $parent];

            $cat = wp_insert_term($name, 'category', $arg);
            //print_r($cat);
            if (!is_wp_error($cat))
            {
                $cat_id = $cat['term_id'];
            }
            elseif (isset($cat->error_data['term_exists']))
            {
                $cat_id = $cat->error_data['term_exists'];
            }
        }
        //echo $name . ' : ' . $cat_id . '<br/>';
        return $cat_id;
    }
    public function wp_feature_property_filter($query)
    {
        global $pagenow;
        $type = 'property';
        if (isset($_GET['post_type']))
        {
            $type = $_GET['post_type'];
        }
        if ('property' == $type && is_admin() && $pagenow == 'edit.php' && isset($_GET['post_status']) && $_GET['post_status'] == 'featured')
        {
            $query->query_vars['meta_key'] = '_is_featured';
            $query->query_vars['meta_value'] = 'yes';
        }
        return $query;
    }
    public function remove_admin_bar() {
        if (!current_user_can('administrator') && !is_admin()) {
            show_admin_bar(false);
        }
    }
}

