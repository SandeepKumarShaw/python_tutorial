<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin/partials
 */

class Carehomesdirect_Property_Admin_Page {
	private $stripepayments_settings_options;
		private $googlemap_capcha_api_settings_options;


	public function __construct(){
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'user/vendor/autoload.php';

	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    if(!empty($stripeOption)){
		    $livemode = $stripeOption['is_live_0'];
		    if(isset($livemode) && $livemode === 'is_live_0'){
		       $publishable_key = $stripeOption['api_publishable_key_1'];
		       $secret_key      = $stripeOption['api_secret_key_2'];
		    }else{
		       $publishable_key = $stripeOption['api_publishable_key_test_3'];
		       $secret_key      = $stripeOption['api_secret_key_test_4'];
		    }
		}else{
			$publishable_key = 'pk_test_YGkT6VfeY5cJY9Wl1fkxCu8I00LSiBOVdK';
		    $secret_key      = 'sk_test_EUvwlru7xzqamg9DLbqUTrSG00sRDiUPUL';
		}
	    $stripe = [
		    "secret_key"      => $secret_key,
		    "publishable_key" => $publishable_key,
		];

		\Stripe\Stripe::setApiKey($stripe['secret_key']);
	}
	public function property_importer_page() {

		add_menu_page('Property Settings', 'Property Settings', 'manage_options', 'property-importer', array(&$this, "property_importer_page_output") );
		add_submenu_page('property-importer', 'Property Importer', 'Property Importer', 'manage_options', 'property-importer', array(&$this, "property_importer_page_output") );
		add_submenu_page('property-importer', 'Payment Setting', 'Payment Setting', 'manage_options', 'payment-setting-stripe', array(&$this, "payment_setting_stripe_output") );
		add_submenu_page('property-importer', 'Claim Listings', 'Claim Listings', 'manage_options', 'cliam-listing-setting', array(&$this, "claim_listing_setting_output") );
		add_submenu_page('property-importer', 'Settings', 'Settings', 'manage_options', 'google-capcha-map-api-setting', array(&$this, "google_capcha_map_api_setting_output") );
	}
	public function payment_setting_stripe_output(){?>
		<div class="wrap">		 	
		<div class="payment-stripe-setting">
		<h1>Stripe Payment Setup</h1>
		<div class="container">
			<ul class="tabs">
				<li class="tab current" data-tab="tab-1">Payment</li>
				<li class="tab" data-tab="tab-2">Membership</li>
				<li class="tab" data-tab="tab-3">Credentials Settings</li>
			</ul>
			<div id="tab-1" class="tab-content current">
				<div class="container">
					<h2 align="center">All Payment</h2> 
					<?php
						//$Subscription = \Stripe\Subscription::all();
						$customers = \Stripe\Customer::all();
					?>

					<table class="cell-border" id="customers" class="cell-border" style="width:100%"> 
							        	<thead class="datatablebody">
				            <tr>
				            	<th class="datatablebody_th">Customer</th>
				                <th class="datatablebody_th">Plan Name</th>
				                <th class="datatablebody_th">Plan Interval</th>
				                <th class="datatablebody_th">Plan Price</th>
				            </tr>
				        </thead>
				        <tbody>
				        <?php 
				            foreach ($customers['data'] as $customer) {
		                      $email = $customer['email'];

		                        foreach ($customer['subscriptions']->data as $subscription) {
			                      	foreach ($subscription['items']->data as $plans) {
			                      		$amount = $plans->plan->amount;
			                      		$price =  $amount / 100;
			            ?>             	
				                        <tr>  
							            	<td><?php echo $email;?></td>
							            	<td><?php echo $plans->plan->nickname;?></td>
							            	<td><?php echo $plans->plan->interval;?></td>
							            	<td><?php echo '$' . number_format($price,2); ?></td>                
							            </tr>  
					    <?php 

					                }
		                        }
		                    } 
		                ?>
		            </tbody>
				        </table>			
				</div>
			</div>    
			<div id="tab-2" class="tab-content">
		    	<div class="container" id="addmoreplandiv">
		    		<div class="plan_success"></div>
				    <h2 align="center">Add New Plan</h2>		   
				    <form action="#" method="POST" class="addmore" id="addmoreplan">     
				        <table class="table table-bordered" id="dynamicTable" align="center" style="margin: 0px auto;"> 
				            <tr>
				            	<th></th>
				                <th>Plan Name</th>
				                <th>Plan Interval</th>
				                <th>Plan Price</th>
				                <th></th>
				            </tr>
				            <tr>  
				            	<td><input type="hidden" name="action" value="property_stripe_plan_add"></td>
				                <td><input type="text" name="addmorename" placeholder="Enter your Plan Name" class="form-control" required /></td>  
				                <td class="custom-select"> 
									  <select name="addmoreqty" class="form-control" required="required">
									    <option value="0">Select Plan Interval:</option>
									    <option value="month">Monthly</option>
									    <option value="year">Yearly</option>							    
									  </select>
				                </td>
				                <td><input type="text" name="addmoreprice" placeholder="Enter your Plan Price" class="form-control" required /></td>  
				                <td><button type="submit" class="btn button-primay add_plan">Save</button></td>
				            </tr>  
				        </table>    
				    </form>
				</div>   
				<div class="container">
					 <h2 align="center">All Plans</h2> 
					<?php
						$Plans = \Stripe\Plan::all();
					?>
					<table class="cell-border" id="customersPlan" class="cell-border" style="width:100%"> 
							        	<thead class="datatablebody">
				        

				            <tr>
				            	<th class="datatablebody_th">ID</th>
				                <th class="datatablebody_th">Plan Name</th>
				                <th class="datatablebody_th">Plan Interval</th>
				                <th class="datatablebody_th">Plan Price</th>
				                <th class="datatablebody_th">Action</th>
				            </tr>
				        </thead>
				        <tbody>
				            <?php foreach ($Plans['data'] as $plan) {
		                      $price = $plan['amount'] / 100;
				            	?>
					            <tr>  
					            	<td><?php echo $plan['id'];?></td>
					            	<td><?php echo $plan['nickname'];?></td>
					            	<td><?php echo $plan['interval'];?></td>
					            	<td><?php echo '$' . number_format($price,2); ?></td>		                
					                <td><button type="button" onclick="delPlan('<?php echo $plan['id'];?>','<?php echo $plan['product'];?>')" name="add" id="add" class="btn remove-tr">Delete</button></td>  
					            </tr>  
				            <?php } ?>
				            </tbody>
				        </table>			
				</div> 
			</div>    
			<div id="tab-3" class="tab-content">
			<?php $this->stripepayments_settings_options = get_option( 'stripepayments_settings_option_name' ); ?>

				<div class="wrap">
					<h2>StripePayments-settings</h2>
					<p></p>
					<?php settings_errors(); ?>

					<form method="post" action="options.php">
						<?php
							settings_fields( 'stripepayments_settings_option_group' );
							do_settings_sections( 'stripepayments-settings-admin' );
							submit_button();
						?>
					</form>
				</div>

			</div> 
		</div><!-- container -->
		</div>
		</div> 
    <?php
    }
    public function claim_listing_setting_output(){?>

    <div class="wrap">		 	
		<div class="payment-stripe-setting">
		<h1>Claim Listings</h1>
			<div class="container">		
		   
				<div id="tab-2" class="">
			 
					<div class="container">
						 <h2 align="center">All User Who Claim's Property</h2> 
						<?php
						global $wpdb; 
						$table_name = $wpdb->prefix . 'claim_details';

						$sql = "SELECT  * FROM " . $table_name . "";
						$results = $wpdb->get_results($sql);

					/*	echo '<pre>';
						  print_r($results);
						echo '</pre>';*/


						?>
					        <table class="cell-border" id="claim_listing_property" class="cell-border" style="width:100%">  
					        	<thead class="datatablebody">
					            <tr>
					            	<th class="datatablebody_th">Email</th>
					            	<th class="datatablebody_th">Name</th>
					                <th class="datatablebody_th">Property Name</th>
					                <th class="datatablebody_th">Action</th>
					            </tr>
					        </thead>
					        <tbody>
					            <?php foreach ($results as $result) {
			                       $user_id = $result->user_id;
			                      $post_id = $result->property_id;
			                      $status = $result->status;
			                      
					            	?>
						            <tr>  
						            	<td><?php echo $result->emailid;?></td>
						            	<td><?php echo $result->name;?></td>
						            	<td><?php echo get_the_title( $post_id ); ?></td>
						            	<?php if($status == '0'){?>
						                <td><button type="button" onclick="upClaimProperty('<?php echo $user_id; ?>','<?php echo $post_id; ?>')" name="claimProperty" id="claimProperty" class="btn remove-tr1" style="width: 150px;">Approved</button></td> 
						                <?php }else if($status == 1){?> 
						                <td><button type="button" onclick="downClaimProperty('<?php echo $user_id; ?>','<?php echo $post_id; ?>')" name="claimProperty" id="claimProperty" class="btn remove-tr">Unapproved</button></td> 	
						                <?php } ?>	
						            </tr>  
					            <?php } ?>
					        </tbody>
					        </table>			
					</div> 
				</div> 
			
			</div><!-- container -->
		</div>
	</div> 

    <?php }
    public function google_capcha_map_api_setting_output(){

    	$this->googlemap_capcha_api_settings_options = get_option( 'googlemap_capcha_api_settings_option_name' ); ?>

		<div class="wrap">
			<h2>GoogleMap & Capcha API Settings</h2>
			<p></p>
			<?php settings_errors(); ?>

			<form method="post" action="options.php">
				<?php
					settings_fields( 'googlemap_capcha_api_settings_option_group' );
					do_settings_sections( 'googlemap-capcha-api-settings-admin' );
					submit_button();
				?>
			</form>
		</div>

    <?php }
    	public function googlemap_capcha_api_settings_page_init() {
		register_setting(
			'googlemap_capcha_api_settings_option_group', // option_group
			'googlemap_capcha_api_settings_option_name', // option_name
			array( $this, 'googlemap_capcha_api_settings_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'googlemap_capcha_api_settings_setting_section', // id
			'Settings', // title
			array( $this, 'googlemap_capcha_api_settings_section_info' ), // callback
			'googlemap-capcha-api-settings-admin' // page
		);

		add_settings_field(
			'recaptcha_site_key_0', // id
			'reCAPTCHA Site Key', // title
			array( $this, 'recaptcha_site_key_0_callback' ), // callback
			'googlemap-capcha-api-settings-admin', // page
			'googlemap_capcha_api_settings_setting_section' // section
		);

		add_settings_field(
			'recaptcha_secret_key_1', // id
			'reCAPTCHA Secret Key', // title
			array( $this, 'recaptcha_secret_key_1_callback' ), // callback
			'googlemap-capcha-api-settings-admin', // page
			'googlemap_capcha_api_settings_setting_section' // section
		);

		add_settings_field(
			'google_maps_api_browser_key_2', // id
			'Google Maps API Browser Key', // title
			array( $this, 'google_maps_api_browser_key_2_callback' ), // callback
			'googlemap-capcha-api-settings-admin', // page
			'googlemap_capcha_api_settings_setting_section' // section
		);
	}

	public function googlemap_capcha_api_settings_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['recaptcha_site_key_0'] ) ) {
			$sanitary_values['recaptcha_site_key_0'] = sanitize_text_field( $input['recaptcha_site_key_0'] );
		}

		if ( isset( $input['recaptcha_secret_key_1'] ) ) {
			$sanitary_values['recaptcha_secret_key_1'] = sanitize_text_field( $input['recaptcha_secret_key_1'] );
		}

		if ( isset( $input['google_maps_api_browser_key_2'] ) ) {
			$sanitary_values['google_maps_api_browser_key_2'] = sanitize_text_field( $input['google_maps_api_browser_key_2'] );
		}

		return $sanitary_values;
	}

	public function googlemap_capcha_api_settings_section_info() {
		
	}

	public function recaptcha_site_key_0_callback() {
		printf(
			'<input class="regular-text" type="text" name="googlemap_capcha_api_settings_option_name[recaptcha_site_key_0]" id="recaptcha_site_key_0" value="%s">',
			isset( $this->googlemap_capcha_api_settings_options['recaptcha_site_key_0'] ) ? esc_attr( $this->googlemap_capcha_api_settings_options['recaptcha_site_key_0']) : ''
		);
	}

	public function recaptcha_secret_key_1_callback() {
		printf(
			'<input class="regular-text" type="text" name="googlemap_capcha_api_settings_option_name[recaptcha_secret_key_1]" id="recaptcha_secret_key_1" value="%s">',
			isset( $this->googlemap_capcha_api_settings_options['recaptcha_secret_key_1'] ) ? esc_attr( $this->googlemap_capcha_api_settings_options['recaptcha_secret_key_1']) : ''
		);
	}

	public function google_maps_api_browser_key_2_callback() {
		printf(
			'<input class="regular-text" type="text" name="googlemap_capcha_api_settings_option_name[google_maps_api_browser_key_2]" id="google_maps_api_browser_key_2" value="%s">',
			isset( $this->googlemap_capcha_api_settings_options['google_maps_api_browser_key_2'] ) ? esc_attr( $this->googlemap_capcha_api_settings_options['google_maps_api_browser_key_2']) : ''
		);
	}
	public function property_importer_page_output() {?>
		<div class="outer-scontainer-wrap">
			
		<h1>Property Importer</h1>    
    <div id="response" class="error"></div>
    <div id="response1" class="success"></div>
    <div class="outer-scontainer">
        <div class="row">

           <form class="form-horizontal" method="post" name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">Choose CSV
                        File</label> 
                        <input type="hidden" name="action" id="form_handler_action" value="property_form_handler">
                        <input type="file" name="form_handler_file"
                        id="form_handler_file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button>
                    <br />

                </div>

            </form>
          <div id="loader"></div>
        </div>
          
    </div>
    <div class="outer-scontainer">

    	<div class="input-row">
                    <span>Click on the Download CSV Button for Sample CSV File:

</span>
                        
                   
                        <a href="<?php echo plugins_url() . '/carehome-property/sample/sample.csv'; ?>" download>
  <img src="<?php echo plugins_url() . '/carehome-property/admin/images/csv.png'; ?>" alt="Download CSV" class="outer-scontainer-img">
</a>
                    <br />

                </div>
    	
    </div>
    		</div>


    <style type="text/css">
  #loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/admin/images/loadingGif.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }
</style>
	
	<?php		
	}
	public function property_form_handler() {

		//print_r($_FILES);

		if( $_FILES['form_handler_file']['name'] != "" ) {
			 $upload = wp_upload_dir();
			 $upload_dir = $upload['basedir'];
			 $upload_dir = $upload_dir . '/property';
			 if (! is_dir($upload_dir)) {
			    mkdir( $upload_dir, 0777 );
			 }
		     $filepath = ABSPATH . 'wp-content/uploads/property/';
		     $name = $_FILES['form_handler_file']['name'];
		     $fullsize_path = $filepath.$name;


	         move_uploaded_file( $_FILES['form_handler_file']['tmp_name'],$fullsize_path);		

			if(!empty($fullsize_path)) {
				$ext = pathinfo($fullsize_path, PATHINFO_EXTENSION);
				if($ext != 'csv') {
				'Not a .csv file.';
				return;
				}
				
				$row = 0;
				$headers = [];
				if (($handle = fopen($fullsize_path, "r")) !== FALSE) {
					while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
						if (++$row == 1) {
							$headers = array_flip($data); // Get the column names from the header.
							continue;
						} else {
							$col1 = $data[$headers['Facility Name']]; // Read row by the column name.
							$col2 = $data[$headers['Facility Name']];
							$col3 = $data[$headers['Licensee']];
							$col4 = $data[$headers['Licensee']];
							$col5 = $data[$headers['Facility Telephone Number']];
							$col6 = $data[$headers['Facility Address']];
							$col7 = $data[$headers['Facility City']];
							$col8 = $data[$headers['Facility State']];
							$col9 = $data[$headers['Facility Zip']];
							$col10 = $data[$headers['Facility Type']];
							$col11 = $data[$headers['Facility Gallery']];
							$wordpress_upload_dir = wp_upload_dir();
						
							if(isset($col11)){
								$allimages = explode("|",trim($col11));
								$attarray = array();
								foreach($allimages as $imgname) {
									array_push($attarray, $imgname);
								}	
								$image_url = Serialize($attarray);
								
							}

							$prepAddr = str_replace(' ','+',$col6);
							$geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&key=AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ');
							$output= json_decode($geocode);
							$latitude = $output->results[0]->geometry->location->lat;
							$longitude = $output->results[0]->geometry->location->lng;
							
	                        global $wpdb;
	                        $table_name = $wpdb->prefix . 'corn_property_mapping'; 
	                        $sqls = "SELECT  COUNT(*) FROM " . $table_name . " WHERE post_title = '" . $col1 . "'";
							$resultss = $wpdb->get_var($sqls);
							if($resultss == 0){

								 $user_id = get_current_user_id();
								 $status = 1;


							$sql1 = "INSERT INTO " . $table_name . " (`post_title`,`post_status`,`post_type`,`post_name`,`jr_state`,`jr_city`,`jr_address`,`jr_postalcode`,`jr_phonenumber`,`jr_latitude`,`jr_longitude`, `jr_license`, `term_name`, `new_rel_path`,`post_author`, `status`) values ('" . $col1 . "', 'publish', 'property', '" . $col2 . "', '" . $col8 . "', '" . $col7 . "', '" . $col6 . "', '" . $col9 . "', '" . $col5 . "', '" . $latitude . "', '" . $longitude . "', '" . $col3 . "', '" . $col10 . "', '" . $image_url . "', '" . $user_id . "', '" . $status . "')";
							    $wpdb->query($sql1);
							    //$wpdb->show_errors(); 
							 echo "Import completed!";    
							}
						}
					}
					
				}
			}
		}
		die();	
	}
	public function stripepayments_settings_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['is_live_0'] ) ) {
			$sanitary_values['is_live_0'] = $input['is_live_0'];
		}else{
			$sanitary_values['is_live_0'] = '';
		}

		if ( isset( $input['api_publishable_key_1'] ) ) {
			$sanitary_values['api_publishable_key_1'] = sanitize_text_field( $input['api_publishable_key_1'] );
		}

		if ( isset( $input['api_secret_key_2'] ) ) {
			$sanitary_values['api_secret_key_2'] = sanitize_text_field( $input['api_secret_key_2'] );
		}

		if ( isset( $input['api_publishable_key_test_3'] ) ) {
			$sanitary_values['api_publishable_key_test_3'] = sanitize_text_field( $input['api_publishable_key_test_3'] );
		}

		if ( isset( $input['api_secret_key_test_4'] ) ) {
			$sanitary_values['api_secret_key_test_4'] = sanitize_text_field( $input['api_secret_key_test_4'] );
		}

		return $sanitary_values;
	}
	public function stripepayments_settings_page_init() {
		register_setting(
			'stripepayments_settings_option_group', // option_group
			'stripepayments_settings_option_name', // option_name
			array( $this, 'stripepayments_settings_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'stripepayments_settings_setting_section', // id
			'Settings', // title
			array( $this, 'stripepayments_settings_section_info' ), // callback
			'stripepayments-settings-admin' // page
		);

		add_settings_field(
			'is_live_0', // id
			'Live Mode', // title
			array( $this, 'is_live_0_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_publishable_key_1', // id
			'Live Stripe Publishable Key', // title
			array( $this, 'api_publishable_key_1_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_secret_key_2', // id
			'Live Stripe Secret Key', // title
			array( $this, 'api_secret_key_2_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_publishable_key_test_3', // id
			'Test Stripe Publishable Key', // title
			array( $this, 'api_publishable_key_test_3_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_secret_key_test_4', // id
			'Test Stripe Secret Key', // title
			array( $this, 'api_secret_key_test_4_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);
	}
	public function stripepayments_settings_section_info() {
		
	}
	public function is_live_0_callback() {
		printf(
			'<input type="checkbox" name="stripepayments_settings_option_name[is_live_0]" id="is_live_0" value="is_live_0" %s> <label for="is_live_0">Check this to run the transaction in live mode. When unchecked it will run in test mode.',
			( isset( $this->stripepayments_settings_options['is_live_0'] ) && $this->stripepayments_settings_options['is_live_0'] === 'is_live_0' ) ? 'checked' : ''
		);
	}

	public function api_publishable_key_1_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_publishable_key_1]" id="api_publishable_key_1" value="%s">',
			isset( $this->stripepayments_settings_options['api_publishable_key_1'] ) ? esc_attr( $this->stripepayments_settings_options['api_publishable_key_1']) : ''
		);
	}

	public function api_secret_key_2_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_secret_key_2]" id="api_secret_key_2" value="%s">',
			isset( $this->stripepayments_settings_options['api_secret_key_2'] ) ? esc_attr( $this->stripepayments_settings_options['api_secret_key_2']) : ''
		);
	}

	public function api_publishable_key_test_3_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_publishable_key_test_3]" id="api_publishable_key_test_3" value="%s">',
			isset( $this->stripepayments_settings_options['api_publishable_key_test_3'] ) ? esc_attr( $this->stripepayments_settings_options['api_publishable_key_test_3']) : ''
		);
	}

	public function api_secret_key_test_4_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_secret_key_test_4]" id="api_secret_key_test_4" value="%s">',
			isset( $this->stripepayments_settings_options['api_secret_key_test_4'] ) ? esc_attr( $this->stripepayments_settings_options['api_secret_key_test_4']) : ''
		);
	}
	public function property_stripe_plan_add(){

	     $addmorename = $_POST['addmorename'];
	     $addmoreqty = $_POST['addmoreqty'];
	     $addmoreprice = $_POST['addmoreprice'];

     	   $plan = \Stripe\Plan::create(
		     	   	[
					  'amount' => $addmoreprice*100,
					  'currency' => 'usd',
					  'interval' => $addmoreqty,
					  'product' => ['name' => $addmorename],
					  'nickname' => $addmorename,

					]
			);
     	   if($plan){
             echo $addmorename . "Plan Created Successfully!";
     	   }else{
             echo "something went wrong";
     	   }
     	   die();
	}
	public function property_stripe_plan_del(){
		$id = $_POST['id'];
		$pid = $_POST['pid'];
		$plan = \Stripe\Plan::retrieve($id);
		$plan->delete();

		$product = \Stripe\Product::retrieve($pid);
		$product->delete();

		die();
	}
	public function property_claim_approved(){
		global $wpdb; 
		$response = array();
		$table_name = $wpdb->prefix . 'claim_details';


		$user_id = $_POST['id'];
		$post_id = $_POST['pid'];
		$prop_name = get_the_title( $post_id );


		$arg = array(
		    'ID' => $post_id,
		    'post_author' => $user_id,
		);
		wp_update_post( $arg );

		$sql = "UPDATE  " . $table_name . " SET `status` = 1 WHERE `user_id` = '" . $user_id . "' AND `property_id` = '" . $post_id . "'";
		$wpdb->query($sql);

        $sql1 = "SELECT `emailid`, `name` FROM " . $table_name . " WHERE `user_id` = '" . $user_id . "' AND `property_id` = '" . $post_id . "'";
		$results = $wpdb->get_row($sql1);

        $to = $results->emailid;
		$subject = "Claim Listing | Approved | Carehomes";
		$txt = "<strong>Name :</strong> $results->name <br><strong>Email :</strong> $to <br><strong>Message :</strong> This Property $prop_name is yours! ";
		$headers[] = "From: Info <info@carehomesdirect.com>";
		$headers[] = 'Content-Type: text/html; charset=UTF-8';

		wp_mail( $to, $subject, $txt, $headers );

		die();
	}
	public function property_claim_unapproved(){
		global $wpdb; 
		$response = array();
		$table_name = $wpdb->prefix . 'claim_details';


		 $user_id = $_POST['id'];
		 $post_id = $_POST['pid'];
		 $admin_id = get_current_user_id();
		 $prop_name = get_the_title( $post_id );

		$arg = array(
		    'ID' => $post_id,
		    'post_author' => $admin_id,
		);
		wp_update_post( $arg );

		$sql = "UPDATE  " . $table_name . " SET `status` = 0 WHERE `user_id` = '" . $user_id . "' AND `property_id` = '" . $post_id . "'";
		$wpdb->query($sql);

		$sql1 = "SELECT `emailid`, `name` FROM " . $table_name . " WHERE `user_id` = '" . $user_id . "' AND `property_id` = '" . $post_id . "'";
		$results = $wpdb->get_row($sql1);

        $to = $results->emailid;
		$subject = "Claim Listing | Decline | Carehomes";
		$txt = "<strong>Name :</strong> $results->name <br><strong>Email :</strong> $to <br><strong>Message :</strong> This Property $prop_name is not yours! ";
		$headers[] = "From: Info <info@carehomesdirect.com>";
		$headers[] = 'Content-Type: text/html; charset=UTF-8';

		wp_mail( $to, $subject, $txt, $headers );
		die();
	}
	public function filter_site_upload_size_limit( $size ) {   
        $size = 15 * 1024 * 1024;
        return $size;
    }
    public function add_extra_user_fields($user){
    	$user_id = $user->ID;   
	    $userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
	    $userPay = get_user_meta( $user_id, 'property_upgrade_membership_payment', true );
	    $userPayName = get_user_meta( $user_id, 'property_upgrade_membership_payment_plan', true );
	    $subscriber_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', true );
	    $plan_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', true );

	    $Plans = \Stripe\Plan::all();
	?>
	        <h3><?php _e("Update Membership", "carehome-property"); ?></h3>
	        <table class="form-table">
	            <tr class="user-job-title-wrap">
	                <th><label for="membership_update_title"><?php _e('Membership'); ?></label></th>
	                <td>
	                	<select name="update_membership_plan_name" id="update_membership_plan_name">
	                		<option value="0">Free Never expires</option>
                            <?php foreach ($Plans['data'] as $plan) {?>				            
							    <option <?php if($plan['nickname'] == $userPayName){ echo 'selected="selected"';}?> value="<?php echo $plan['nickname'];?>"><?php echo $plan['nickname'];?></option>
							<?php } ?>
						</select>
						<input type="hidden" name="property_upgrade_membership" value="100">

	                </td>
	                
	            </tr>
	            
	        </table>
	<?php
	}
	public function save_extra_user_fields($user_id){
		$pName = $_POST['update_membership_plan_name']; 
        if($pName === '0' || $pName === 0){
        	update_user_meta( $user_id, 'property_upgrade_membership', 0 );
        	update_user_meta( $user_id, 'property_upgrade_membership_payment', 0 );
        	update_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', 0 );
        	update_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', 0 );
        	update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', sanitize_text_field( $pName ) );

        }
        elseif(($pName != '0' || $pName != 0) && $pName === 'Assisted Living Premium Annual' ){
        	update_user_meta( $user_id, 'property_upgrade_membership', sanitize_text_field( $_POST['property_upgrade_membership'] ));
        	update_user_meta( $user_id, 'property_upgrade_membership_payment', 1499 );


        	update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', sanitize_text_field( $pName ) );

        }
        elseif(($pName != '0' || $pName != 0) && $pName === 'Assisted Living Premium Monthly' ){
        	update_user_meta( $user_id, 'property_upgrade_membership', sanitize_text_field( $_POST['property_upgrade_membership'] ));
        	update_user_meta( $user_id, 'property_upgrade_membership_payment', 149 );


        	update_user_meta( $user_id, 'property_upgrade_membership_payment_plan', sanitize_text_field( $pName ) );

        }
		


	}
}