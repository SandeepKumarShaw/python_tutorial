<?php
/**
 * Plugin Name:       WP Front-end register
 * Plugin URI:        http://example.com/
 * Description:       This plugin will help you to add ajax enabled custom register form on your website in just few minutes.
 * Version:           2.1.0
 * Author:            Wp Team
 * Author URI:        http://example.com/
 * License:           GPL-2.0+
 * License URI:       http://example.com/
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


require plugin_dir_path( __FILE__ ) . 'includes/class-wp-mp-register-login.php';

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_wp_mp_register_login() {

	 new Wp_Mp_Register_Login();
	

}
run_wp_mp_register_login();
