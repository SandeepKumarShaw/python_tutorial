(function($) {
    'use strict';

    $(document).ready(initScript);







    function initScript() {
        redirecturls();
        //defing global ajax post url
        window.ajaxPostUrl = ajax_object.ajax_url;
        // validating registration form request
        wpmpValidateAndProcessRegisterForm();
       
    }

    function redirecturls(){
        var redirectUrl = "<?php echo site_url().'/welcome-dashboard-user/'; ?>";

    }


    // Validate registration form
    function wpmpValidateAndProcessRegisterForm() {
        $('#wpmpRegisterForm').formValidation({
            message: 'This value is not valid',
            icon: {
                required: 'glyphicon glyphicon-asterisk',
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                wpmp_fname: {
                    validators: {
                        notEmpty: {
                            message: 'The Name is required'
                        }
                    }
                },                
                wpmp_email: {
                    validators: {
                        notEmpty: {
                            message: 'The email is required'
                        },
                        regexp: {
                            regexp: '^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$',
                            message: 'E-mail is invalid'
                        }
                    }
                },
                wpmp_password: {
                    validators: {
                        notEmpty: {
                            message: 'The password is required'
                        },
                        stringLength: {
                            min: 6,
                            message: 'The password must be more than 6 characters long'
                        }
                    }
                },
                wpmp_password2: {
                    validators: {
                        notEmpty: {
                            message: 'The password is required'
                        },
                        identical: {
                            field: 'wpmp_password',
                            message: 'The password and its confirm are not the same'
                        },
                        stringLength: {
                            min: 6,
                            message: 'The password must be more than 6 characters long'
                        }
                    }
                },
                wpmp_checkbox: {
                    validators: {
                        notEmpty: {
                            message: 'Please accept the Terms of Service to register on the site.'
                        }
                    }
                },  
                  
            
            }
        }).on('success.form.fv', function(e) {
            $('#wpmp-register-alert').hide();
            $('#wpmp-mail-alert').hide();
            $('body, html').animate({
                scrollTop: 0
            }, 'slow');
            // You can get the form instance
            var $registerForm = $(e.target);
            // and the FormValidation instance
            var fv = $registerForm.data('formValidation');
            var content = $registerForm.serialize();

            var redirectUrl = $('#redirection_url').val();

            // start processing
            $('#wpmp-reg-loader-info').show();
            //window.location.href = "/welcome-dashboard/";

            wpmpStartRegistrationProcess(content, redirectUrl);
            // Prevent form submission
            e.preventDefault();
        }).on('err.form.fv', function(e) {
            // Regenerate the captcha
            //generateCaptcha();
        });
    }


    // Make ajax request with user credentials
    function wpmpStartRegistrationProcess(content, redirectUrl) {
        
        var registerRequest = $.ajax({
            type: 'POST',
            url: ajaxPostUrl,
            data: content + '&action=wpmp_user_registration',
            dataType: 'json',
            success: function(data) {

                $('#wpmp-reg-loader-info').hide();
                //check mail sent status
                if (data.mail_status == false) {

                    $('#wpmp-mail-alert').show();
                    $('#wpmp-mail-alert').html('Could not able to send the email notification.');
                }
                // check login status
                if (true == data.reg_status) {
                    $('#wpmp-register-alert').removeClass('alert-danger');
                    $('#wpmp-register-alert').addClass('alert-success');
                    $('#wpmp-register-alert').show();
                    $('#wpmp-register-alert').html(data.success);


                   // var delay = 2000; 
                   // setTimeout(function(){ window.location = URL; }, delay);
                     window.setTimeout(function(){

                        // Move to a new location or you can do something else
                        window.location.href = redirectUrl;

                    }, 5000);

                } else {
                    $('#wpmp-register-alert').addClass('alert-danger');
                    $('#wpmp-register-alert').show();
                    $('#wpmp-register-alert').html(data.error);

                }
            },
            error: function(data) {
                console.log(data);
            }
        });



    }

 



})(jQuery);
