<?php
global $wpdb; 
$hmohub_plan = $wpdb->prefix . 'hmohub_plan';  // table name
$charset_collate = $wpdb->get_charset_collate();

if($wpdb->get_var("SHOW TABLES LIKE '$hmohub_plan'") != $hmohub_plan) {
       $sql = "CREATE TABLE $hmohub_plan (
                id bigint(20) NOT NULL auto_increment,
                plan_id varchar(200) NOT NULL,
                Prod_id varchar(200) NOT NULL,
                PlanName varchar(200) NOT NULL,
                PlanAmmount varchar(60) NOT NULL,
                member_level_id bigint(20) NOT NULL,
                PlanInterval varchar(60) NOT NULL,
                plan_content  longtext NOT NULL,
                UNIQUE KEY id (id)
        ) $charset_collate;";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql );
}

$hmohub_customer = $wpdb->prefix . 'hmohub_customer';  // table name
$hmohub_customer_charset = $wpdb->get_charset_collate();

if($wpdb->get_var("SHOW TABLES LIKE '$hmohub_customer'") != $hmohub_customer) {
       $sql = "CREATE TABLE $hmohub_customer (
                id bigint(20) NOT NULL auto_increment,
                plan_id varchar(200) NOT NULL,
                sub_id varchar(200) NOT NULL,
                member_level_id bigint(20) NOT NULL,
                user_id bigint(20) NOT NULL,
                Email varchar(200) NOT NULL,
                UserName varchar(200) NOT NULL,
                sub_id varchar(200) NOT NULL,
                custId varchar(200) NOT NULL,
                UNIQUE KEY id (id)
        ) $hmohub_customer_charset;";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql );
}
?>