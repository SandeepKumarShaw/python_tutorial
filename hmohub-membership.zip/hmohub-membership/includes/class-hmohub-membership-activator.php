<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/includes
 * @author     Your Name <email@example.com>
 */
class Hmohub_Membership_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		require_once plugin_dir_path( __FILE__ ) . 'inc/Table_creation.php';

	}

}
