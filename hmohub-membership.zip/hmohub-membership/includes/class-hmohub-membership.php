<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/includes
 * @author     Your Name <email@example.com>
 */
class Hmohub_Membership {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Hmohub_Membership_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $hmohub_membership    The string used to uniquely identify this plugin.
	 */
	protected $hmohub_membership;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'HMOHUB_MEMBERSHIP_VERSION' ) ) {
			$this->version = HMOHUB_MEMBERSHIP_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->hmohub_membership = 'hmohub-membership';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_admin_hooks_page();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Hmohub_Membership_Loader. Orchestrates the hooks of the plugin.
	 * - Hmohub_Membership_i18n. Defines internationalization functionality.
	 * - Hmohub_Membership_Admin. Defines all hooks for the admin area.
	 * - Hmohub_Membership_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-hmohub-membership-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-hmohub-membership-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-hmohub-membership-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-hmohub-membership-admin-page.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-hmohub-membership-public.php';


		$this->loader = new Hmohub_Membership_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Hmohub_Membership_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Hmohub_Membership_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Hmohub_Membership_Admin( $this->get_hmohub_membership(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

	
	}
	private function define_admin_hooks_page() {

		$plugin_admin_page = new Hmohub_Membership_Admin_Page();

		$this->loader->add_action( 'admin_menu', $plugin_admin_page, 'hmohub_membership_page' );
		$this->loader->add_action( 'admin_init', $plugin_admin_page, 'stripepayments_settings_page_init' );

		$this->loader->add_action( 'wp_ajax_nopriv_property_stripe_plan_add', $plugin_admin_page, 'property_stripe_plan_add' );
		$this->loader->add_action( 'wp_ajax_property_stripe_plan_add', $plugin_admin_page, 'property_stripe_plan_add' );

		$this->loader->add_action( 'wp_ajax_nopriv_property_stripe_plan_del', $plugin_admin_page, 'property_stripe_plan_del' );
		$this->loader->add_action( 'wp_ajax_property_stripe_plan_del', $plugin_admin_page, 'property_stripe_plan_del' );

		$this->loader->add_action( 'admin_init', $plugin_admin_page, 'hmohub_pop_up_message_settings_page_init' );

		$this->loader->add_action( 'restrict_page_settings_tab', $plugin_admin_page, 'restrict_page_hmohubcat_tab',1 );
		$this->loader->add_action( 'restrict_page_settings_tab', $plugin_admin_page, 'restrict_page_hmohubposttype_tab' );

		$this->loader->add_action( 'restrict_page_settings_content', $plugin_admin_page, 'restrict_page_hmohubcat_render_options_page' );
		$this->loader->add_action( 'restrict_page_settings_content', $plugin_admin_page, 'restrict_page_hmohubposttype_render_options_page' );

		$this->loader->add_action( 'wp_ajax_nopriv_hmohubcat_restriction_plan_update', $plugin_admin_page, 'hmohubcat_restriction_plan_update' );
		$this->loader->add_action( 'wp_ajax_hmohubcat_restriction_plan_update', $plugin_admin_page, 'hmohubcat_restriction_plan_update' );




		
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Hmohub_Membership_Public( $this->get_hmohub_membership(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );


		$this->loader->add_action( 'wp_footer', $plugin_public, 'load_style_in_footer' );
		$this->loader->add_shortcode( 'wp_upgrade_membership_shortcode', $plugin_public, 'upgrade_membership_shortcode' );
		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment', $plugin_public, 'stripe_membership_payment' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment', $plugin_public, 'stripe_membership_payment' );

		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment_upgrade', $plugin_public, 'stripe_membership_payment_upgrade' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment_upgrade', $plugin_public, 'stripe_membership_payment_upgrade' );

		$this->loader->add_action( 'wp_ajax_nopriv_stripe_membership_payment_cancel', $plugin_public, 'stripe_membership_payment_cancel' );
		$this->loader->add_action( 'wp_ajax_stripe_membership_payment_cancel', $plugin_public, 'stripe_membership_payment_cancel' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_hmohub_membership() {
		return $this->hmohub_membership;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Hmohub_Membership_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
