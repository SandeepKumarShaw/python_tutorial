<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/public
 * @author     Your Name <email@example.com>
 */
class Hmohub_Membership_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $hmohub_membership    The ID of this plugin.
	 */
	private $hmohub_membership;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $hmohub_membership       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $hmohub_membership, $version ) {

		$this->hmohub_membership = $hmohub_membership;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hmohub_Membership_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hmohub_Membership_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->hmohub_membership, plugin_dir_url( __FILE__ ) . 'css/hmohub-membership-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hmohub_Membership_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hmohub_Membership_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */   


	    wp_enqueue_script($this->hmohub_membership . 'stripe-validation-js', 'https://js.stripe.com/v2/', '', $this->version, false );

	    wp_enqueue_script($this->hmohub_membership . '-jquery-validate-user', plugin_dir_url(__FILE__) . 'js/jquery.validate.min.js', array('jquery'), $this->version, false);

	   	//wp_enqueue_script($this->hmohub_membership . '-sweetalert-js-front', plugin_dir_url( __FILE__ ) . 'js/sweetalert.js', array('jquery'), $this->version, false);

	   	wp_enqueue_script($this->hmohub_membership . '-sweetalert-js-front', 'https://cdn.jsdelivr.net/npm/sweetalert2@9', array('jquery'), $this->version, false);



	   	wp_enqueue_script($this->hmohub_membership . 'ajax-js', plugin_dir_url(__FILE__) . 'js/public_ajax.js', array(
            'jquery'
        ) , $this->version, false);
        wp_localize_script($this->hmohub_membership . 'ajax-js', 'ajax_public_params', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
		wp_enqueue_script( $this->hmohub_membership, plugin_dir_url( __FILE__ ) . 'js/hmohub-membership-public.js', array( 'jquery' ), $this->version, false );

	}
	public function load_style_in_footer(){
		echo "<style type='text/css'>";
		echo "#loader {display: none;position: fixed;top: 0;left: 0;right: 0;bottom: 0;
      width: 100%;background: rgba(0,0,0,0.75) url('" . plugins_url() . "'/hmohub-membership/public/images/loader1.gif') no-repeat center center;z-index: 10000;}";
		echo "</style>";
	}
	public function upgrade_membership_shortcode(){
		if( is_user_logged_in() ) {		
			$user_details = new WP_User(get_current_user_id());
			$user_id = $user_details->ID;	
			require_once plugin_dir_path( __FILE__ ) . 'partials/hmohub-membership-public-display.php';
		}
		
	}
	public function stripe_membership_payment(){
		global $wpdb;
		$table_name = $wpdb->prefix . 'hmohub_plan';
	    $table_hmohub_customer = $wpdb->prefix . 'hmohub_customer';
	    $table_swpm_members_tbl = $wpdb->prefix . 'swpm_members_tbl';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/vendor/autoload.php';



	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    $livemode = $stripeOption['is_live_0'];
	    if(isset($livemode) && $livemode === 'is_live_0'){
	       $publishable_key = $stripeOption['api_publishable_key_1'];
	       $secret_key      = $stripeOption['api_secret_key_2'];
	    }else{
	       $publishable_key = $stripeOption['api_publishable_key_test_3'];
	       $secret_key      = $stripeOption['api_secret_key_test_4'];
	    }

		$cardNumber = $_REQUEST['cardNumber'];
		$cardCVC = $_REQUEST['cardCVC'];
		$cardHolder = $_REQUEST['cardHolder'];
		$expMonth = $_REQUEST['expMonth'];
		$expYear = $_REQUEST['expYear'];
		$planid = $_REQUEST['plan'];
		$price = $_REQUEST['price'];
		$interval = $_REQUEST['interval'];
		$nickname = $_REQUEST['nickname'];

		$user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;
		$email  = $user_details->user_email;


		$stripe = [
		    "secret_key"      => $secret_key,
		    "publishable_key" => $publishable_key,
		];

		  \Stripe\Stripe::setApiKey($stripe['secret_key']);

		   $token = \Stripe\Token::create(array(
			  "card" => array(
			    "number" => $cardNumber,
			    "exp_month" => $expMonth,
			    "exp_year" => $expYear,
			    "cvc" => $cardCVC
			  )
			));	

		  $customer = \Stripe\Customer::create([
		      'email' => $email,
		      'source'  => $token,
		  ]);

		  $custId = $customer->id;

		   $subscription = \Stripe\Subscription::create(array(
		      "customer" => $customer->id,
		      "items" => array(
		          array(
		              "plan" => $planid,
		          ),
		      ),
		  ));

			$subsId = $subscription->id;

			$sql = "SELECT * FROM " . $table_name . " WHERE `plan_id` = '" . $planid . "'";
			$results = $wpdb->get_row($sql);
			$mem_id = $results->member_level_id;



			$sql1 = "UPDATE  " . $table_hmohub_customer . " SET `plan_id` = '" . $planid . "',`member_level_id` = '" . $mem_id . "',`sub_id` = '" . $subsId . "',`custId` = '" . $custId . "' WHERE `user_id` = '" . $user_id . "'";
			$wpdb->query($sql1);

			$sql2 = "UPDATE  " . $table_swpm_members_tbl . " SET `membership_level` = '" . $mem_id . "' WHERE `email` = '" . $email . "'";
			$wpdb->query($sql2);

		    

		echo '<h1>Successfully charged $'.$price.'!</h1>';

		die();	    
	}
	public function stripe_membership_payment_upgrade(){

	}
	public function stripe_membership_payment_cancel(){

		global $wpdb;
		$table_name = $wpdb->prefix . 'hmohub_plan';
	    $table_hmohub_customer = $wpdb->prefix . 'hmohub_customer';
	    $table_swpm_members_tbl = $wpdb->prefix . 'swpm_members_tbl';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/vendor/autoload.php';

	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    $livemode = $stripeOption['is_live_0'];
	    if(isset($livemode) && $livemode === 'is_live_0'){
	       $publishable_key = $stripeOption['api_publishable_key_1'];
	       $secret_key      = $stripeOption['api_secret_key_2'];
	    }else{
	       $publishable_key = $stripeOption['api_publishable_key_test_3'];
	       $secret_key      = $stripeOption['api_secret_key_test_4'];
	    }
	    $user_details = new WP_User(get_current_user_id());
		$user_id = $user_details->ID;
		$email  = $user_details->user_email;

		$plan_id = $_REQUEST['plan_id'];
		$sub_id = $_REQUEST['sub_id'];


        $cusql = "SELECT * FROM " . $table_hmohub_customer . " WHERE `user_id` = '" . $user_id . "'";
		$cusresults = $wpdb->get_row($cusql);
		$cust_Id = $cusresults->custId;


		if(isset($sub_id) && ($sub_id !=0 || $sub_id !='0')){
			$stripe =   [
							"secret_key"      => $secret_key,
							"publishable_key" => $publishable_key,
						];
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			$subscription = \Stripe\Subscription::retrieve($sub_id);
			$cancel = $subscription->delete();


			$customer = \Stripe\Customer::retrieve($cust_Id);
			$customer->delete();





			$price = '0';
			$subsId = '0';
			$custId = '0';
		    $sql = "SELECT * FROM " . $table_name . " WHERE `PlanAmmount` = '" . $price . "'";
		    $results = $wpdb->get_row($sql);
		    $planid = $results->plan_id;
		    $mem_id = $results->member_level_id;

		    $sql1 = "UPDATE  " . $table_hmohub_customer . " SET `plan_id` = '" . $planid . "',`member_level_id` = '" . $mem_id . "',`sub_id` = '" . $subsId . "',`custId` = '" . $custId . "' WHERE `user_id` = '" . $user_id . "'";
			$wpdb->query($sql1);

			$sql2 = "UPDATE  " . $table_swpm_members_tbl . " SET `membership_level` = '" . $mem_id . "' WHERE `email` = '" . $email . "'";
			$wpdb->query($sql2);
		}
		echo '<h1>Successfully Updated the Plan</h1>';
		die();

	}
}
