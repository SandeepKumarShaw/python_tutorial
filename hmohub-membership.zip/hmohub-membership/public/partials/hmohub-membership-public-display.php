<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Hmohub_Membership
 * @subpackage Hmohub_Membership/public/partials
 */
require_once(ABSPATH . "wp-content" . '/plugins/hmohub-membership/admin/vendor/autoload.php');

    global $wpdb;
    $table_name = $wpdb->prefix . 'hmohub_plan';
    $table_hmohub_customer = $wpdb->prefix . 'hmohub_customer';
    $table_swpm_members_tbl = $wpdb->prefix . 'swpm_members_tbl';


	if( is_user_logged_in() ) {
	  
	  	$user_details = new WP_User(get_current_user_id());
	  	$user_id = $user_details->ID;   

	    $sql = "SELECT * FROM " . $table_hmohub_customer . " WHERE `user_id` = '" . $user_id . "'";
	    $results = $wpdb->get_row($sql);
		    $planid = $results->plan_id;
		    $mem_id = $results->member_level_id;
		    $sub_id = $results->sub_id;

	    $sql1 = "SELECT * FROM " . $table_name . " WHERE `plan_id` = '" . $planid . "' AND `member_level_id` = '" . $mem_id . "'";
	    $results1 = $wpdb->get_row($sql1);
		    $userPayName = $results1->PlanName;
		    $userPay = $results1->PlanAmmount;
	}  
       $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
       if(!empty($stripeOption)){
          $livemode = $stripeOption['is_live_0'];
          if(isset($livemode) && $livemode === 'is_live_0'){
             $publishable_key = $stripeOption['api_publishable_key_1'];
             $secret_key      = $stripeOption['api_secret_key_2'];
          }else{
             $publishable_key = $stripeOption['api_publishable_key_test_3'];
             $secret_key      = $stripeOption['api_secret_key_test_4'];
          }
      }else{
         $publishable_key = 'pk_test_YGkT6VfeY5cJY9Wl1fkxCu8I00LSiBOVdK';
          $secret_key      = 'sk_test_EUvwlru7xzqamg9DLbqUTrSG00sRDiUPUL';
      }
       $stripe = [
          "secret_key"      => $secret_key,
          "publishable_key" => $publishable_key,
      ];

?>



<section id="primary">
   <div id="content" role="main">
      <div class="jr-page jr-form-listing-outer jrPage jrListingCreate">
         <form id="jr-form-listing" method="post" action="javascript:void(0);" data-listing-id="" data-cat-id="17">
            <div class="jr-form-listing-fields jrForm jrFormContainer jrHidden" style="display: block;">
               <fieldset>
                  <div class="row">
                     <h2>Active Subscription Plan</h2>
                     <?php
                        if($userPay == '0'){
                         
                         ?> 
                     <div class="col-md-12">
                        <p> You have free plan Activated. Please subscribe from below plans...</p>
                     </div>
                     <?php }else{?> 
                     <div class="col-md-12">
                        <div id="update-success" class="hidden">
                           <i class="fa fa-check"></i>
                           <p>Upgrade Subscription Successfully!</p>
                        </div>
                        <div class="jrDataList">
                           <div class="row jr-paid-plan-row jrGrid">
                              <div class="col-md-3">
                                 <span class="jrPlanName"><strong><?php echo $userPayName;?></strong></span>            
                              </div>
                              <div class="col-md-2">
                                 <div class="jrLeft">
                                    <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo number_format($userPay,2); ?></span>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <?php

                                    if($userPay != '0'){

                                    \Stripe\Stripe::setApiKey($stripe['secret_key']);


                                    $subscriptions = \Stripe\Subscription::retrieve($sub_id);


                                    $current_period_end = date("F j, Y",$subscriptions['current_period_end']);
                                    $current_period_start = date("F j, Y",$subscriptions['current_period_start']);
                                    echo "<span class='jrPlanName'><strong>Subscription Start :</strong></span> " . $current_period_start;
                                    echo "<br>";
                                    echo "<span class='jrPlanName'><strong>Next Billing Date  :</strong></span> " . $current_period_end;
                                    }
                                 ?>                                                                 
                              </div>
                              <div class="col-md-3">
                                 <?php if($userPay != '0' || $userPay != 0){?>
                                 <button class="btn btn-danger jr-paid-buy jrButton jrSmall jr-paid-buy-sub" data-sub-id="<?php echo $sub_id; ?>" value="<?php echo $planid; ?>" onclick="cancelSubPlan('<?php echo $planid; ?>','<?php echo $sub_id; ?>')">
                                 <i class="fa fa-close"></i> Cancel Membership
                                 </button>
                                
                                 <?php } ?>
                              </div>
                           </div>
                           <br>
                        </div>
                     </div>
                     <?php } ?>
                  </div>
               </fieldset>
               <fieldset id="jr-paid-plan-list">
                  <div class="row">
                     <h2>Available plans For Subscription:</h2>
                     <?php
                        $sqlPlan = "SELECT * FROM " . $table_name;
                        $Planresults = $wpdb->get_results($sqlPlan);
                        if(!empty($Planresults)){
                        	foreach ($Planresults as $result) {
                               	if($result->PlanAmmount == '0'){
                        	?>
                     <div class="col-md-12">
                        <div class="jrDataList">
                           <div class="jrGrid jrDataListHeader">Free &amp; Trial Plans</div>
                           <div class="row jr-paid-plan-row-free jrGrid">
                              <div class="col-md-1">
                                 <input name="jr_paid_plan1" type="radio" value="1" data-free="1" disabled="">
                              </div>
                              <div class="col-md-3">
                                 <span class="jrPlanName"><strong><?php echo $result->PlanName; ?></strong></span>
                                 <span class="jrPlanDuration">
                                 Never expires
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <?php echo $result->plan_content; ?>
                              </div>
                              <div class="col-md-2">
                                 <div class="jrRight">
                                    <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo $result->PlanAmmount; ?></span>
                                 </div>
                              </div>
                           </div>
                           <br>
                        </div>
                     </div>
                     <?php 
                        }else{?>
                     <div class="col-md-12">
                        <div class="jrDataList">
                           <div class="jrGrid jrDataListHeader">Subscription Plans</div>
                           <div class="row <?php if($userPay != '0'){?>jr-paid-plan-row-paid-plan<?php }else{?>jr-paid-plan-row-paid<?php } ?> jrGrid">
                              <div class="col-md-1">
                                 <input class="jr_paid_plan" name="jr_paid_plan" type="radio" value="<?php echo $result->plan_id; ?>" data-amtprice="<?php echo $result->PlanAmmount; ?>" data-interval="<?php echo $result->PlanInterval; ?>" data-nickname="<?php echo $result->PlanName; ?>" <?php if($userPay != '0'){?>disabled=""<?php } ?>>
                              </div>
                              <div class="col-md-3">
                                 <span class="jrPlanName"><strong><?php echo $result->PlanName; ?></strong></span>
                                 <span class="jrPlanDuration">
                                 <?php 
                                    if($result->PlanInterval == 'year'){
                                         echo "12 Month(s)";
                                       }else{
                                         echo "1 Month";
                                       }
                                      ?>    
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <?php echo $result->plan_content; ?>
                              </div>
                              <div class="col-md-2">
                                 <div class="jrRight">
                                    <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo $result->PlanAmmount; ?></span>
                                 </div>
                              </div>
                           </div>
                           <br>
                        </div>
                     </div>
                     <?php
                        }
                        }	
                        }
                        ?>
                  </div>
               </fieldset>
               <fieldset>
                  <div id="form-container-payment" style="display: none;">
                     <div id="card-success" class="hidden">
                        <i class="fa fa-check"></i>
                        <p>Payment Successful!</p>
                     </div>
                     <div id="form-errors" class="hidden">
                        <p id="card-error">Card error</p>
                     </div>
                     <div id="form-container">
                        <div id="card-front">
                           <label for="card-number">
                           Card Number
                           </label>
                           <input type="text" id="card-number" placeholder="1234 5678 9101 1112" maxlength="16">
                           <div id="cardholder-container">
                              <label for="card-holder">Card Holder
                              </label>
                              <input type="text" id="card-holder" placeholder="e.g. John Doe" />
                           </div>
                           <!-- end card holder container -->
                           <div id="exp-container">
                              <label for="card-exp">Expiration</label><br>
                              <input id="card-month" type="text" placeholder="MM" maxlength="2">
                              <input id="card-year" type="text" placeholder="YY" maxlength="2">
                           </div>
                           <div id="cvc-container">
                              <label for="card-cvc"> CVC/CVV</label><br>
                              <input id="card-cvc" placeholder="XXX-X" type="text" maxlength="4">
                              <p>Last 3 or 4 digits</p>
                           </div>
                        </div>
                        <!-- end card back -->
                        <input type="text" id="card-token" />
                        <button type="button" id="card-btn">Pay Now</button>
                     </div>
                  </div>
                  <!-- end form container -->
                  <div id="loader"></div>
               </fieldset>
            </div>
         </form>
      </div>
   </div>
</section>
<?php
  echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
          </script>';
  
?>