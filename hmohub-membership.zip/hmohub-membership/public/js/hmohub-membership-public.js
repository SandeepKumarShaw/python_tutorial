  jQuery(document).ready(function($){

    
    var spinner = $('#loader');
/*+++++++++++++++++++++++++++ Stripe Card Form Display ++++++++++++++++++++++++++++++*/

    $('input[name=jr_paid_plan]').click(function () {
    	//alert('hi');
      $("#form-container-payment").show();
    }); 
/*+++++++++++++++++++++++++++ Stripe Card Checking +++++++++++++++++++++++++++++++++*/

    Stripe.setPublishableKey('pk_test_YGkT6VfeY5cJY9Wl1fkxCu8I00LSiBOVdK');
    var cardNumber, cardMonth, cardYear, cardCVC, cardHolder;
    // check for any empty inputs
    function findEmpty() {
        var emptyText = $('#form-container input').filter(function () {
            return $(this).val == null;
        });
        // add invalid class to empty inputs
        console.log(emptyText.prevObject);
        emptyText.prevObject.addClass('invalid');
    } 

    // check card type on card number input blur 
    $('#card-number').blur(function (event) {
        event.preventDefault();
       // checkCardType();
    });

/*+++++++++++++++++++++++++++ Stripe Subscription +++++++++++++++++++++++++++++++++*/
    $('#card-btn').click(function (event) {

        var plan = $("input[name='jr_paid_plan']:checked").val();
        var price = $('input[name="jr_paid_plan"]:checked').attr("data-AmtPrice");
        var interval = $('input[name="jr_paid_plan"]:checked').attr("data-interval");
        var nickname = $('input[name="jr_paid_plan"]:checked').attr("data-nickname");
        // get each input value and use Stripe to determine whether they are valid
        var cardNumber = $('#card-number').val();
        var isValidNo = Stripe.card.validateCardNumber(cardNumber);
        var expMonth = $('#card-month').val();
        var expYear = $('#card-year').val();
        var isValidExpiry = Stripe.card.validateExpiry(expMonth, expYear);

        var cardCVC = $('#card-cvc').val();
        var isValidCVC = Stripe.card.validateCVC(cardCVC);
        var cardHolder = $('#card-holder').val();
        event.preventDefault();

        //alert(plan + '' + price + '' + interval + '' + nickname)

        // alert the user if any fields are missing
        if (!cardNumber || !cardCVC || !cardHolder || !expMonth || !expYear) {
            console.log(cardNumber + cardCVC + cardHolder + expMonth + expYear);
            $('#form-errors').addClass('hidden');
            $('#card-success').addClass('hidden');
            $('#form-errors').removeClass('hidden');
            $('#card-error').text('Please complete all fields.');
            findEmpty();
        } else {
            // alert the user if any fields are invalid
            if (!isValidNo || !isValidExpiry || !isValidCVC) {
                $('#form-errors').css('display', 'block');
                if (!isValidNo) {
                    $('#card-error').text('Invalid credit card number.');
                } else if (!isValidExpiry) {
                    $('#card-error').text('Invalid expiration date.')
                } else if (!isValidCVC) {
                    $('#card-error').text('Invalid CVC code.')
                }

            } else {
                $('#form-errors').addClass('hidden');
                spinner.show();
                jQuery.ajax({
                  url: ajaxurl, // or example_ajax_obj.ajaxurl if using on frontend
                  type: 'post',
                  data: {
                      'action': 'stripe_membership_payment',
                      'cardNumber' : cardNumber,
                      'cardCVC' : cardCVC,
                      'cardHolder' : cardHolder,
                      'expMonth' : expMonth,
                      'expYear' : expYear,
                      'plan' : plan,
                      'price' : price,
                      'interval':interval,
                      'nickname':nickname
                  },
                  success:function(data) {
                    //console.log(data);
                    spinner.hide();
                    $('#card-success').removeClass('hidden');
                    setTimeout(function(){// wait for 5 secs(2)
                         location.reload(); // then reload the page.(3)
                    }, 3000); 
                  },
                  error: function(errorThrown){
                      console.log(errorThrown);
                  }
              });
            }
        }
    });
 });

/*+++++++++++++++++++++++++++ Stripe Cancel Subscription +++++++++++++++++++++++++++++++++*/

  function cancelSubPlan(plan_id, sub_id){


Swal.fire({
  title: 'Are you sure?',
  text: "You Want to Cancel Your Subscription!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
    jQuery.ajax({
        url: ajaxurl,
        type : "POST",
        data : {'action' : 'stripe_membership_payment_cancel', 'plan_id' :plan_id, 'sub_id' :sub_id},
        success: function(data){
            Swal.fire(
              'Deleted!',
              'Your Subscrition Plan has been deleted.',
              'success'
            )
            
           location.reload(); 
        },
        error : function(data){
            Swal.fire({
                title: 'Opps...',
                text : data.responseJSON.message,
                type : 'error',
                timer : '3000'
            })
        }
    })
  }else {
    Swal.fire("Your Subscription is safe!");
  }
})




      
/*            swal({
                title: "Are you sure?",
                text: "You Want to Cancel Your Subscription!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajaxurl,
                        type : "POST",
                        data : {'action' : 'stripe_membership_payment_cancel', 'plan_id' :plan_id, 'sub_id' :sub_id},
                        success: function(data){
                            swal("Poof! Your Subscrition Plan has been Canceled!", {
                            icon: "success",
                            });
                           location.reload(); 
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Subscription is safe!");
                }
            });*/
  }       

 
//*============================================ END =================================================*/


