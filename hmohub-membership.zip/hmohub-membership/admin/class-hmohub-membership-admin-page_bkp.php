<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin/partials
 */

class Hmohub_Membership_Admin_Page {
	private $stripepayments_settings_options;
	private $hmohub_pop_up_message_settings_options;
	public function __construct(){
		$this->stripeapisetup();

	}
	public function stripeapisetup(){

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/vendor/autoload.php';

	    $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
	    if(!empty($stripeOption)){
		    $livemode = $stripeOption['is_live_0'];
		    if(isset($livemode) && $livemode === 'is_live_0'){
		       $publishable_key = $stripeOption['api_publishable_key_1'];
		       $secret_key      = $stripeOption['api_secret_key_2'];
		    }else{
		       $publishable_key = $stripeOption['api_publishable_key_test_3'];
		       $secret_key      = $stripeOption['api_secret_key_test_4'];
		    }
		}else{
			$publishable_key = 'pk_test_YGkT6VfeY5cJY9Wl1fkxCu8I00LSiBOVdK';
		    $secret_key      = 'sk_test_EUvwlru7xzqamg9DLbqUTrSG00sRDiUPUL';
		}
	    $stripe = [
		    "secret_key"      => $secret_key,
		    "publishable_key" => $publishable_key,
		];

		\Stripe\Stripe::setApiKey($stripe['secret_key']);
	}
	public function hmohub_membership_page() {

		add_menu_page('Membership Settings', 'Membership Settings', 'manage_options', 'hmohub-membership-page', array(&$this, "property_importer_page_output") );

		add_submenu_page('hmohub-membership-page', 'Membership Settings', 'Membership Settings', 'manage_options', 'hmohub-membership-page', array(&$this, "property_importer_page_output") );
		add_submenu_page('hmohub-membership-page', 'Restriction Settings', 'Restriction Settings', 'manage_options', 'hmohub-restrict-page', array(&$this, "restrict_page_output") );

		add_submenu_page('hmohub-membership-page', 'Message Settings', 'Message Settings', 'manage_options', 'hmohub-pop-up-message-page', array(&$this, "hmohub_pop_up_message_settings_create_admin_page") );
		
	}
	public function hmohub_pop_up_message_settings_create_admin_page() {
		$this->hmohub_pop_up_message_settings_options = get_option( 'hmohub_pop_up_message_settings_option_name' ); ?>

		<div class="wrap">
			<h2>HMOHUB POP UP MESSAGE SETTINGS</h2>
			<p></p>
			<?php settings_errors(); ?>

			<form method="post" action="options.php">
				<?php
					settings_fields( 'hmohub_pop_up_message_settings_option_group' );
					do_settings_sections( 'hmohub-pop-up-message-settings-admin' );
					submit_button();
				?>
			</form>
		</div>
	<?php }

	public function hmohub_pop_up_message_settings_page_init() {
		register_setting(
			'hmohub_pop_up_message_settings_option_group', // option_group
			'hmohub_pop_up_message_settings_option_name', // option_name
			array( $this, 'hmohub_pop_up_message_settings_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'hmohub_pop_up_message_settings_setting_section', // id
			'Settings', // title
			array( $this, 'hmohub_pop_up_message_settings_section_info' ), // callback
			'hmohub-pop-up-message-settings-admin' // page
		);

		add_settings_field(
			'pop_up_message_0', // id
			'POP UP Message', // title
			array( $this, 'pop_up_message_0_callback' ), // callback
			'hmohub-pop-up-message-settings-admin', // page
			'hmohub_pop_up_message_settings_setting_section' // section
		);
	}

	public function hmohub_pop_up_message_settings_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['pop_up_message_0'] ) ) {
			$sanitary_values['pop_up_message_0'] = esc_textarea( $input['pop_up_message_0'] );
		}

		return $sanitary_values;
	}

	public function hmohub_pop_up_message_settings_section_info() {
		
	}

	public function pop_up_message_0_callback() {
		printf(
			'<textarea class="large-text" rows="5" name="hmohub_pop_up_message_settings_option_name[pop_up_message_0]" id="pop_up_message_0">%s</textarea>',
			isset( $this->hmohub_pop_up_message_settings_options['pop_up_message_0'] ) ? esc_attr( $this->hmohub_pop_up_message_settings_options['pop_up_message_0']) : ''
		);
	}
	public function property_importer_page_output(){?>
		<div class="wrap">		 	
		<div class="payment-stripe-setting">
		<h1>Stripe Payment Setup</h1>
		<div class="container">
			<ul class="tabs">
				<li class="tab current" data-tab="tab-1">Payment</li>
				<li class="tab" data-tab="tab-2">Membership</li>
				<li class="tab" data-tab="tab-3">Credentials Settings</li>
			</ul>
			<div id="tab-1" class="tab-content current">
				<div class="container">
					<h2 align="center">All Payment</h2> 
					<?php
						//$Subscription = \Stripe\Subscription::all();
						//$customers = \Stripe\Customer::all();


					    global $wpdb;
					    $table_hmohub_customer = $wpdb->prefix . 'hmohub_customer';
						$hmohub_customer_sql = "SELECT * FROM " . $table_hmohub_customer;

						$hmohub_customer_results = $wpdb->get_results($hmohub_customer_sql);
                             


					?>

					<table class="cell-border" id="customers" class="cell-border" style="width:100%"> 
							        	<thead class="datatablebody">
				            <tr>
				            	<th class="datatablebody_th">Customer</th>
				                <th class="datatablebody_th">Plan Name</th>
				                <th class="datatablebody_th">Plan Interval</th>
				                <th class="datatablebody_th">Plan Price</th>
				            </tr>
				        </thead>
				        <tbody>
				        	<?php


				        if(!empty($hmohub_customer_results)){
                            foreach ($hmohub_customer_results as $hmohub_customer_result) {
                             $plan_id = $hmohub_customer_result->plan_id;
                             $sub_id = $hmohub_customer_result->sub_id;
                             $custId = $hmohub_customer_result->custId;
                             if($custId != '0' && $sub_id !='0'){
                             	$customers = \Stripe\Customer::retrieve($custId);

                             	//print_r($customers['subscriptions']);

                             	foreach ($customers['subscriptions']->data as $subscription) {
			                      	foreach ($subscription['items']->data as $plans) {

			                      		$amount = $plans->plan->amount;
			                      		$price =  $amount / 100;
			                      	}
			                    }




                            	?>
                            	    <tr>  
							            	<td><?php echo $hmohub_customer_result->Email;?></td>
							            	<td><?php echo $plans->plan->nickname;?></td>
							            	<td><?php echo $plans->plan->interval;?></td>
							            	<td><?php echo '$' . number_format($price,2); ?></td>                
							            </tr> 

                            <?php 
                        }
                            }
                        }
                        ?>
                            	

				      
		                		            </tbody>
				        </table>			
				</div>
			</div>    
			<div id="tab-2" class="tab-content">
		    	<div class="container" id="addmoreplandiv">
		    		<div class="plan_success"></div>

	<div class="container-contact100">
		<div class="wrap-contact100">
			<form action="#" method="POST" class="addmore contact100-form validate-form" id="addmoreplan">  
			<input type="hidden" name="action" value="property_stripe_plan_add">   
	
				<span class="contact100-form-title">
					Add New Plan
				</span>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate="Please Type Your Name">
					<span class="label-input100">Plan Name *</span>
				    <input type="text" name="addmorename" placeholder="Enter your Plan Name" class="form-control input100" required />
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "Enter Your Email (e@a.x)">
					<span class="label-input100">Plan Price *</span>
					<input type="text" name="addmoreprice" placeholder="Enter your Plan Price" class="form-control input100" required />
				</div>

				

				<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
					<span class="label-input100">Membership Level </span>
					<div>
						
                     <select id="membership_level_id" class="js-select2" name="membership_level_id">
		                                <?php echo SwpmUtils::membership_level_dropdown(); ?>
	                 </select>

						<div class="dropDownSelect2"></div>
					</div>
				</div>	

				<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
					<span class="label-input100">Plan Interval *</span>
					<div>
						<select class="js-select2" name="addmoreqty" class="form-control" required="required">
									    <option value="0">Select Plan Interval:</option>
									    <option value="month">Monthly</option>
									    <option value="year">Yearly</option>							    
									  </select>

						
						<div class="dropDownSelect2"></div>
					</div>
				</div>		

				<div class="wrap-input100 validate-input bg0 rs1-alert-validate" data-validate = "Please Type Your Message">
					<span class="label-input100">Plan Description </span>

                    <?php
								$content = '';
								$editor_id = 'myplantexteditor';
								$settings = array( 
									'wpautop' => false, 
									'media_buttons' => false, 
									'quicktags' => false,
									'tinymce'       => array(
								    'toolbar1'      => 'bold,italic,underline,alignleft,aligncenter,alignright,link,bullist,numlist',
								    'toolbar2'      => '',
								    'toolbar3'      => '',
								),
								);
								wp_editor( $content, $editor_id, $settings );
				            ?>  

				</div>

				<div class="container-contact100-form-btn">
					<button type="submit" class="btn button-primay add_plan contact100-form-btn"><span>Save<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i></span></button>
				</div>
			</form>
		</div>
	</div>
	<div id="loader"></div>

				</div>   
				<div class="container">
					 <h2 align="center">All Plans</h2> 
					<?php
						$Plans = \Stripe\Plan::all();
					?>
					<table class="cell-border" id="customersPlan" class="cell-border" style="width:100%"> 
							        	<thead class="datatablebody">
				        

				            <tr>
				            	<th class="datatablebody_th">ID</th>
				                <th class="datatablebody_th">Plan Name</th>
				                <th class="datatablebody_th">Plan Interval</th>
				                <th class="datatablebody_th">Plan Price</th>
				                <th class="datatablebody_th">Action</th>
				            </tr>
				        </thead>
				        <tbody>
				            <?php foreach ($Plans['data'] as $plan) {
		                      $price = $plan['amount'] / 100;
				            	?>
					            <tr>  
					            	<td><?php echo $plan['id'];?></td>
					            	<td><?php echo $plan['nickname'];?></td>
					            	<td><?php echo $plan['interval'];?></td>
					            	<td><?php echo '$' . number_format($price,2); ?></td>		                
					                <td><button type="button" onclick="delPlan('<?php echo $plan['id'];?>','<?php echo $plan['product'];?>')" name="add" id="add" class="btn remove-tr">Delete</button></td>  
					            </tr>  
				            <?php } ?>
				            </tbody>
				        </table>			
				</div> 
			</div>    
			<div id="tab-3" class="tab-content">
			<?php $this->stripepayments_settings_options = get_option( 'stripepayments_settings_option_name' ); ?>

				<div class="wrap">
					<h2>StripePayments-settings</h2>
					<p></p>
					<?php settings_errors(); ?>

					<form method="post" action="options.php">
						<?php
							settings_fields( 'stripepayments_settings_option_group' );
							do_settings_sections( 'stripepayments-settings-admin' );
							submit_button();
						?>
					</form>
				</div>

			</div> 
		</div><!-- container -->
		</div>
		</div> 
<style type="text/css">
  #loader {display: none;position: fixed;top: 0;left: 0;right: 0;bottom: 0;width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/hmohub-membership/admin/images/loader1.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }
</style>



    <?php
    }	
    	public function stripepayments_settings_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['is_live_0'] ) ) {
			$sanitary_values['is_live_0'] = $input['is_live_0'];
		}else{
			$sanitary_values['is_live_0'] = '';
		}

		if ( isset( $input['api_publishable_key_1'] ) ) {
			$sanitary_values['api_publishable_key_1'] = sanitize_text_field( $input['api_publishable_key_1'] );
		}

		if ( isset( $input['api_secret_key_2'] ) ) {
			$sanitary_values['api_secret_key_2'] = sanitize_text_field( $input['api_secret_key_2'] );
		}

		if ( isset( $input['api_publishable_key_test_3'] ) ) {
			$sanitary_values['api_publishable_key_test_3'] = sanitize_text_field( $input['api_publishable_key_test_3'] );
		}

		if ( isset( $input['api_secret_key_test_4'] ) ) {
			$sanitary_values['api_secret_key_test_4'] = sanitize_text_field( $input['api_secret_key_test_4'] );
		}

		return $sanitary_values;
	}
	public function stripepayments_settings_page_init() {
		register_setting(
			'stripepayments_settings_option_group', // option_group
			'stripepayments_settings_option_name', // option_name
			array( $this, 'stripepayments_settings_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'stripepayments_settings_setting_section', // id
			'Settings', // title
			array( $this, 'stripepayments_settings_section_info' ), // callback
			'stripepayments-settings-admin' // page
		);

		add_settings_field(
			'is_live_0', // id
			'Live Mode', // title
			array( $this, 'is_live_0_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_publishable_key_1', // id
			'Live Stripe Publishable Key', // title
			array( $this, 'api_publishable_key_1_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_secret_key_2', // id
			'Live Stripe Secret Key', // title
			array( $this, 'api_secret_key_2_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_publishable_key_test_3', // id
			'Test Stripe Publishable Key', // title
			array( $this, 'api_publishable_key_test_3_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);

		add_settings_field(
			'api_secret_key_test_4', // id
			'Test Stripe Secret Key', // title
			array( $this, 'api_secret_key_test_4_callback' ), // callback
			'stripepayments-settings-admin', // page
			'stripepayments_settings_setting_section' // section
		);
	}
	public function stripepayments_settings_section_info() {
		
	}
	public function is_live_0_callback() {
		printf(
			'<input type="checkbox" name="stripepayments_settings_option_name[is_live_0]" id="is_live_0" value="is_live_0" %s> <label for="is_live_0">Check this to run the transaction in live mode. When unchecked it will run in test mode.',
			( isset( $this->stripepayments_settings_options['is_live_0'] ) && $this->stripepayments_settings_options['is_live_0'] === 'is_live_0' ) ? 'checked' : ''
		);
	}

	public function api_publishable_key_1_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_publishable_key_1]" id="api_publishable_key_1" value="%s">',
			isset( $this->stripepayments_settings_options['api_publishable_key_1'] ) ? esc_attr( $this->stripepayments_settings_options['api_publishable_key_1']) : ''
		);
	}

	public function api_secret_key_2_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_secret_key_2]" id="api_secret_key_2" value="%s">',
			isset( $this->stripepayments_settings_options['api_secret_key_2'] ) ? esc_attr( $this->stripepayments_settings_options['api_secret_key_2']) : ''
		);
	}

	public function api_publishable_key_test_3_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_publishable_key_test_3]" id="api_publishable_key_test_3" value="%s">',
			isset( $this->stripepayments_settings_options['api_publishable_key_test_3'] ) ? esc_attr( $this->stripepayments_settings_options['api_publishable_key_test_3']) : ''
		);
	}

	public function api_secret_key_test_4_callback() {
		printf(
			'<input class="regular-text" type="text" name="stripepayments_settings_option_name[api_secret_key_test_4]" id="api_secret_key_test_4" value="%s">',
			isset( $this->stripepayments_settings_options['api_secret_key_test_4'] ) ? esc_attr( $this->stripepayments_settings_options['api_secret_key_test_4']) : ''
		);
	}
	public function property_stripe_plan_add(){
		global $wpdb;
 		$table_name = $wpdb->prefix . 'hmohub_plan';
	    $addmorename = $_POST['addmorename'];
	    $addmoreqty = $_POST['addmoreqty'];
	    $addmoreprice = $_POST['addmoreprice'];
	    $member_id = $_POST['membership_level_id'];
	    $plan_content = $_POST['myplantexteditor'];

	 	$plan = \Stripe\Plan::create(
		    [
				'amount' => $addmoreprice*100,
				'currency' => 'usd',
				'interval' => $addmoreqty,
				'product' => ['name' => $addmorename],
				'nickname' => $addmorename,

			]
		);
        $plan_id = $plan->id;
        $prod_id = $plan->product;
     	if($plan){
			$sql = "INSERT INTO " . $table_name . " (`plan_id`, `Prod_id`,`PlanName`,`PlanAmmount`,`member_level_id`,`PlanInterval`,`plan_content`) values ('" . $plan_id . "', '". $prod_id . "', '" . $addmorename . "', '" . $addmoreprice . "', '" . $member_id . "', '" . $addmoreqty . "','" . $plan_content . "')";
		    $result = $wpdb->query($sql);
		    if($result){
		    	echo $addmorename . "Plan Created Successfully!";
		    }

     	}else{
             echo "something went wrong";
     	}
     	die();
	}
	public function property_stripe_plan_del(){
		$id = $_POST['id'];
		$pid = $_POST['pid'];
		$plan = \Stripe\Plan::retrieve($id);
		$plan->delete();

		$product = \Stripe\Product::retrieve($pid);
		$product->delete();

		global $wpdb;
		$table_name = $wpdb->prefix . 'hmohub_plan';

		$sql = "DELETE FROM " . $table_name . " WHERE `plan_id` = '" . $id . "' AND `Prod_id` = '" . $pid . "'";
		$wpdb->query($sql);
		die();
	}
	public function restrict_page_output(){
		global $restrict_page_active_tab;
		$restrict_page_active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'hmohubcat'; 
		echo '<div class="wrap">';
			echo '<h2 class="nav-tab-wrapper">';
				do_action( 'restrict_page_settings_tab' );
			echo '</h2>';
				do_action( 'restrict_page_settings_content' );
		echo '</div>';
	}		
	public function restrict_page_hmohubcat_tab(){
		global $restrict_page_active_tab; ?>
		<a class="nav-tab <?php echo $restrict_page_active_tab == 'hmohubcat' || '' ? 'nav-tab-active' : ''; ?>" href="<?php echo admin_url( 'admin.php?page=hmohub-restrict-page&tab=hmohubcat' ); ?>"><?php _e( 'Category Restriction', 'hmohub-membership' ); ?> </a>
		<?php
	}
	public function restrict_page_hmohubposttype_tab(){
		global $restrict_page_active_tab; ?>
		<a class="nav-tab <?php echo $restrict_page_active_tab == 'hmohubposttype-tab' ? 'nav-tab-active' : ''; ?>" href="<?php echo admin_url( 'admin.php?page=hmohub-restrict-page&tab=hmohubposttype-tab' ); ?>"><?php _e( 'Post Type Restriction', 'hmohub-membership' ); ?> </a>
		<?php
	}
	public function restrict_page_hmohubcat_render_options_page() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class.hmohub-category-list.php';

//include_once(SIMPLE_WP_MEMBERSHIP_PATH .'classes/class.Hmohub-category-list.php');
        $category_list = new HmohubCategoryList();



        //include_once(SIMPLE_WP_MEMBERSHIP_PATH . 'views/admin_category_list.php');



		global $restrict_page_active_tab;
		if ( '' || 'hmohubcat' != $restrict_page_active_tab )
			return;

/*		echo '<div class="wrap">';	
		    echo '<h3>Category Restriction</h3>';
		    echo '<div class="restric_update"></div>';
		    echo '<form action="" method="POST">';
				echo '<div id="poststuff">';
				echo '<label>Membership Plans: </label>';
					echo '<select id="membership_level_id" class="js-select2" name="membership_level_id">';
			            echo SwpmUtils::membership_level_dropdown($category_list1->selected_level_id);
			        echo '</select>';
			        $args = array(
			            'taxonomy'      => 'category',
			            'orderby'       => 'name',
			            'order'         => 'ASC',
			            'hierarchical'  => 1,
			            'pad_counts'    => 0,
			            'exclude'       => 1
			        );

		global $wpdb;
        $table_membership_tbl = $wpdb->prefix . 'swpm_membership_tbl';
        $arry = array();
        $arry1 = array();
        $sql = "SELECT * FROM " . $table_membership_tbl;
        $results = $wpdb->get_results($sql);
        foreach ($results as $key => $result) {
        	$cat_id = unserialize($result->category_list);
        	$arry[$result->alias] = $cat_id;
        	$arry1[$result->id] = $cat_id;
        	echo "1";
        }
        echo '<pre>';
	        print_r($arry1);
        echo '</pre>';




			        $categories = get_categories( $args );
			        echo '<h4>Category</h4>';
			        foreach ( $categories as $category ){
			            echo '<div class="search-box">';
			                echo '<div class="search-box-inside">';

			               $values = get_term_meta($category->term_id, 'restricted_plan_id', true);
			               foreach ($values as $key => $value1) {
			               	if (array_key_exists($value1,$arry)){
                               // echo 1;
/*			               		echo '<pre>';
	        print_r($arry[$value1]);
        echo '</pre>';*/

			               		//print_r($arry[$value1]);
			               		//exit;
			         /*      	}	
		echo '<pre>';
	        print_r($value);
        echo '</pre>';
			               }*/


	

/*echo '<label><input type="checkbox" name="selector[]" class="cat_id" value="'. $category->term_id . '" rel="'. $category->name . '">'. $category->name . '</label>';*/

			                   

			               /*    
			                echo '</div>';
			            echo '</div>';

			        }
				echo '</div>';
				echo '<input type="submit" name="submit" id="submit" class="button button-primary restriction_plan_update" value="Save Changes">';
			echo '</form>';
		echo '</div>';

		$category_list1->prepare_items();	
		$category_list1->display();*/
		?>

<form id="category_list_form" method="post">
    <input type="hidden" name="swpm_category_prot_update_nonce" value="<?php echo wp_create_nonce('swpm_category_prot_update_nonce_action'); ?>" />
    
    <p class="swpm-select-box-left">
        <label for="membership_level_id"><?php SwpmUtils::e('Membership Level:'); ?></label>
        <select id="membership_level_id" name="membership_level_id">
            <option <?php echo $category_list->selected_level_id == 1 ? "selected" : "" ?> value="1"><?php echo SwpmUtils::_('General Protection'); ?></option>
            <?php echo SwpmUtils::membership_level_dropdown($category_list->selected_level_id); ?>
        </select>                
    </p>
    <p class="swpm-select-box-left">
        <input type="submit" class="button-primary" name="update_category_list" value="<?php SwpmUtils::e('Update'); ?>">
    </p>
        <?php $category_list->prepare_items(); ?>   
        <?php $category_list->display(); ?>
</form>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#membership_level_id').change(function() {
            $('#category_list_form').submit();
        });
    });
</script>

		<?php
	}
	public function restrict_page_hmohubposttype_render_options_page() {
		global $restrict_page_active_tab;
		if ( 'hmohubposttype-tab' != $restrict_page_active_tab )
			return;
		?>
	 
		<h3><?php _e( 'Post Type Restriction', 'hmohub-membership' ); ?></h3>
		<!-- Put your content here -->
		<?php
	}
/*	public function hmohubcat_restriction_plan_update(){
		global $wpdb;
        $table_membership_tbl = $wpdb->prefix . 'swpm_membership_tbl';
        		$membership_level_id = $_POST['membership_level_id'];


        $sql1 = "SELECT * FROM " . $table_membership_tbl . " WHERE `id` = '" . $membership_level_id . "'";
			$results1 = $wpdb->get_row($sql1);
			$alias = $results1->alias;


		$ids = $_POST['ids'];
		foreach ($ids as $id) {
			$dates = get_term_meta($id, 'restricted_plan_id', true);
			if(count($dates) != 0){ 
				//echo "yes";
				if (in_array($alias, $dates)) {
				}else{
					array_push($dates,$alias);
				}
			    
			}else{
			    $dates[] = $new_date;
			}
			update_term_meta($id, 'restricted_plan_id', $dates);
		}


		$mem_id = serialize($ids);	

        $sql = "UPDATE  " . $table_membership_tbl . " SET `category_list` = '" . $mem_id . "' WHERE `id` = '" . $membership_level_id . "'";
		$wpdb->query($sql);   
		echo '<h1>Update Successfully!</h1>';         
		die;
	}*/

}