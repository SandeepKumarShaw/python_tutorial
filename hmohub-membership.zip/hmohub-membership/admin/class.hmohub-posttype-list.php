<?php

/**
 * Post Type Lists
 *
 * @author nur
 */
if (!class_exists('WP_List_Table')) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class HmohubPosttypeList extends WP_List_Table {

    public $selected_level_id = 1;
    public $hmo_posttype;
    public $details;

    public function __construct() {
        parent::__construct(array(
            'singular' => 'Membership Level',
            'plural' => 'Membership Levels',
            'ajax' => false
        ));
        $selected = filter_input(INPUT_POST, 'membership_level_id');
        $this->selected_level_id = empty($selected) ? 1 : $selected;
        $this->hmo_posttype = ($this->selected_level_id == 1) ?
                SwpmProtection::get_instance() :
                SwpmPermission::get_instance($this->selected_level_id);    
         
    }
    public function get_columns(){
        $columns = array(
                'cb' => '<input type="checkbox" />',
                'post_slug' => 'Slug',
                'posttype' => 'Post Type',
                'count' => 'Count'
            );
        return $columns;
    }
    public  function column_cb( $item ) {      

        global $wpdb;
        $table_name = $wpdb->prefix . 'swpm_membership_tbl';

        $sql = "SELECT * FROM " . $table_name . " WHERE `id` = '" . $this->selected_level_id . "'";
        $results = $wpdb->get_row($sql);


        $data = unserialize($results->custom_post_list);   

        return sprintf(
                '<input type="hidden" name="ids_in_page[]" value="%s">
            <input type="checkbox" %s name="ids[]" value="%s" />', $item['post_slug'], in_array($item['post_slug'], $data) ? "checked" : "", $item['post_slug']
        );
    } 
    public static function get_posttypes() {
        $args = array('public' => true  ,'_builtin' => false);
        $output = 'objects';//'names'; // names or objects, note names is the default
        $operator = 'and'; // 'and' or 'or'
        $arr = array();
        $post_types = get_post_types( $args, $output, $operator ); 
        foreach ($post_types as $key => $post_type) {
            $count_posts = wp_count_posts($post_type->name)->publish;

        $arr[$key] = $post_type->label;
        $arr[$key] = array('post_slug' => $post_type->name,'posttype' => $post_type->label,'count' => $count_posts);
        }        
        return $arr;
    }

    public function prepare_items() {

      $columns = $this->get_columns();
      $hidden = array();
      $sortable = array();
      $this->_column_headers = array($columns, $hidden, $sortable);
      $this->items = self::get_posttypes();
    }
    public function column_default( $item, $column_name ) {
      switch( $column_name ) { 
        case 'post_slug':
        case 'posttype':
        case 'count':
          return $item[ $column_name ];
        default:
          return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
      }
    }
    public function no_items() {
        _e( 'No Post Types avaliable.', 'sp' );
    }
}
