jQuery(document).ready( function($) {
  var spinner = $('#loader');
  //spinner.show();
  // Disable search and ordering by default
$.extend( $.fn.dataTable.defaults, {
    searching: false,
    ordering:  false,
    lengthChange: false
} );

   $('#claim_listing_property').DataTable();
      $('#customers').DataTable();

   $('#customersPlan').DataTable();

/*==================================  Custom Tab Functionality ================================*/		
	 	$('ul.tabs li').click(function(){
			var tab_id = $(this).attr('data-tab');

			$('ul.tabs li').removeClass('current');
			$('.tab-content').removeClass('current');

			$(this).addClass('current');
			$("#"+tab_id).addClass('current');
		});

/*====================================== Plan Add With Validation ============================*/
$.validator.addMethod('selectcheck', function (value) {
        return (value != '0');
    }, "Please select Plan Interval");

$('#addmoreplan').validate({

	rules: {
	    addmorename: {         
	        required: true, 
	        minlength: 5,      
	    },
	    addmoreqty: {          
	        selectcheck: true 
	    },
	    addmoreprice: {           
	        required: true,
	        digits: true
	    },
      myplantexteditor:{
        required: true
      }
	},
    messages: {              
        addmorename: {
              required:"Please Enter Plan Name.",
              minlength:"Plan Name at least 5 character long"
              },
        addmoreprice: {
              required: "Please Enter Plan Price",
              minlength: "Please Enter Valid Price"
              },
        myplantexteditor: {
              required: "Please Enter Plan Description"
              }      
    },

    submitHandler: function(form) {
      tinyMCE.triggerSave();
      
      spinner.show();
        $.ajax({
          url: ajax_params.ajax_url,
          type: 'post',
          data: $(form).serialize(),
          success:function(data) {
            spinner.hide();
          	$("#addmoreplan")[0].reset();

           // console.log(data);
                $('.plan_success').html(data);
			      setTimeout(function(){
			        $('.plan_success').fadeOut();
			    },3000);
          location.reload(); 

          },
          error: function(errorThrown){
              console.log(errorThrown);
          }
      });
    }
});
 
}); 
/*============================================ DELETE PLAN ===========================================*/
  function delPlan(id, pid){
      
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this Plan!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajax_params.ajax_url,
                        type : "POST",
                        data : {'action' : 'property_stripe_plan_del', 'id' :id, 'pid' :pid},
                        success: function(data){
                            swal("Poof! Your Plan has been deleted!", {
                            icon: "success",
                            });
                           location.reload(); 
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Plan is safe!");
                }
            });
  }
/*============================================ END =================================================*/

